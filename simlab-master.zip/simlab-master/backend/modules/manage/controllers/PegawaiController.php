<?php

namespace backend\modules\manage\controllers;

use common\models\eis\Pegawai as EisPegawai;
use common\models\refs\RefSubUnit;
use common\models\simlab\Pegawai;
use common\models\simlab\searches\PegawaiSearch;
use common\models\User;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * PegawaiController implements the CRUD actions for Pegawai model.
 */
class PegawaiController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Pegawai models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PegawaiSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single Pegawai model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Pegawai'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new Pegawai model.
     * For ajax request will return json object
     * and for non-ajax request if creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $request = Yii::$app->request;

        $user = new User();
        $pegawai = new Pegawai();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $user->load($request->post());
                $pegawai->load($request->post());

                $user->validate();
                $pegawai->validate();

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    if (!$pegawai->ID_PEGAWAI) {
                        $user->setPassword($user->password);
                        $user->generateAuthKey();
                        $user->generateEmailVerificationToken();

                        $success = $user->save();
                    } else {
                        $success = true;
                    }

                    if ($success && $user->ID) {
                        Yii::$app->authManager->assign(Yii::$app->authManager->getRole($pegawai->DEFAULT_ROLE), $user->ID);
                    }

                    if ($success) {
                        $pegawai->ID_USER = $user->ID;
                        $success = $pegawai->save();
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Tambah Pegawai'),
                            'content' => '<span class="text-success">' . Yii::t('app',
                                    'Tambah pegawai berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Tambah Lagi'),
                                    ['create'],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Tambah Pegawai'),
                        'content' => $this->renderAjax('create', [
                            'user' => $user,
                            'pegawai' => $pegawai,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Tambah Pegawai'),
                    'content' => $this->renderAjax('create', [
                        'user' => $user,
                        'pegawai' => $pegawai,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $user->load($request->post());
                $pegawai->load($request->post());

                $user->validate();
                $pegawai->validate();

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    if (!$pegawai->ID_PEGAWAI) {
                        $user->setPassword($user->password);
                        $user->generateAuthKey();
                        $user->generateEmailVerificationToken();

                        $success = $user->save();
                    } else {
                        $success = true;
                    }

                    if ($success && $user->ID) {
                        Yii::$app->authManager->assign(Yii::$app->authManager->getRole($pegawai->DEFAULT_ROLE), $user->ID);
                    }

                    if ($success) {
                        $pegawai->ID_USER = $user->ID;
                        $success = $pegawai->save();
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Tambah pegawai berhasil.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    return $this->render('create', [
                        'user' => $user,
                        'pegawai' => $pegawai,
                    ]);
                }
            } else {
                return $this->render('create', [
                    'user' => $user,
                    'pegawai' => $pegawai,
                ]);
            }
        }
    }

    /**
     * Updates an existing Pegawai model.
     * For ajax request will return json object
     * and for non-ajax request if update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionUpdate($id)
    {
        $request = Yii::$app->request;
        $authManager = Yii::$app->authManager;

        $pegawai = $this->findModel($id);
        $user = $pegawai->ID_USER ? $pegawai->idUser : new User();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $user->load($request->post());
                $pegawai->load($request->post());

                $user->validate();
                $pegawai->validate();

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    if (!$pegawai->ID_PEGAWAI) {
                        $user->setPassword($user->password);
                        $user->generateAuthKey();
                        $user->generateEmailVerificationToken();

                        $success = $user->save();
                    } else {
                        $success = true;
                    }

                    if ($success && $user->ID) {
                        if (!$authManager->getAssignment($pegawai->DEFAULT_ROLE, $user->ID)) {
                            $authManager->assign($authManager->getRole($pegawai->DEFAULT_ROLE), $user->ID);
                        }
                    }

                    if ($success) {
                        $pegawai->ID_USER = $user->ID;
                        $success = $pegawai->save();
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Update Pegawai'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Update pegawai berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Update'),
                                    ['update', 'id' => $id],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Update Pegawai'),
                        'content' => $this->renderAjax('update', [
                            'user' => $user,
                            'pegawai' => $pegawai,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Tambah Pegawai'),
                    'content' => $this->renderAjax('create', [
                        'user' => $user,
                        'pegawai' => $pegawai,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $user->load($request->post());
                $pegawai->load($request->post());

                $user->validate();
                $pegawai->validate();

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    if (!$pegawai->ID_PEGAWAI) {
                        $user->setPassword($user->password);
                        $user->generateAuthKey();
                        $user->generateEmailVerificationToken();

                        $success = $user->save();
                    } else {
                        $success = true;
                    }

                    if ($success && $user->ID) {
                        if (!$authManager->getAssignment($pegawai->DEFAULT_ROLE, $user->ID)) {
                            $authManager->assign($authManager->getRole($pegawai->DEFAULT_ROLE), $user->ID);
                        }
                    }

                    if ($success) {
                        $pegawai->ID_USER = $user->ID;
                        $success = $pegawai->save();
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Update pegawai berhasil'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    return $this->render('update', [
                        'user' => $user,
                        'pegawai' => $pegawai,
                    ]);
                }
            } else {
                return $this->render('update', [
                    'user' => $user,
                    'pegawai' => $pegawai,
                ]);
            }
        }
    }

    /**
     * Delete an existing Pegawai model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionDelete($id)
    {
        $request = Yii::$app->request;
        $this->findModel($id)->delete();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus pegawaiberhasil'));
        return $this->redirect(['index']);
    }

    /**
     * Delete multiple existing Pegawai model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @return mixed
     * @throws \Throwable
     */
    public function actionBulkDelete()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks')); // Array or selected records primary keys

        foreach ($pks as $pk) {
            $model = $this->findModel($pk);
            $model->delete();
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus user berhasil.'));
        return $this->redirect(['index']);
    }

    /**
     * @param $id
     * @return array
     */
    public function actionApiPegawai($id)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        $model = EisPegawai::find()
            ->select([
                'NAMA_LENGKAP' => 'NAMA_LENGKAP',
                'NIP' => 'NIP',
                'ID_UNIT' => 'ID_UNIT',
                'ID_SUB_UNIT' => 'ID_SUB_UNIT',
                'ID_JENIS_KELAMIN' => 'ID_JENIS_KELAMIN',
                // 'TELP' => 'NOMOR_TELEPON_HP',
            ])
            ->where(['ID' => $id])
            ->asArray()
            ->one();

        return [
            'model' => $model,
            'sub_unit' => RefSubUnit::map('ID', 'SUB_UNIT', ['ID_UNIT' => $model['ID_UNIT']]),
        ];
    }

    /**
     * Finds the Pegawai model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Pegawai the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Pegawai::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
