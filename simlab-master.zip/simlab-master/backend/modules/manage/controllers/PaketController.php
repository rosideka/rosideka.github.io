<?php

namespace backend\modules\manage\controllers;

use common\models\MultipleModel;
use common\models\simlab\Paket;
use common\models\simlab\PaketParameter;
use common\models\simlab\searches\PaketParameterSearch;
use common\models\simlab\searches\PaketSearch;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * PaketController implements the CRUD actions for Paket model.
 */
class PaketController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Paket models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PaketSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single Paket model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);
        $smParameter = new PaketParameterSearch(['ID_PAKET' => $model->ID]);
        $dpParameter = $smParameter->search($request->queryParams);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Paket'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                    'smParameter' => $smParameter,
                    'dpParameter' => $dpParameter,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
            'smParameter' => $smParameter,
            'dpParameter' => $dpParameter,
        ]);
    }

    /**
     * Creates a new Paket model.
     * For ajax request will return json object
     * and for non-ajax request if creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        /* @var $dataPaketParameter PaketParameter[] */

        $request = Yii::$app->request;

        $model = new Paket();
        $dataPaketParameter = [new PaketParameter()];
        $dataPaketParameter = MultipleModel::create(PaketParameter::class, $dataPaketParameter, 'ID');

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());
                $model->validate();

                MultipleModel::loadMultiple($dataPaketParameter, Yii::$app->request->post());
                MultipleModel::validateMultiple($dataPaketParameter);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataPaketParameter as $paketParameter) {
                            $paketParameter->ID_PAKET = $model->ID;
                            if (!$paketParameter->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $model->updateAttributes([
                            'HARGA' => $model->getTotalHarga(),
                        ]);

                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Tambah Paket'),
                            'content' => '<span class="text-success">' . Yii::t('app',
                                    'Tambah paket berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Tambah Lagi'),
                                    ['create'],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Tambah Paket'),
                        'content' => $this->renderAjax('create', [
                            'model' => $model,
                            'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Tambah Paket'),
                    'content' => $this->renderAjax('create', [
                        'model' => $model,
                        'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());
                $model->validate();

                MultipleModel::loadMultiple($dataPaketParameter, Yii::$app->request->post());
                MultipleModel::validateMultiple($dataPaketParameter);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataPaketParameter as $paketParameter) {
                            $paketParameter->ID_PAKET = $model->ID;
                            if (!$paketParameter->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $model->updateAttributes([
                            'HARGA' => $model->getTotalHarga(),
                        ]);

                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Tambah paket berhasil.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('create', [
                        'model' => $model,
                        'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                    ]);
                }
            } else {
                return $this->render('create', [
                    'model' => $model,
                    'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                ]);
            }
        }
    }

    /**
     * Updates an existing Paket model.
     * For ajax request will return json object
     * and for non-ajax request if update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionUpdate($id)
    {
        /* @var $dataPaketParameter PaketParameter[] */

        $request = Yii::$app->request;

        $model = $this->findModel($id);
        $dataPaketParameter = $model->dataPaketParameter;

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataPaketParameter, 'ID', 'ID');
                $dataPaketParameter = MultipleModel::create(PaketParameter::class, $dataPaketParameter);
                MultipleModel::loadMultiple($dataPaketParameter, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataPaketParameter, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataPaketParameter);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = PaketParameter::findOne($delId);
                            if (!$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataPaketParameter as $parameterMetode) {
                            $parameterMetode->ID_PAKET = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $model->updateAttributes([
                            'HARGA' => $model->getTotalHarga(),
                        ]);

                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Update Paket'),
                            'content' => '<span class="text-success">' . Yii::t('app',
                                    'Update paket berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Update'),
                                    ['update', 'id' => $id],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Update Paket'),
                        'content' => $this->renderAjax('update', [
                            'model' => $model,
                            'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Update Paket'),
                    'content' => $this->renderAjax('update', [
                        'model' => $model,
                        'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataPaketParameter, 'ID', 'ID');
                $dataPaketParameter = MultipleModel::create(PaketParameter::class, $dataPaketParameter);
                MultipleModel::loadMultiple($dataPaketParameter, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataPaketParameter, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataPaketParameter);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = PaketParameter::findOne($delId);
                            if (!$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataPaketParameter as $parameterMetode) {
                            $parameterMetode->ID_PAKET = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $model->updateAttributes([
                            'HARGA' => $model->getTotalHarga(),
                        ]);

                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Update paket berhasil'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('update', [
                        'model' => $model,
                        'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                    ]);
                }
            } else {
                return $this->render('update', [
                    'model' => $model,
                    'dataPaketParameter' => $dataPaketParameter ?: [new PaketParameter()],
                ]);
            }
        }
    }

    /**
     * Delete an existing Paket model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionDelete($id)
    {
        $request = Yii::$app->request;
        $this->findModel($id)->delete();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus paketberhasil'));
        return $this->redirect(['index']);
    }

    /**
     * Delete multiple existing Paket model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionBulkDelete()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks')); // Array or selected records primary keys

        foreach ($pks as $pk) {
            $model = $this->findModel($pk);
            $model->delete();
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus user berhasil.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the Paket model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Paket the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Paket::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
