<?php

use common\models\refs\RefBakuMutu;
use common\models\refs\RefJenisPaket;
use common\models\refs\RefSubLayanan;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\PaketSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="paket-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'KODE') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_SUB_LAYANAN')->widget(Select2::class, [
                'data' => RefSubLayanan::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('SUB_LAYANAN')) ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_JENIS_PAKET')->widget(Select2::class, [
                'data' => RefJenisPaket::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('JENIS_PAKET')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_BAKU_MUTU')->widget(Select2::class, [
                'data' => RefBakuMutu::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('BAKU_MUTU')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'HARGA') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'DISKON') ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
