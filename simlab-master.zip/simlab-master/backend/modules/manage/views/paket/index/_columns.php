<?php

use common\models\simlab\searches\PaketParameterSearch;
use kartik\grid\GridView;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\PaketSearch */
/* @var $this yii\web\View */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'expandAllTitle' => Yii::t('app', 'Detail'),
        'collapseTitle' => Yii::t('app', 'Detail'),
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SUB_LAYANAN',
        'label' => $searchModel->getAttributeLabel('SUB_LAYANAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_PAKET',
        'label' => $searchModel->getAttributeLabel('JENIS_PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('BAKU_MUTU'),
    ],
    /*
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SATUAN',
        'label' => $searchModel->getAttributeLabel('SATUAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'HARGA',
        'label' => $searchModel->getAttributeLabel('HARGA'),
        'format' => 'currency',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BIAYA_AMBIL',
        'label' => $searchModel->getAttributeLabel('BIAYA_AMBIL'),
        'format' => 'currency',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'DISKON',
        'label' => $searchModel->getAttributeLabel('DISKON'),
        'format' => 'percent',
    ],
    */
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([
                'paket-parameter/index',
                StringHelper::basename(PaketParameterSearch::class) => [
                    'ID_PAKET' => $model['ID'],
                ],
            ]);
        },
        'template' => '{parameter}',
        'buttons' => [
            'parameter' => function ($url, $model, $key) {
                return Html::a(
                    '<i class="fa fa-file-text-o"></i> ' . Yii::t('app', 'Parameter'),
                    $url,
                    [
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Uji'),
                        'class' => 'btn btn-sm btn-success',
                        'data-pjax' => 0,
                    ]
                );
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
