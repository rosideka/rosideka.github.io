<?php

/* @var $searchModel common\models\simlab\searches\PaketSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_SUB_LAYANAN',
        'label' => $searchModel->getAttributeLabel('ID_SUB_LAYANAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SUB_LAYANAN',
        'label' => $searchModel->getAttributeLabel('SUB_LAYANAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_JENIS_PAKET',
        'label' => $searchModel->getAttributeLabel('ID_JENIS_PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_PAKET',
        'label' => $searchModel->getAttributeLabel('JENIS_PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('ID_BAKU_MUTU'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('BAKU_MUTU'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'HARGA',
        'label' => $searchModel->getAttributeLabel('HARGA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BIAYA_AMBIL',
        'label' => $searchModel->getAttributeLabel('BIAYA_AMBIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'DISKON',
        'label' => $searchModel->getAttributeLabel('DISKON'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
