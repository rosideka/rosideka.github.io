<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model array */
/* @var $searchModel common\models\simlab\searches\PaketSearch */

echo DetailView::widget([
    'model' => $model,
    'options' => ['class' => 'table table-striped table-bordered detail-view', 'style' => 'margin-bottom: 0'],
    'attributes' => [
        [
            'attribute' => 'SUB_LAYANAN',
            'label' => $searchModel->getAttributeLabel('SUB_LAYANAN'),
            'captionOptions' => ['style' => 'width: 33.33%'],
        ],
        [
            'attribute' => 'HARGA',
            'label' => $searchModel->getAttributeLabel('HARGA'),
            'format' => 'currency',
        ],
        [
            'attribute' => 'BIAYA_AMBIL',
            'label' => $searchModel->getAttributeLabel('BIAYA_AMBIL'),
            'format' => 'currency',
        ],
        [
            'attribute' => 'DISKON',
            'label' => $searchModel->getAttributeLabel('DISKON'),
            'format' => 'percent',
        ],
    ],
]);
