<?php

use common\models\refs\RefBakuMutu;
use common\models\refs\RefJenisPaket;
use common\models\refs\RefParameter;
use common\models\refs\RefParameterMetode;
use common\models\refs\RefSubLayanan;
use kartik\select2\Select2;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use yii\helpers\Json;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $model common\models\simlab\Paket */
/* @var $dataPaketParameter common\models\simlab\PaketParameter[] */

$api = Json::encode(['metode' => Url::to(['/api/metode-uji'])]);
$this->registerJs("var api = {$api};");
$this->registerJs($this->render('_script.js'));

$mapParameter = RefParameter::map('ID', 'CONCAT(\'(\', "RUMUS", \') \', "NAMA")');
?>
<div class="paket-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Paket') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(['id' => 'pp_form']); ?>

            <?= $form->field($model, 'ID_SUB_LAYANAN')->widget(Select2::class, [
                'data' => RefSubLayanan::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'ID_JENIS_PAKET')->widget(Select2::class, [
                        'data' => RefJenisPaket::map('ID', 'JENIS_PAKET', ['lastChild' => true]),
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                        'pluginOptions' => ['allowClear' => true],
                    ]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'ID_BAKU_MUTU')->widget(Select2::class, [
                        'data' => RefBakuMutu::map(),
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                        'pluginOptions' => ['allowClear' => true],
                    ]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'KODE')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'NAMA')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'BIAYA_AMBIL')->input('number', ['min' => 0.00, 'step' => 0.01]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'DISKON')->input('number', [
                        'min' => 0.00,
                        'step' => 0.01,
                        'placeholder' => Yii::t('app', 'Diskon dalam bentuk nominal'),
                    ]) ?>

                </div>
            </div>

            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'pp_container',
                'widgetBody' => '.pp-items',
                'widgetItem' => '.pp-item',
                'min' => 1,
                'insertButton' => '.pp-add-item',
                'deleteButton' => '.pp-del-item',
                'model' => $dataPaketParameter[0],
                'formId' => 'pp_form',
                'formFields' => ['ID', 'ID_PARAMETER', 'ID_METODE_UJI', 'KUANTITAS'],
            ]); ?>

            <div class="callout callout-info pp-callout">
                <h4 class="text-uppercase"><?= Yii::t('app', 'Parameter') ?></h4>
            </div>

            <div class="pp-items">
                <div class="row hidden-xs" style="margin-bottom: 10px">
                    <div class="col-xs-4">
                        <label class="control-label">
                            <?= $dataPaketParameter[0]->getAttributeLabel('ID_PARAMETER'); ?>
                        </label>

                    </div>
                    <div class="col-xs-4">
                        <label class="control-label">
                            <?= $dataPaketParameter[0]->getAttributeLabel('ID_METODE_UJI'); ?>
                        </label>

                    </div>
                    <div class="col-xs-2">
                        <label class="control-label">
                            <?= $dataPaketParameter[0]->getAttributeLabel('KUANTITAS') ?>
                        </label>

                    </div>
                    <div class="col-xs-2">
                        <?= Html::button(
                            '<i class="glyphicon glyphicon-plus"></i> ' . Yii::t('app', 'Tambah'),
                            ['class' => 'btn btn-success pp-add-item btn-block']
                        ) ?>

                    </div>
                </div>
                <?php foreach ($dataPaketParameter as $index => $paketParameter): ?>
                    <div class="row item pp-item">
                        <?= $paketParameter->isNewRecord ? Html::activeHiddenInput($paketParameter, "[{$index}]ID") : '' ?>

                        <div class="col-xs-4">
                            <?= $form->field($paketParameter, "[{$index}]ID_PARAMETER")->widget(Select2::class, [
                                'data' => $mapParameter,
                                'options' => [
                                    'placeholder' => Yii::t('app', '-- Pilih --'),
                                    'class' => 'fi-id-parameter',
                                ],
                                'pluginOptions' => [
                                    'allowClear' => true,
                                    'escapeMarkup' => new JsExpression('function (r) {return r}'),
                                ],
                            ])->label(false) ?>

                        </div>
                        <div class="col-xs-4">
                            <?=
                            $form->field($paketParameter, "[{$index}]ID_METODE_UJI")->widget(Select2::class, [
                                'data' => $paketParameter->ID_PARAMETER
                                    ? RefParameterMetode::map(
                                        'B.ID',
                                        'B.NAMA_METODE',
                                        ['A.ID_PARAMETER' => $paketParameter->ID_PARAMETER]
                                    )
                                    : [],
                                'options' => [
                                    'placeholder' => Yii::t('app', '-- Pilih --'),
                                    'class' => 'fi-id-metode-uji',
                                ],
                                'pluginOptions' => ['allowClear' => true],
                            ])->label(false)
                            ?>

                        </div>
                        <div class="col-xs-2">
                            <?=
                            $form
                                ->field($paketParameter, "[{$index}]KUANTITAS")
                                ->input('number', ['min' => 0.00, 'step' => 0.01])
                                ->label(false)
                            ?>

                        </div>
                        <div class="col-xs-2">
                            <?= Html::button(
                                '<i class="glyphicon glyphicon-trash"></i> Hapus',
                                ['class' => 'btn btn-block btn-danger pp-del-item']
                            ) ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php DynamicFormWidget::end(); ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
