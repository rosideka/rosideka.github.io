/* jshint esversion: 6 */
/* globals $:true, */

(function ($) {
  let containers = $('.pp_container');

  containers.on("beforeInsert", function (e, item) {
    let container = $(this);
    let widget = eval(container.data('dynamicform'));
    let template = $(widget.template);
    template.find('.fi-id-metode-uji option:not(:first)').remove();

    widget.template.html(template.html());
  });

  containers.on('change', '.fi-id-parameter', function (e) {
    e.preventDefault();
    e.stopImmediatePropagation();

    let element = $(this);
    let item = element.closest('.item');
    let target = item.find('.fi-id-metode-uji');

    $.ajax({
      url: api.metode,
      data: {id: element.val()},
      beforeSend: function () {
        target.children('option:not(:first)').remove();
      }
    })
      .done(function (data) {
        $.each(data.output, function(key, value) {
          target.append($("<option></option>").attr("value",key).text(value));
          target.val(data.selected).change();
        });
      })
      .fail(function (data) {
      })
      .always(function (data) {
      })
  })
}(jQuery));
