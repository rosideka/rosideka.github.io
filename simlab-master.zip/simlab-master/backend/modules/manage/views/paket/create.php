<?php

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Paket */
/* @var $dataPaketParameter common\models\simlab\PaketParameter[] */

$this->title = Yii::t('app', 'Tambah Paket');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Paket'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="paket-create">
    <?= $this->render('_form', [
        'model' => $model,
        'dataPaketParameter' => $dataPaketParameter,
    ]) ?>
</div>
