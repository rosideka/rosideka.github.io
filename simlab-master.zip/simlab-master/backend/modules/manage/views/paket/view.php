<?php

use kartik\grid\GridView;
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Paket */
/* @var $dpParameter yii\data\SqlDataProvider */

$this->title = Yii::t('app', 'Paket');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Paket'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="paket-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title text-uppercase"><?= Yii::t('app', 'Detail Paket') ?></div>
        </div>
        <div class="box-body">
            <?php
            echo DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width: 33.33%'],
                    ],
                    'KODE',
                    'NAMA',
                    [
                        'attribute' => 'ID_SUB_LAYANAN',
                        'value' => $model->ID_SUB_LAYANAN ? $model->idSubLayanan->NAMA : null,
                    ],
                    [
                        'attribute' => 'ID_JENIS_PAKET',
                        'value' => $model->ID_JENIS_PAKET ? $model->idJenisPaket->JENIS_PAKET : null,
                    ],
                    [
                        'attribute' => 'ID_BAKU_MUTU',
                        'value' => $model->ID_BAKU_MUTU ? $model->idBakuMutu->NAMA_BAKU_MUTU : null,
                    ],
                    'HARGA:currency',
                    'BIAYA_AMBIL:currency',
                    'DISKON:currency',
                    [
                        'label' => 'Total Biaya (Harga + Biaya Ambil - Diskon)',
                        'value' => $model->HARGA + $model->BIAYA_AMBIL - $model->DISKON,
                        'format' => 'currency',
                    ],
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]);

            echo Html::tag('h4', Yii::t('app', 'Parameter'), ['class' => 'text-uppercase']);

            echo GridView::widget([
                'dataProvider' => $dpParameter,
                'pjax' => true,
                'pjaxSettings' => [
                    'options' => [
                        'enablePushState' => false,
                        'enableReplaceState' => false,
                    ],
                ],
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'RUMUS_PARAMETER',
                        'format' => 'raw',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'NAMA_PARAMETER',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'METODE_UJI',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'TARIF_UJI',
                        'format' => 'currency',
                        'pageSummary' => true,
                        'headerOptions' => ['style' => 'text-align:center;width:100px'],
                        'contentOptions' => ['style' => 'text-align:right'],
                        'pageSummaryOptions' => ['style' => 'text-align:right'],
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'KUANTITAS',
                        'pageSummary' => true,
                        'headerOptions' => ['style' => 'text-align:center;width:50px'],
                        'contentOptions' => ['style' => 'text-align:right'],
                        'pageSummaryOptions' => ['style' => 'text-align:right'],
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'panel' => false,
                'summary' => false,
                'showPageSummary' => true,
            ])
            ?>

        </div>
    </div>
</div>
