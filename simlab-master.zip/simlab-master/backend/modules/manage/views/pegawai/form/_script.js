(function ($) {
  $('#fi-id-pegawai').change(function () {
    let element = $(this);
    let name = element.data('model');
    let account = $('#wr-account');
    let api = new URL(element.data('api'));
    api.searchParams.append('id', element.val());

    console.log(element.val() !== '');

    if (element.val() !== '') {
      account.removeClass('in')
    } else {
      account.addClass('in');
    }

    $.ajax({
      url: api,
      method: 'POST',
      beforeSend: function () {
        element.closest('.form-group').append('<span class="loading"><i class="fa fa-spinner fa-pulse"></i> Loading...</span>');
      },
    }).done(function (response) {
      element.closest('.form-group').find('.loading').remove();
      let model = response.model;
      let subunit = $('#fi-id-sub-unit');

      subunit.html('');

      $.each(response.sub_unit, function (i, v) {
        subunit.append(new Option(v, i, false, false))
      });

      subunit.select2('enable', [true]);

      $.each(model, function (i, v) {
        $('[name="' + name + '[' + i + ']"]').val(v).change()
      });
    }).fail(function (response) {
      element.closest('.form-group').find('.loading').html('<i class="fa fa-spinner fa-warning"></i> Error...');
    })
  });
}(jQuery));