<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */
/* @var $pegawai common\models\simlab\Pegawai */

$this->title = Yii::t('app', 'Update Pegawai');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Pegawai'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pegawai-update">
    <?= $this->render('_form', [
        'user' => $user,
        'pegawai' => $pegawai,
    ]) ?>
</div>
