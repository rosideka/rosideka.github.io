<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Pegawai */

$user = $model->idUser;

$this->title = Yii::t('app', 'Pegawai');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Pegawai'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pegawai-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title text-uppercase"><?= Yii::t('app', 'Detail Pegawai') ?></div>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width: 33.33%'],
                    ],
                    'ID_PEGAWAI',
                    [
                        'label' => Yii::t('app', 'Username'),
                        'value' => $user ? $user->USERNAME : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Email'),
                        'value' => $user ? $user->EMAIL : null,
                    ],
                    'NAMA_LENGKAP',
                    'NIP',
                    [
                        'label' => Yii::t('app', 'Lab'),
                        'value' => $model->ID_LAB ? $model->idLab->NAMA : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Unit'),
                        'value' => $model->ID_UNIT ? $model->idUnit->UNIT : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Sub Unit'),
                        'value' => $model->ID_SUB_UNIT ? $model->idSubUnit->SUB_UNIT : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Jenis Kelamin'),
                        'value' => $model->ID_JENIS_KELAMIN ? $model->idJenisKelamin->JENIS_KELAMIN : null,
                    ],
                    'ALAMAT',
                    'TELP',
                    [
                        'label' => Yii::t('app', 'Status'),
                        'value' => $user ? $user->getStatusText() : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]) ?>

        </div>
    </div>
</div>
