<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */
/* @var $pegawai common\models\simlab\Pegawai */

$this->title = Yii::t('app', 'Tambah Pegawai');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Pegawai'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pegawai-create">
    <?= $this->render('_form', [
        'user' => $user,
        'pegawai' => $pegawai,
    ]) ?>
</div>
