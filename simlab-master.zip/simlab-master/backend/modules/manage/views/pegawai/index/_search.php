<?php

use common\models\refs\RefLab;
use common\models\refs\RefSubUnit;
use common\models\refs\RefUnit;
use kartik\depdrop\DepDrop;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\PegawaiSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="pegawai-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_PEGAWAI') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'USERNAME') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA_LENGKAP') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'NIP') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_LAB')->widget(Select2::class, [
                'data' => RefLab::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('LAB')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_UNIT')->widget(Select2::class, [
                'data' => RefUnit::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --'), 'id' => 'fs-id-unit'],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('UNIT')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_SUB_UNIT')->widget(DepDrop::class, [
                'data' => $model->ID_UNIT
                    ? ['' => Yii::t('app', '-- Pilih --')]
                    + RefSubUnit::map('ID', 'SUB_UNIT', ['ID_UNIT' => $model->ID_UNIT])
                    : ['' => Yii::t('app', '-- Pilih --')],
                'type' => DepDrop::TYPE_SELECT2,
                'select2Options' => ['pluginOptions' => ['allowClear' => true]],
                'pluginOptions' => [
                    'depends' => ['fs-id-unit'],
                    'placeholder' => '--Pilih --',
                    'url' => Url::to(['/api/depdrop-sub-unit', 'access' => false]),
                    'loadingText' => 'Loading Data...',
                ],
            ])->label($model->getAttributeLabel('SUB_UNIT')) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
