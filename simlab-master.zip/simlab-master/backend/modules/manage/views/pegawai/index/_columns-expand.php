<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $searchModel common\models\simlab\searches\PegawaiSearch */

$authManager = Yii::$app->authManager;

echo DetailView::widget([
    'model' => $model,
    'options' => ['class' => 'table table-striped table-bordered detail-view', 'style' => 'margin-bottom: 0'],
    'attributes' => [
        [
            'attribute' => 'EMAIL',
            'label' => $searchModel->getAttributeLabel('JENIS_KELAMIN'),
            'captionOptions' => ['style' => 'width: 33.33%'],
            'format' => 'email',
        ],
        [
            'attribute' => 'TELP',
            'label' => $searchModel->getAttributeLabel('TELP'),
        ],
        [
            'attribute' => 'JENIS_KELAMIN',
            'label' => $searchModel->getAttributeLabel('JENIS_KELAMIN'),
        ],
        [
            'attribute' => 'ALAMAT',
            'label' => $searchModel->getAttributeLabel('ALAMAT'),
        ],
        [
            'attribute' => 'DEFAULT_ROLE',
            'label' => $searchModel->getAttributeLabel('DEFAULT_ROLE'),
            'value' => $model['ID_USER']
                ? implode(', ', ArrayHelper::getColumn($authManager->getRolesByUser($model['ID']), 'description'))
                : null,
        ],
    ],
]);
