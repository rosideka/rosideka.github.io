<?php

/* @var $searchModel common\models\simlab\searches\PegawaiSearch */

use common\models\User;
use yii\helpers\ArrayHelper;

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_USER',
        'label' => $searchModel->getAttributeLabel('ID_USER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL',
        'label' => $searchModel->getAttributeLabel('EMAIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PEGAWAI',
        'label' => $searchModel->getAttributeLabel('ID_PEGAWAI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LENGKAP',
        'label' => $searchModel->getAttributeLabel('NAMA_LENGKAP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NIP',
        'label' => $searchModel->getAttributeLabel('NIP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_LAB',
        'label' => $searchModel->getAttributeLabel('ID_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LAB',
        'label' => $searchModel->getAttributeLabel('LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UNIT',
        'label' => $searchModel->getAttributeLabel('ID_UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UNIT',
        'label' => $searchModel->getAttributeLabel('UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_SUB_UNIT',
        'label' => $searchModel->getAttributeLabel('ID_SUB_UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SUB_UNIT',
        'label' => $searchModel->getAttributeLabel('SUB_UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_JENIS_KELAMIN',
        'label' => $searchModel->getAttributeLabel('ID_JENIS_KELAMIN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_KELAMIN',
        'label' => $searchModel->getAttributeLabel('JENIS_KELAMIN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ALAMAT',
        'label' => $searchModel->getAttributeLabel('ALAMAT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS',
        'label' => $searchModel->getAttributeLabel('STATUS'),
        'value' => function ($model) {
            return ArrayHelper::getValue(User::getStatusList(), $model['STATUS']);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
