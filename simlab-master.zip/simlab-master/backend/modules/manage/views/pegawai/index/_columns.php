<?php

use common\models\User;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\PegawaiSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'expandAllTitle' => Yii::t('app', 'Detail'),
        'collapseTitle' => Yii::t('app', 'Detail'),
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PEGAWAI',
        'label' => $searchModel->getAttributeLabel('ID_PEGAWAI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LENGKAP',
        'label' => $searchModel->getAttributeLabel('NAMA_LENGKAP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NIP',
        'label' => $searchModel->getAttributeLabel('NIP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LAB',
        'label' => $searchModel->getAttributeLabel('LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UNIT',
        'label' => $searchModel->getAttributeLabel('UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SUB_UNIT',
        'label' => $searchModel->getAttributeLabel('SUB_UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS',
        'label' => $searchModel->getAttributeLabel('STATUS'),
        'value' => function ($model) {
            return ArrayHelper::getValue(User::getStatusList(), $model['STATUS']);
        },
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
