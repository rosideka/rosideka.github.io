<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */
/* @var $member common\models\simlab\Member */
/* @var $dataMemberPj common\models\simlab\MemberPj[] */

$this->title = Yii::t('app', 'Update Member');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Member'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="member-update">
    <?= $this->render('_form', [
        'user' => $user,
        'member' => $member,
        'dataMemberPj' => $dataMemberPj,
    ]) ?>
</div>
