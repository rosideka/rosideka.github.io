<?php

use kartik\grid\GridView;
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Member */
/* @var $smMemberPj common\models\simlab\searches\MemberPjSearch */
/* @var $dpMemberPj yii\data\SqlDataProvider */

$this->title = Yii::t('app', 'Member');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Member'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$user = $model->idUser;
?>
<div class="member-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title"><?= Yii::t('app', 'Detail Member') ?></div>
        </div>
        <div class="box-body">
            <?php
            echo DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width: 33.33%'],
                    ],
                    [
                        'label' => $user->getAttributeLabel('USERNAME'),
                        'value' => $user->USERNAME,
                    ],
                    [
                        'label' => $user->getAttributeLabel('EMAIL'),
                        'value' => $user->EMAIL,
                        'format' => 'email',
                    ],
                    'NAMA',
                    'NO_IDENTITAS',
                    'ALAMAT',
                    'TELP',
                    'FAX',
                    [
                        'label' => $model->getAttributeLabel('ID_JENIS_MEMBER'),
                        'value' => $model->ID_JENIS_MEMBER ? $model->idJenisMember->JENIS_MEMBER : null,
                    ],
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]);

            echo Html::tag('h4', Yii::t('app', 'Penanggung Jawab'), ['class' => 'text-uppercase']);

            echo GridView::widget([
                'dataProvider' => $dpMemberPj,
                'pjax' => true,
                'pjaxSettings' => [
                    'options' => [
                        'enablePushState' => false,
                        'enableReplaceState' => false,
                    ],
                ],
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'NAMA',
                        'label' => $smMemberPj->getAttributeLabel('NAMA'),
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'EMAIL',
                        'label' => $smMemberPj->getAttributeLabel('EMAIL'),
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'TELP',
                        'label' => $smMemberPj->getAttributeLabel('TELP'),
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'IS_DEFAULT',
                        'label' => $smMemberPj->getAttributeLabel('IS_DEFAULT'),
                        'format' => 'boolean',
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'panel' => false,
                'summary' => false,
            ])
            ?>

        </div>
    </div>
</div>
