(function ($) {
  let container = $('#mpj-toggle');

  $('#fi-id-jenis-member').change(function () {
    let element = $(this);
    let value = element.val();

    if (parseInt(value) === 2) {
      container.addClass('in')
    } else {
      container.removeClass('in')
    }
  });

  container.on('change', '.fi-is-default', function (){
    let element = $(this);
    let value = element.val();

    if (parseInt(value) === 1) {
      let parent = element.closest('.mpj-item');
      let siblings = parent.siblings('.mpj-item');

      siblings.find('.fi-is-default').each(function (i, e) {
        $(e).val('0').change();
      });
    }
  })
}(jQuery));
