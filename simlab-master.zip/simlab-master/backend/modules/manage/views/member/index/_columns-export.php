<?php

/* @var $searchModel common\models\simlab\searches\MemberSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_USER',
        'label' => $searchModel->getAttributeLabel('ID_USER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL',
        'label' => $searchModel->getAttributeLabel('EMAIL'),
        'format' => 'email',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_IDENTITAS',
        'label' => $searchModel->getAttributeLabel('NO_IDENTITAS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ALAMAT',
        'label' => $searchModel->getAttributeLabel('ALAMAT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'FAX',
        'label' => $searchModel->getAttributeLabel('FAX'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_JENIS_MEMBER',
        'label' => $searchModel->getAttributeLabel('ID_JENIS_MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_MEMBER',
        'label' => $searchModel->getAttributeLabel('JENIS_MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
