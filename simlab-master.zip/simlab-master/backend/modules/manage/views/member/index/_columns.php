<?php

use common\models\simlab\searches\MemberPjSearch;
use common\models\User;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\MemberSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL',
        'label' => $searchModel->getAttributeLabel('EMAIL'),
        'format' => 'email',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ALAMAT',
        'label' => $searchModel->getAttributeLabel('ALAMAT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'FAX',
        'label' => $searchModel->getAttributeLabel('FAX'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_MEMBER',
        'label' => $searchModel->getAttributeLabel('JENIS_MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS',
        'label' => $searchModel->getAttributeLabel('STATUS'),
        'value' => function ($model) {
            return ArrayHelper::getValue(User::getStatusList(), $model['STATUS']);
        },
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'PJ'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{member-pj}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([
                'member-pj/index',
                StringHelper::basename(MemberPjSearch::class) => [
                    'ID_MEMBER' => $model['ID'],
                ],
            ]);
        },
        'buttons' => [
            'member-pj' => function ($url, $model, $key) {
                if ($model['ID_JENIS_MEMBER'] === 1) {
                    return '';
                }

                return Html::a(
                    '<i class="glyphicon glyphicon-user"></i> ' . Yii::t('app', 'PJ'),
                    $url,
                    [
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Uji'),
                        'class' => 'btn btn-sm btn-success',
                        'data-pjax' => 0,
                    ]
                );
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
