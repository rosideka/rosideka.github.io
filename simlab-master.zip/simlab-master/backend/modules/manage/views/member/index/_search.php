<?php

use common\models\refs\RefJenisMember;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\MemberSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="member-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'USERNAME') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'EMAIL') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ALAMAT') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'TELP') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'FAX') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_JENIS_MEMBER')->widget(Select2::class, [
                'data' => RefJenisMember::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('JENIS_MEMBER')) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
