<?php

use common\models\refs\RefJenisMember;
use common\models\User;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $user common\models\User */
/* @var $member common\models\simlab\Member */
/* @var $dataMemberPj common\models\simlab\MemberPj[] */

$this->registerCss($this->render('form/_style.min.css'));
$this->registerJs($this->render('form/_script.min.js'));
?>
<div class="member-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Member') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(['id' => 'mpj_form']); ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($user, 'USERNAME')->textInput() ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($user, 'EMAIL')->textInput() ?>

                </div>
            </div>

            <?php if ($user->isNewRecord): ?>
                <div class="row">
                    <div class="col-sm-6">
                        <?= $form->field($user, 'password')->passwordInput() ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($user, 'passwordRepeat')->passwordInput() ?>

                    </div>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($member, 'NAMA')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($member, 'TELP')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($member, 'FAX')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($member, 'NO_IDENTITAS')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <?= $form->field($member, 'ALAMAT')->textarea(['maxlength' => true, 'rows' => 2]) ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($member, 'ID_JENIS_MEMBER')->dropDownList(
                        RefJenisMember::map(),
                        ['prompt' => Yii::t('app', '-- Pilih --'), 'id' => 'fi-id-jenis-member']
                    ) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($user, 'STATUS')->dropDownList(
                        User::getStatusList(),
                        ['prompt' => Yii::t('app', '-- Pilih --')]
                    ) ?>

                </div>
            </div>
            <div id="mpj-toggle" class="collapse<?= !$member->ID_JENIS_MEMBER || $member->ID_JENIS_MEMBER == 1 ? '' : ' in' ?>">
                <?php DynamicFormWidget::begin([
                    'widgetContainer' => 'mpj_container',
                    'widgetBody' => '.mpj-items',
                    'widgetItem' => '.mpj-item',
                    'min' => 1,
                    'insertButton' => '.mpj-add-item',
                    'deleteButton' => '.mpj-del-item',
                    'model' => $dataMemberPj[0],
                    'formId' => 'mpj_form',
                    'formFields' => ['ID', 'ID_PARAMETER', 'ID_METODE_UJI', 'KUANTITAS'],
                ]); ?>

                <div class="callout callout-info mpj-callout">
                    <h4 class="text-uppercase" style="margin-bottom: 0">
                        <?= Yii::t('app', 'Penanggung Jawab') ?>
                    </h4>
                </div>

                <div class="mpj-items">
                    <div class="clearfix">
                        <?= Html::button(
                            '<i class="glyphicon glyphicon-plus"></i> ' . Yii::t('app', 'Tambah'),
                            ['class' => 'btn btn-success mpj-add-item pull-right']
                        ) ?>

                    </div>

                    <?php foreach ($dataMemberPj as $index => $memberPj): ?>
                        <div class="item mpj-item">
                            <?= $memberPj->isNewRecord ? Html::activeHiddenInput($memberPj, "[{$index}]ID") : '' ?>

                            <div class="row">
                                <div class="col-sm-6">
                                    <?= $form->field($memberPj, "[{$index}]NAMA")->textInput() ?>

                                </div>
                                <div class="col-sm-6">
                                    <?= $form->field($memberPj, "[{$index}]EMAIL")->textInput() ?>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <?= $form->field($memberPj, "[{$index}]TELP")->textInput() ?>

                                </div>
                                <div class="col-sm-4">
                                    <?= $form->field($memberPj, "[{$index}]IS_DEFAULT")->dropDownList(
                                        [1 => Yii::t('app', 'Ya'), 0 => Yii::t('app', 'Tidak')],
                                        ['prompt' => Yii::t('app', '-- Pilih --'), 'class' => 'form-control fi-is-default']
                                    ) ?>

                                </div>
                                <div class="col-sm-2">
                                    <?= Html::button(
                                        '<i class="glyphicon glyphicon-trash"></i> Hapus',
                                        ['class' => 'btn btn-block btn-danger mpj-del-item', 'style' => 'margin-top: 25px']
                                    ) ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php DynamicFormWidget::end(); ?>

            </div>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $member->isNewRecord ? Yii::t('app', 'Simpan') : Yii::t('app', 'Update'),
                        ['class' => $member->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
