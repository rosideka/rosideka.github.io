<?php

use common\models\refs\RefLayanan;
use common\models\refs\RefSubLayanan;
use kartik\depdrop\DepDrop;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\FaqSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="faq-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-xs-6 col-sm-3">
            <?= $form->field($model, 'ID_LAYANAN')->widget(Select2::class, [
                'data' => RefLayanan::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --'), 'id' => 'fi-id-layanan'],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
        <div class="col-xs-6 col-sm-3">
            <?= $form->field($model, 'ID_SUB_LAYANAN')->widget(DepDrop::class, [
                'data' => $model->ID_LAYANAN
                    ? ['' => '-- Pilih --'] + RefSubLayanan::map('ID', 'NAMA', ['ID_LAYANAN' => $model->ID_LAYANAN])
                    : ['' => '-- Pilih --'],
                'type' => DepDrop::TYPE_SELECT2,
                'select2Options' => ['pluginOptions' => ['allowClear' => true]],
                'pluginOptions' => [
                    'depends' => ['fi-id-layanan'],
                    'placeholder' => Yii::t('app', '-- Pilih --'),
                    'url' => Url::to(['/api/depdrop-sub-layanan']),
                    'loadingText' => 'Loading Data...',
                ],
            ]) ?>

        </div>
        <div class="col-xs-12 col-sm-6">
            <?= $form->field($model, 'KEYWORD') ?>
            
        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
