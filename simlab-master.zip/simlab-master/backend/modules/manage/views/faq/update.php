<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Faq */

$this->title = Yii::t('app', 'Update Faq');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Faq'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="faq-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
