<?php

use common\models\refs\RefLayanan;
use common\models\refs\RefSubLayanan;
use dosamigos\tinymce\TinyMce;
use kartik\depdrop\DepDrop;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Faq */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="faq-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form F.A.Q.') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <div class="row">
                <div class="col-xs-6">
                    <?= $form->field($model, 'ID_LAYANAN')->widget(Select2::class, [
                        'data' => RefLayanan::map(),
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --'), 'id' => 'fi-id-layanan'],
                        'pluginOptions' => ['allowClear' => true],
                    ]) ?>

                </div>
                <div class="col-xs-6">
                    <?= $form->field($model, 'ID_SUB_LAYANAN')->widget(DepDrop::class, [
                        'data' => $model->ID_LAYANAN
                            ? ['' => '-- Pilih --'] + RefSubLayanan::map('ID', 'NAMA', ['ID_LAYANAN' => $model->ID_LAYANAN])
                            : ['' => '-- Pilih --'],
                        'type' => DepDrop::TYPE_SELECT2,
                        'select2Options' => ['pluginOptions' => ['allowClear' => true]],
                        'pluginOptions' => [
                            'depends' => ['fi-id-layanan'],
                            'placeholder' => Yii::t('app', '-- Pilih --'),
                            'url' => Url::to(['/api/depdrop-sub-layanan']),
                            'loadingText' => 'Loading Data...',
                        ],
                    ]) ?>

                </div>
            </div>

            <?= $form->field($model, 'QUESTION')->widget(TinyMce::class, [
                'clientOptions' => [
                    'height' => 300,
                    'menubar' => false,
                    'plugins' => [
                        "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                        "searchreplace visualblocks visualchars code fullscreen",
                        "insertdatetime media nonbreaking save table contextmenu directionality",
                        "template paste textcolor",
                    ],
                    'toolbar' => "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media | forecolor backcolor | code fullscreen",
                ],
            ]) ?>

            <?= $form->field($model, 'ANSWER')->widget(TinyMce::class, [
                'clientOptions' => [
                    'height' => 300,
                    'menubar' => false,
                    'plugins' => [
                        "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                        "searchreplace visualblocks visualchars code fullscreen",
                        "insertdatetime media nonbreaking save table contextmenu directionality",
                        "template paste textcolor",
                    ],
                    'toolbar' => "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media | forecolor backcolor | code fullscreen",
                ],
            ]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
