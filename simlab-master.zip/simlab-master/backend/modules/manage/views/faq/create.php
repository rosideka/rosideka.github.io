<?php



/* @var $this yii\web\View */
/* @var $model common\models\simlab\Faq */

$this->title = Yii::t('app', 'Tambah F.A.Q.');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Faq'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="faq-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
