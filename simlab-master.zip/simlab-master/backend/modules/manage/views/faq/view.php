<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Faq */

$this->registerCss('.faq-view img{max-width: 100%; height: auto;}');

$this->title = Yii::t('app', 'F.A.Q.');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Faq'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="faq-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title"><?= Yii::t('app', 'Detail F.A.Q.') ?></div>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6">
                    <h4>
                        <small>
                            <?= $model->getAttributeLabel('ID_LAYANAN') ?>
                        </small><br/>
                        <?= $model->ID_LAYANAN ? $model->idLayanan->NAMA : null ?>
                    </h4>
                </div>
                <div class="col-sm-6">
                    <h4>
                        <small>
                            <?= $model->getAttributeLabel('ID_SUB_LAYANAN') ?>
                        </small><br/>
                        <?= $model->ID_LAYANAN ? $model->idSubLayanan->NAMA : null ?>
                    </h4>
                </div>
            </div>
            <div class="question lead text-blue" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd">
                <?= $model->QUESTION ?>
            </div>
            <div class="answer" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd">
                <?= $model->ANSWER ?>
            </div>
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]) ?>

        </div>
    </div>
</div>
