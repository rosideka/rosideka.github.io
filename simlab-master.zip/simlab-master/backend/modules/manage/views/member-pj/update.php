<?php

/* @var $this yii\web\View */
/* @var $model common\models\simlab\MemberPj */

$this->title = Yii::t('app', 'Update Member Pj');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Member Pj'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="member-pj-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
