<?php

use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\MemberPj */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="member-pj-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Member Pj') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?php
            $member = $model->ID_MEMBER ? $model->idMember : null;

            echo $form->field($model, 'ID_MEMBER')->widget(Select2::class, [
                'initValueText' => $member ? implode(' - ', [$member->ID, $member->NAMA]) : null,
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => [
                    'allowClear' => true,
                    'minimumInputLength' => 3,
                    'ajax' => [
                        'url' => Url::to(['/api/id-member']),
                        'delay' => 500,
                        'dataType' => 'JSON',
                        'data' => new JsExpression('function(params) { return { q:params.term }; }'),
                    ],
                    'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                    'templateResult' => new JsExpression('function(response) { return response.text; }'),
                    'templateSelection' => new JsExpression('function (response) { return response.text; }'),
                ],
            ]);
            ?>

            <?= $form->field($model, 'NAMA')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'NO_IDENTITAS')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'EMAIL')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'TELP')->textInput(['maxlength' => true]) ?>

            <?=
            $form
                ->field($model, 'IS_DEFAULT', ['template' => '{input} {label} {error} {hint}'])
                ->checkbox([], false)
                ->label('Jadikan penanggung jawab utama')
            ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
