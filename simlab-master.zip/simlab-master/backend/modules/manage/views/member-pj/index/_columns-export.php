<?php

/* @var $searchModel common\models\simlab\searches\MemberPjSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_MEMBER',
        'label' => $searchModel->getAttributeLabel('ID_MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'MEMBER',
        'label' => $searchModel->getAttributeLabel('MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_IDENTITAS',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL',
        'label' => $searchModel->getAttributeLabel('EMAIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IS_DEFAULT',
        'label' => $searchModel->getAttributeLabel('IS_DEFAULT'),
        'format' => 'boolean',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
