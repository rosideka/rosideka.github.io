<?php

use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\searches\MemberPjSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="member-pj-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-4">
            <?php
            $member = $model->ID_MEMBER ? $model->idMember : null;

            echo $form->field($model, 'ID_MEMBER')->widget(Select2::class, [
                'initValueText' => $member ? implode(' - ', [$member->ID, $member->NAMA]) : null,
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => [
                    'allowClear' => true,
                    'minimumInputLength' => 3,
                    'ajax' => [
                        'url' => Url::to(['/api/id-member']),
                        'delay' => 500,
                        'dataType' => 'JSON',
                        'data' => new JsExpression('function(params) { return { q:params.term }; }'),
                    ],
                    'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                    'templateResult' => new JsExpression('function(response) { return response.text; }'),
                    'templateSelection' => new JsExpression('function (response) { return response.text; }'),
                ],
            ])->label($model->getAttributeLabel('MEMBER'));
            ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'NAMA') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'EMAIL') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'TELP') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'IS_DEFAULT')->dropDownList(
                [1 => Yii::t('app', 'Ya'), 0 => Yii::t('app', 'Tidak')],
                ['prompt' => Yii::t('app', '-- Pilih --')]
            ) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
