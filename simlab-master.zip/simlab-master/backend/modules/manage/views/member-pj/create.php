<?php

/* @var $this yii\web\View */
/* @var $model common\models\simlab\MemberPj */

$this->title = Yii::t('app', 'Tambah Member Pj');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Member Pj'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="member-pj-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
