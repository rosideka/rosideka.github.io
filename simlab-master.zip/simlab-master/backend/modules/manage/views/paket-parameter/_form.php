<?php

use common\models\refs\RefParameter;
use common\models\refs\RefParameterMetode;
use common\models\simlab\Paket;
use kartik\depdrop\DepDrop;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\PaketParameter */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="paket-parameter-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Paket Parameter') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($model, 'ID_PAKET')->widget(Select2::class, [
                'data' => Paket::map('A.ID', 'CONCAT("A"."KODE", \' - \', "A"."NAMA")'),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

            <?= $form->field($model, 'ID_PARAMETER')->widget(Select2::class, [
                'data' => RefParameter::map('ID', 'CONCAT(\'(\', "RUMUS", \') \', "NAMA")'),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --'), 'id' => 'fi-id-parameter'],
                'pluginOptions' => [
                    'allowClear' => true,
                    'escapeMarkup' => new JsExpression('function (r) {return r}'),
                ],
            ]) ?>

            <?= $form->field($model, 'ID_METODE_UJI')->widget(DepDrop::class, [
                'data' => $model->ID_PARAMETER
                    ? ['' => Yii::t('app', '-- Pilih --')]
                    + RefParameterMetode::map('B.ID', 'B.NAMA_METODE', ['ID_PARAMETER' => $model->ID_PARAMETER])
                    : ['' => Yii::t('app', '-- Pilih --')],
                'type' => DepDrop::TYPE_SELECT2,
                'select2Options' => ['pluginOptions' => ['allowClear' => true]],
                'pluginOptions' => [
                    'depends' => ['fi-id-parameter'],
                    'placeholder' => Yii::t('app', '-- Pilih --'),
                    'url' => Url::to(['/api/depdrop-metode-uji', 'access' => false]),
                    'loadingText' => 'Loading Data...',
                ],
            ]) ?>

            <?= $form->field($model, 'KUANTITAS')->input('number', ['min' => 0.00, 'step' => 0.01]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
