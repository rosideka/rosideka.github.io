<?php

use common\models\refs\RefMetodeUji;
use common\models\refs\RefParameter;
use common\models\simlab\Paket;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\PaketParameterSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="paket-parameter-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-6">
            <?= $form->field($model, 'ID_PAKET')->widget(Select2::class, [
                'data' => Paket::map('A.ID', 'CONCAT("A"."KODE", \' - \', "A"."NAMA")'),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('PAKET')) ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'ID_PARAMETER')->widget(Select2::class, [
                'data' => RefParameter::map('ID', 'CONCAT(\'(\', "RUMUS", \') \', "NAMA")'),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => [
                    'allowClear' => true,
                    'escapeMarkup' => new JsExpression('function (r) {return r}'),
                ],
            ])->label($model->getAttributeLabel('NAMA_PARAMETER')) ?>

        </div>
        <div class="col-sm-6">
            <?= $form->field($model, 'ID_METODE_UJI')->widget(Select2::class, [
                'data' => RefMetodeUJi::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('METODE_UJI')) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
