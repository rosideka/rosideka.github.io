<?php

/* @var $searchModel common\models\simlab\searches\PaketParameterSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PAKET',
        'label' => $searchModel->getAttributeLabel('ID_PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PAKET',
        'label' => $searchModel->getAttributeLabel('PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PARAMETER',
        'label' => $searchModel->getAttributeLabel('ID_PARAMETER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_PARAMETER',
        'label' => $searchModel->getAttributeLabel('NAMA_PARAMETER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_METODE_UJI',
        'label' => $searchModel->getAttributeLabel('ID_METODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'METODE_UJI',
        'label' => $searchModel->getAttributeLabel('METODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KUANTITAS',
        'label' => $searchModel->getAttributeLabel('KUANTITAS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TARIF_UJI',
        'label' => $searchModel->getAttributeLabel('TARIF_UJI'),
        'format' => 'currency',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
