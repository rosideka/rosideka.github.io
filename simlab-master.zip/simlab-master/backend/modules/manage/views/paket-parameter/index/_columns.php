<?php
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\PaketParameterSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PAKET',
        'label' => $searchModel->getAttributeLabel('PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_PARAMETER',
        'label' => $searchModel->getAttributeLabel('NAMA_PARAMETER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'METODE_UJI',
        'label' => $searchModel->getAttributeLabel('METODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KUANTITAS',
        'label' => $searchModel->getAttributeLabel('KUANTITAS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TARIF_UJI',
        'label' => $searchModel->getAttributeLabel('TARIF_UJI'),
        'format' => 'currency',
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
