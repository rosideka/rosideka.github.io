<?php

/* @var $this yii\web\View */
/* @var $model common\models\simlab\PaketParameter */

$this->title = Yii::t('app', 'Tambah Paket Parameter');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Paket Parameter'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="paket-parameter-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
