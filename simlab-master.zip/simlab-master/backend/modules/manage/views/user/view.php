<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Detail User');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard User'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title"><?= Yii::t('app', 'Detail User') ?></div>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'ID',
                    'USERNAME',
                    'EMAIL:email',
                    [
                        'attribute' => 'STATUS',
                        'value' => $model->getStatusText(),
                    ],
                    [
                        'attribute' => 'CREATED_AT',
                        'format' => ['datetime', 'php:d F Y H:i:s'],
                    ],
                    [
                        'attribute' => 'UPDATED_AT',
                        'format' => ['datetime', 'php:d F Y H:i:s'],
                    ],
                ],
            ]) ?>

            <p style="margin-top: 15px">
                <b><?= Yii::t('app', 'PERHATIAN: Gunakan kode ini hanya jika dibutuhkan.') ?></b>
            </p>
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'PASSWORD_RESET_TOKEN',
                    'VERIFICATION_TOKEN',
                ],
            ]) ?>

        </div>
    </div>
</div>
