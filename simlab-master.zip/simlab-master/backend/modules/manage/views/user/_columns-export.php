<?php

/* @var $searchModel common\models\searches\UserSearch */

use yii\helpers\ArrayHelper;

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL',
        'label' => $searchModel->getAttributeLabel('EMAIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS',
        'label' => $searchModel->getAttributeLabel('STATUS'),
        'value' => function ($model) use ($searchModel) {
            return ArrayHelper::getValue($searchModel::getStatusList(), $model['STATUS']);
        },
        'filter' => $searchModel::getStatusList(),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATED_AT',
        'label' => $searchModel->getAttributeLabel('CREATED_AT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATED_AT',
        'label' => $searchModel->getAttributeLabel('UPDATED_AT'),
    ],
];
