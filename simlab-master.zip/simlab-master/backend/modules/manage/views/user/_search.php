<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\searches\UserSearch */
/* @var $form yii\widgets\ActiveForm */

$template = '{label}<div class="input-group">{input}<span class="input-group-btn">'
    . Html::submitButton('<i class="glyphicon glyphicon-search"></i>', ['class' => 'btn btn-primary'])
    . '</span></div>';
?>
<div class="user-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID', ['template' => $template]) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'USERNAME', ['template' => $template]) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'EMAIL', ['template' => $template]) ?>

        </div>
        <div class="col-sm-3">
            <?=
            $form
                ->field($model, 'STATUS', ['template' => $template])
                ->dropDownList($model::getStatusList(), ['prompt' => Yii::t('app', '-- Pilih --')]);
            ?>

        </div>
    </div>
    <?php ActiveForm::end(); ?>

</div>
