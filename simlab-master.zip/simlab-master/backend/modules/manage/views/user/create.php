<?php



/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Tambah User');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard User'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
