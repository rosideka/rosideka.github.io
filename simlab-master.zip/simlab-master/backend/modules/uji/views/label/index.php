<?php

use common\models\simlab\Uji;
use johnitvn\ajaxcrud\BulkButtonWidget;
use johnitvn\ajaxcrud\CrudAsset;
use kartik\export\ExportMenu;
use kartik\grid\GridView;
use yii\bootstrap\Modal;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $searchModel backend\modules\uji\models\PenerimaanSearch */
/* @var $dpSearch yii\data\SqlDataProvider|yii\data\ActiveDataProvider */
/* @var $dpExport yii\data\SqlDataProvider|yii\data\ActiveDataProvider */

CrudAsset::register($this);
$this->registerCss('#crud-datatable th, #crud-datatable td{white-space:normal}');

$this->title = Yii::t('app', 'Dashboard Label');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uji-index">
    <div class="box box-primary">
        <div class="box-header with-border">
            <?= ExportMenu::widget([
                'container' => ['class' => 'btn-group', 'role' => 'group'],
                'dataProvider' => $dpExport,
                'columns' => require(__DIR__ . '/index/_columns-export.php'),
                'fontAwesome' => true,
                'columnSelectorOptions' => ['label' => 'Kolom'],
                'columnSelectorMenuOptions' => ['style' => ['height' => '240px', 'overflow-y' => 'auto']],
                'dropdownOptions' => ['label' => 'Export', 'class' => 'btn btn-default'],
                'batchSize' => $dpExport->pagination->pageSize,
                'target' => '_blank',
                'stream' => true,
                'deleteAfterSave' => true,
                'filename' => 'EXPORT-DATA-LAB-' . date('Y-m-d'),
            ]); ?>

            <div class="pull-right">
                <?= Html::button(
                    '<i class="glyphicon fa fa-search"></i> ' . Yii::t('app', 'Pencarian'),
                    [
                        'class' => 'btn btn-info search-button',
                        'data-toggle' => 'collapse',
                        'data-target' => '.search-collapse',
                    ]
                ) ?>

                <?= Html::a(
                    '<i class="glyphicon glyphicon-refresh"></i>',
                    ['index'],
                    ['class' => 'btn btn-warning']
                ) ?>

            </div>
        </div>
        <div class="box-body search-collapse collapse in">
            <?= $this->render('index/_search', [
                'model' => $searchModel,
            ]); ?>
        </div>
    </div>
    <?php
    $before = '';
    $params = [];

    if ($searchModel->KODE_UJI && ($uji = Uji::findByKode($searchModel->KODE_UJI, $searchModel->TAHUN_PERMOHONAN))) {
        $params = array_merge($params, ['id' => $uji->ID]);
    }

    if ($params) {
        $before = Html::a(
            '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Cetak Semua'),
            array_merge(['print-all'], $params),
            ['role' => 'modal-remote', 'class' => 'btn btn-danger']
        );
    }

    echo GridView::widget([
        'id' => 'crud-datatable',
        'dataProvider' => $dpSearch,
        'pjax' => true,
        'columns' => require(__DIR__ . '/index/_columns.php'),
        'toolbar' => [
            [
                'content' =>
                    Html::a(
                        '<i class="glyphicon glyphicon-repeat"></i>',
                        ['index'],
                        ['data-pjax' => 1, 'class' => 'btn btn-default', 'title' => Yii::t('app', 'Reset')]
                    )
                    . '{toggleData}'
                    . '{export}',
            ],
        ],
        'striped' => true,
        'condensed' => true,
        'responsive' => true,
        'responsiveWrap' => false,
        'panel' => [
            'type' => 'default',
            'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Uji'),
            'before' => $before,
            'after' => BulkButtonWidget::widget([
                'buttons' => Html::a(
                    '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Cetak Terpilih'),
                    ['print-selected'],
                    [
                        'class' => 'btn btn-danger btn-sm',
                        'role' => 'modal-remote-bulk',
                        'data-confirm' => false,
                        'data-method' => false,
                        'data-request-method' => 'post',
                        'data-confirm-title' => Yii::t('app', 'Apakah Anda Akan Mencetak Label CU?'),
                        'data-confirm-message' => Yii::t('app', 'Apakah anda bener akan mencetak label contoh uji terpilih'),
                    ]
                ),
            ])
                . '<div class="clearfix"></div>',
        ],
    ]) ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Keterangan</h3>
        </div>
        <div class="panel-body">
            <h4>Kode Uji Lab: LP1.0001.L1.0002.0003</h4>
            <table class="table table-condensed" style="margin-bottom: 0">
                <tbody>
                    <tr>
                        <th style="width: 10px"><b class="label label-default">LP2</b></th>
                        <td>Kode penerimaan contoh uji</td>
                    </tr>
                    <tr>
                        <th><b class="label label-default">0001</b></th>
                        <td>Kode agenda per tahun</td>
                    </tr>
                    <tr>
                        <th><b class="label label-default">L1</b></th>
                        <td>Kode laboratorium</td>
                    </tr>
                    <tr>
                        <th><b class="label label-default">0002</b></th>
                        <td>Kode uji laboratorium hasil generate (urutan) per laboratorium</td>
                    </tr>
                    <tr>
                        <th><b class="label label-default">0003</b></th>
                        <td>Kode jenis paket</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
Modal::begin([
    'id' => 'ajaxCrudModal',
    'footer' => '',
]);
Modal::end();
?>
