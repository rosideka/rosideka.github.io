<?php

/* @var $this yii\web\View */
/* @var $dataUjiLab common\models\simlab\Uji[] */

$this->title = Yii::t('app', 'Penerimaan Contoh Uji');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Penerimaan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uji-create">
    <?= $this->render('_form', [
        'dataUjiLab' => $dataUjiLab,
    ]) ?>
</div>
