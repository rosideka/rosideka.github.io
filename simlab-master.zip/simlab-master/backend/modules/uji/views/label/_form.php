<?php

use common\models\refs\RefUjiRetensi;
use common\models\simlab\Agenda;
use common\models\simlab\Pegawai;
use common\models\simlab\Uji;
use common\models\simlab\UjiLab;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\View;
use yii\widgets\ActiveForm;

/* @var $this View */
/* @var $form ActiveForm */
/* @var $agenda Agenda */
/* @var $dataUjiLab UjiLab[] */

$formatter = Yii::$app->formatter;

$no = 0;
$mapUjiRetensi = RefUjiRetensi::map();
$mapPegawai = Pegawai::map('ID', 'NAMA_LENGKAP');
?>
<div class="uji-form">
    <?php $form = ActiveForm::begin(); ?>

    <?php foreach ($dataUjiLab as $i => $ujiLab) { ?>
        <?php
        /* @var $uji Uji */
        /* @var $ujiLab UjiLab */

        $uji = $ujiLab->idUji;
        $lab = $ujiLab->idLab;
        ?>
        <div class="box box-success box-solid uji-item">
            <div class="box-header" data-toggle="collapse" data-target="#carousel-uji-<?= $i ?>" style="cursor: pointer">
                <h4 class="box-title"><?= implode(' - ', [$uji->KODE, $uji->ASAL_CONTOH_UJI]) ?></h4>
            </div>
            <div id="carousel-uji-<?= $i ?>" class="box-body collapse in">
                <table class="table table-bordered table-striped" style="margin-bottom: 15px">
                    <thead>
                    <tr>
                        <th style="width: 5%; text-align: center;">#CU</th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Jenis Contoh Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Parameter Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Lab') ?></th>
                        <th style="width: 24%;text-align: center"><?= Yii::t('app', 'Kode Uji Lab*') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="text-center"><?= $i + 1 ?></td>
                        <td><?= $formatter->asText(ArrayHelper::getValue($uji, 'idPaket.NAMA')) ?></td>
                        <td>
                            <?= implode(', ', ArrayHelper::getColumn(
                                $uji->getDataUjiParameter()->where(['ID_LAB' => $ujiLab->ID_LAB])->all(),
                                'idParameter.RUMUS'
                            )) ?>
                        </td>
                        <td><?= $formatter->asText(ArrayHelper::getValue($lab, 'NAMA')) ?></td>
                        <td class="text-center"><?= $formatter->asText(ArrayHelper::getValue($ujiLab, 'KODE')) ?></td>
                    </tr>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-sm-4">
                        <?= $form->field($ujiLab, "[{$i}]ID_UJI_RETENSI")->widget(Select2::class, [
                            'data' => $mapUjiRetensi,
                            'options' => ['placeholder' => '-- Pilih --'],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                    <div class="col-sm-2">
                        <?= $form->field($ujiLab, "[{$i}]NO_CETAK")->widget(Select2::class, [
                            'data' => UjiLab::mapNoCetak(),
                            'options' => ['placeholder' => '-- Pilih --', 'class' => 'fi-no_cetak'],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($ujiLab, "[{$i}]IDP_KOORDINATOR")->widget(Select2::class, [
                            'data' => $mapPegawai,
                            'options' => ['placeholder' => '-- Pilih --'],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <?php if ($pks = Yii::$app->request->post('pks')) { ?>
        <?= Html::hiddenInput('pks', $pks); ?>
    <?php } ?>

    <?php if (!Yii::$app->request->isAjax) { ?>
        <div class="form-group">
            <?= Html::submitButton(Yii::t('app', 'Simpan'), ['class' => 'btn btn-primary']) ?>
        </div>
    <?php } ?>

    <?php ActiveForm::end(); ?>

</div>
