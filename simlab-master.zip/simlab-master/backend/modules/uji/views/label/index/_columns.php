<?php

use backend\modules\uji\models\LabelSearch;
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $searchModel LabelSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
        'checkboxOptions' => function ($model) {
            if (!in_array($model['ID_STATUS_UJI'], [4, 5, 6])) {
                return ['disabled' => true];
            }

            return ['value' => implode('|', [$model['ID'], $model['ID_LAB']])];
        },
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_AGENDA',
        'label' => $searchModel->getAttributeLabel('KODE_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI',
        'label' => $searchModel->getAttributeLabel('KODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ASAL_CONTOH_UJI',
        'label' => $searchModel->getAttributeLabel('ASAL_CONTOH_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LAB',
        'label' => $searchModel->getAttributeLabel('NAMA_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_CU_LAB',
        'value' => 'KODE_UJI_LAB',
        'label' => $searchModel->getAttributeLabel('KODE_UJI_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PENERIMAAN',
        'value' => 'TANGGAL_PENERIMAAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Label'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{print}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['print', 'idu' => $model['ID_UJI'], 'idl' => $model['ID_LAB']]);
        },
        'buttons' => [
            'print' => function ($url, $model, $key) {
                if ($model['ID_STATUS_UJI'] >= 4) {
                    return Html::a(
                        '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Cetak'),
                        $url,
                        [
                            'data-toggle' => 'tooltip',
                            'title' => Yii::t('app', 'Cetak'),
                            'class' => 'btn btn-sm btn-danger',
                            'role' => 'modal-remote',
                        ]
                    );
                }

                return '';
            },
        ],
    ],
];
