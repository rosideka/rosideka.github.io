<?php

use common\models\refs\RefBakuMutu;
use common\models\refs\RefJenisPaket;
use common\models\refs\RefKlasifikasiLokasi;
use common\models\refs\RefStatusUji;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\modules\uji\models\LabelSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="uji-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'TAHUN_PERMOHONAN')->input('number', ['step' => 1]) ?>

        </div>
        <div class="col-sm-2">
            <?= $form->field($model, 'KODE_AGENDA') ?>

        </div>
        <div class="col-sm-2">
            <?= $form->field($model, 'KODE_UJI') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_LAB')->widget(Select2::class, [
                'data' => common\models\refs\RefLab::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label(Yii::t('app', 'Lab')) ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_JENIS_PAKET')->widget(Select2::class, [
                'data' => RefJenisPaket::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('JENIS_PAKET')) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_BAKU_MUTU')->widget(Select2::class, [
                'data' => RefBakuMutu::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('BAKU_MUTU')) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_KLASIFIKASI_LOKASI')->widget(Select2::class, [
                'data' => RefKlasifikasiLokasi::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('KLASIFIKASI_LOKASI')) ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_STATUS_UJI')->widget(Select2::class, [
                'data' => RefStatusUji::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('STATUS_UJI')) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'TANGGAL_PENERIMAAN_AWAL')->widget(DatePicker::class, [
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'options' => ['placeholder' => 'Format: yyyy-mm-dd'],
                'pluginOptions' => ['autoclose' => true, 'format' => 'yyyy-mm-dd'],
            ])->label($model->getAttributeLabel('TANGGAL_PENERIMAAN_AWAL')) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'TANGGAL_PENERIMAAN_AKHIR')->widget(DatePicker::class, [
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'options' => ['placeholder' => 'Format: yyyy-mm-dd'],
                'pluginOptions' => ['autoclose' => true, 'format' => 'yyyy-mm-dd'],
            ])->label($model->getAttributeLabel('TANGGAL_PENERIMAAN_AKHIR')) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
