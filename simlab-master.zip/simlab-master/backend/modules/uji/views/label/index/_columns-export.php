<?php

/* @var $searchModel \backend\modules\uji\models\LabelSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TAHUN_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TAHUN_PERMOHONAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PENERIMAAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_AGENDA',
        'label' => $searchModel->getAttributeLabel('ID_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_AGENDA',
        'label' => $searchModel->getAttributeLabel('KODE_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI',
        'label' => $searchModel->getAttributeLabel('KODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ASAL_CONTOH_UJI',
        'label' => $searchModel->getAttributeLabel('ASAL_CONTOH_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LAB',
        'label' => $searchModel->getAttributeLabel('NAMA_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_PARAMETER',
        'label' => $searchModel->getAttributeLabel('NAMA_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_CU_LAB',
        'label' => $searchModel->getAttributeLabel('KODE_UJI_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI_LAB',
        'label' => $searchModel->getAttributeLabel('KODE_UJI_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
];
