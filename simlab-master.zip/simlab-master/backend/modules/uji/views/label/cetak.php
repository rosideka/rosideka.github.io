<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */


/* @var $this yii\web\View */
/* @var $dataUjiLab common\models\simlab\UjiLab[] */

$this->registerCss('tr th, tr td {padding-left: 1px; text-align: left; vertical-align: top;}');
$this->registerCss($this->render('docx/_style.css'));

$formatter = Yii::$app->formatter;
$this->title = 'Label Contoh Uji';

$max = (int) substr((string) max(array_keys($dataUjiLab)), 0, -1) ?: 1;
?>
<div class="cetak portrait label-docx" style="font-family: Arial !important;">
    <?php for ($i = 0; $i < $max; $i++) { ?>
        <table style="width: 15.71cm; border-collapse: collapse">
            <tbody>
                <?php for ($j = 1; $j <= 10; $j += 2) { ?>
                <?php $no = $i * 10 + $j; ?>
                <tr style="border: none !important">
                    <?php
                    /* @var $ujiLab1 \common\models\simlab\UjiLab|null */
                    /* @var $ujiLab2 \common\models\simlab\UjiLab|null */
                    $ujiLab1 = $dataUjiLab[$no] ?? null;
                    $ujiLab2 = $dataUjiLab[$no + 1] ?? null;
                    ?>
                    <?php if ($ujiLab1) { ?>
                        <td style="border: 1px solid #000; height: 3.81cm; width: 7.7cm">
                            <?= $this->render('docx/_row', ['ujiLab' => $ujiLab1]); ?>
                        </td>
                    <?php } else { ?>
                        <td style="height: 3.81cm; width: 7.701cm"></td>
                    <?php } ?>
                    
                    <td style="width: 0.29cm;"></td>
                    <?php if ($ujiLab2) { ?>
                        <td style="border: 1px solid #000; height: 3.81cm; width: 7.7cm">
                            <?= $this->render('docx/_row', ['ujiLab' => $ujiLab2]); ?>
                        </td>
                    <?php } else { ?>
                        <td style="height: 3.8cm; width: 7.701cm"></td>
                    <?php } ?>
                </tr>
                <tr>
                    <td style="height: 0.29cm;"></td>
                    <td></td>
                    <td></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="page-break"></div>
    <?php } ?>
</div>
