<?php

/* @var $this yii\web\View */
/* @var $ujiLab \common\models\simlab\UjiLab */
?>
<?php if ($ujiLab) { ?>
    <?php
    $uji = $ujiLab->idUji;
    $agenda = $uji->idAgenda;
    $jenis = $uji->idJenisPaket;
    $retensi = $ujiLab->idUjiRetensi;
    $penerima = $agenda->idpPenerima;
    ?>
    <h2 class="text-center" style="font-size: 9pt; margin: 2pt">
        <span class="text-uppercase" style="text-decoration: underline">
            LABEL CONTOH UJI<br/>
        </span>
        <span style="text-decoration: underline">
            No. Agenda: <?= $agenda->KODE ?>
        </span>
    </h2>
    <table style="border-collapse: collapse; font-size: 9pt; line-height: 1.3">
        <tbody>
        <tr style="font-size: 11pt; font-weight: bold">
            <td style="width: 40%;">Kode CU</td>
            <td>:</td>
            <td><?= $ujiLab->KODE ?></td>
        </tr>
        <tr>
            <td>Jenis Cu</td>
            <td>:</td>
            <td><?= $jenis->JENIS_PAKET ?></td>
        </tr>
        <tr>
            <td>Tanggal Masuk</td>
            <td>:</td>
            <td><?= $agenda->TANGGAL_PENERIMAAN ?></td>
        </tr>
        <tr>
            <td>Tanggal Kadaluarsa</td>
            <td>:</td>
            <td><?= $retensi->RETENSI ?></td>
        </tr>
        </tbody>
    </table>
    <table style="border-collapse: collapse; font-size: 9pt; line-height: 1.3">
        <tbody>
        <tr>
            <td style="width: 60%; text-align: center">
                <span style="font-size: 24pt; font-weight: bold; line-height: 1">
                    <?= $retensi->KODE ?>
                </span>
                <br>
                <span style="font-size: 7pt; line-height: 0.7">Kode Retensi</span>
            </td>
            <td>
                Penerima CU
                <br>
                <br>
                <?= $penerima->NAMA_LENGKAP ?>
            </td>
        </tr>
        </tbody>
    </table>
<?php } ?>
