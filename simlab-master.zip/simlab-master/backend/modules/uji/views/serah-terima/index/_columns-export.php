<?php

/* @var $searchModel backend\modules\uji\models\SerahTerimaSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_CU_LAB',
        'label' => $searchModel->getAttributeLabel('NO_CU_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_LAB',
        'label' => Yii::t('app', 'ID Lab'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LAB',
        'label' => $searchModel->getAttributeLabel('LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_RETENSI',
        'label' => Yii::t('app', 'ID Uji Retensi'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_RETENSI',
        'label' => $searchModel->getAttributeLabel('UJI_RETENSI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IDP_KOORDINATOR',
        'label' => Yii::t('app', 'IDP Koordinator'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KOORDINATOR',
        'label' => $searchModel->getAttributeLabel('KOORDINATOR'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IDP_PENGIRIM',
        'label' => Yii::t('app', 'IDP Pengirim'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PENGIRIM',
        'label' => $searchModel->getAttributeLabel('PENGIRIM'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IDP_PENERIMA',
        'label' => Yii::t('app', 'IDP Penerima'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PENERIMA',
        'label' => $searchModel->getAttributeLabel('PENERIMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TGL_TERIMA',
        'label' => $searchModel->getAttributeLabel('TGL_TERIMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
