<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $searchModel backend\modules\uji\models\PenerimaanSearch */

echo DetailView::widget([
    'model' => $model,
    'options' => [
        'class' => 'table table-striped table-bordered detail-view',
        'style' => 'margin-bottom: 0',
    ],
    'attributes' => [
        [
            'attribute' => 'KOORDINATOR',
            'label' => $searchModel->getAttributeLabel('KOORDINATOR'),
            'captionOptions' => ['style' => 'width: 33.33%'],
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'PENGIRIM',
            'label' => $searchModel->getAttributeLabel('PENGIRIM'),
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'PENERIMA',
            'label' => $searchModel->getAttributeLabel('PENERIMA'),
        ],
    ],
]);
