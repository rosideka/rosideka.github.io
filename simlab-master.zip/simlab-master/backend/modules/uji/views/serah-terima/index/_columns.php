<?php

use kartik\grid\GridView;
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $searchModel backend\modules\uji\models\SerahTerimaSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'width' => '30px',
        'expandAllTitle' => 'Detail Agenda',
        'collapseTitle' => 'Detail Agenda',
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LAB',
        'label' => $searchModel->getAttributeLabel('LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('RUMUS_PARAMETER'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_RETENSI',
        'label' => $searchModel->getAttributeLabel('UJI_RETENSI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TGL_TERIMA',
        'label' => $searchModel->getAttributeLabel('TGL_TERIMA'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Terima'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{terima}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['terima', 'id' => $key]);
        },
        'buttons' => [
            'terima' => function ($url, $model, $key) {
                return Html::a(
                    Yii::t('app', 'Terima'),
                    $url,
                    [
                        'role' => 'modal-remote',
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Label'),
                        'class' => 'btn btn-sm btn-primary',
                        'data-pjax' => 0,
                    ]
                );
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Cetak'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{cetak}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['cetak', 'id' => $key]);
        },
        'buttons' => [
            'cetak' => function ($url, $model, $key) {
                if (!$model['TGL_TERIMA']) {
                    return '';
                }

                return Html::a(
                    '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Cetak'),
                    $url,
                    [
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Cetak'),
                        'class' => 'btn btn-sm btn-danger',
                        'data-pjax' => 0,
                    ]
                );
            },
        ],
    ],
];
