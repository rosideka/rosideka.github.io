<?php

use backend\modules\uji\models\SerahTerimaSearch;
use common\models\refs\RefLab;
use common\models\refs\RefUjiRetensi;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model SerahTerimaSearch */
/* @var $form ActiveForm */
?>
<div class="uji-lab-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'KODE') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_LAB')->widget(Select2::class, [
                'data' => RefLab::map(),
                'options' => ['placeholder' => '-- Pilih --'],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_UJI_RETENSI')->widget(Select2::class, [
                'data' => RefUjiRetensi::map(),
                'options' => ['placeholder' => '-- Pilih --'],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'PENGIRIM') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'TGL_TERIMA')->widget(DatePicker::class, [
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'options' => ['placeholder' => 'YYYY-MM-DD'],
                'pluginOptions' => ['autoclose' => true, 'format' => 'yyyy-mm-dd'],
            ]) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . 'Proses',
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . 'Reset',
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
