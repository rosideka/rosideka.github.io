<?php

use common\models\simlab\UjiLab;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model UjiLab */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="uji-lab-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Serah Terima CU') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?php
            $pengirim = $model->idpPengirim ?? null;

            echo $form->field($model, 'IDP_PENGIRIM')->widget(Select2::class, [
                'initValueText' => implode(' - ', $pengirim
                    ? [$pengirim->ID, $pengirim->NAMA_LENGKAP, $pengirim->NIP]
                    : []
                ),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => [
                    'allowClear' => true,
                    'minimumInputLength' => 3,
                    'ajax' => [
                        'url' => Url::to(['/api-helper/id-pegawai']),
                        'delay' => 500,
                        'dataType' => 'JSON',
                        'data' => new JsExpression('function(params) { return { q:params.term }; }'),
                    ],
                    'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                    'templateResult' => new JsExpression('function(response) { return response.text; }'),
                    'templateSelection' => new JsExpression('function (response) { return response.text; }'),
                ],
            ])
            ?>

            <?= $form->field($model, 'TGL_TERIMA')->widget(DatePicker::class, [
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'options' => ['placeholder' => 'YYYY-MM-DD'],
                'pluginOptions' => ['autoclose' => true, 'format' => 'yyyy-mm-dd'],
            ]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group" style="margin-bottom: 0">
                    <?= Html::submitButton(Yii::t('app', 'Terima'), ['class' => 'btn btn-primary']) ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
