<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\UjiLab */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$this->registerCss('tr th, tr td {padding: 3px; text-align: left; vertical-align: top;}');
$this->registerCss($this->render('@backend/modules/uji/views/cetak/cetak/_style.css'));

$formatter = Yii::$app->formatter;
$uji = $model->idUji;
$agenda = $uji->idAgenda;

$this->title = 'Lembar Serah Terima CU - ' . $model->KODE;
?>
<div class="cetak portrait uji-cetak-serah-terima">
    <table style="width: 100%; border-bottom: 1px solid #000000">
        <tbody>
        <tr>
            <td valign="top" style="width: 1.74cm">
                <?= Html::img('@appUrl/img/logo-uns-350x350.png', ['style' => ['width' => '1.74cm'], 'width' => 66, 'height' => 66]); ?>
            </td>
            <td valign="top" style="text-align: center">
                <h1 style="font-size: 9pt; margin: 0;font-weight: normal; line-height: 1.2">KEMENTERIAN PENDIDIKAN DAN KEBUDAYAAN</h1>
                <h2 style="font-size: 9pt; margin: 0;font-weight: bold">UNIVERSITAS SEBELAS MARET</h2>
                <h3 style="font-size: 11pt; margin: 0;font-weight: bold; line-height: 1.2">UPT LABORATORIUM TERPADU</h3>
                <p align="center" style="font-size: 5pt">
                    Jl. Ir. Sutami 36 A Kentingan, Surakarta 57126
                    <br/>
                    Telp. <a href="tel:0271663379">0271-663379<a>, 
                    <a href="tel:0271646994"></a> 
                    psw. 398 
                    Fax. <a href="fax:0271663379">0271-663379</a>;
                    <br>
                    Email : <a href="mailto:uptlabterpadu@unit.uns.ac.id">uptlabterpadu@unit.uns.ac.id</a>
                    <br/>
                    Laman <a href="https://uptlabterpadu.uns.ac.id">uptlabterpadu.uns.ac.id</a>
                </p>
            </td>
            <td valign="top" style="text-align: center">
                <?= Html::img('@appUrl/img/logo-kan-500x206.png', ['style' => ['width' => '1.52cm'], 'width' => 57, 'height' => 24]); ?>
                <p align="center" style="font-weight: bold; font-size: 6pt">
                    Komite Akreditasi Nasional
                    <br />
                    LP-207-IDN
                    <br />
                    LK-161-IDN
                </p>
            </td>
            <td valign="top" style="font-size: 5pt">
                <p class="text-center" style="text-align: center; font-weight: bold">
                    Laboratorium Lingkungan
                    <br/>
                    SK Gubernur
                    <br/>
                    Jawa Tengah
                    <br/>
                    No. 660.1/12/2005
                </p>
                <p class="text-center" style="text-align: center; font-size: 5pt">
                    Kementerian Lingkungan Hidup
                    <br/>
                    No. Registrasi
                    <br/>
                    0016/LPJ/LABLING-1/LRK/KLH
                </p>
            </td>
        </tr>
        </tbody>
    </table>

    <h2 class="text-center text-uppercase" style="text-transform: uppercase; text-align: center; font-weight: bold; font-size: 11pt">
        <span style="text-decoration: underline">
            Lembar Serah Terima Dari Penerima Contoh Uji<br/>
            Kepada Admin Laboratorium<br/>
        </span>
        No. Agenda: <?= $agenda->KODE ?>
    </h2>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 22%;">
                Penerima Contoh Uji
            </td>
            <td class="text-center" style="width: 5pt;">:</td>
            <td><?= ArrayHelper::getValue($agenda, 'idpPenerima.NAMA_LENGKAP') ?></td>
        </tr>
        <tr>
            <td>Admin Laboratorium</td>
            <td class="text-center">:</td>
            <td><?= $model->idpKoordinator->NAMA_LENGKAP ?? null ?></td>
        </tr>
        <tr>
            <td>Tanggal Penerimaan</td>
            <td class="text-center">:</td>
            <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:l, d F Y') ?></td>
        </tr>
        </tbody>
    </table>
    <p>
        Menyerahkan contoh uji untuk dianalisis di UPT Laboratorium Terpadu UNS dengan ketentuan/parameter sebagai
        berikut:
    </p>
    <table style="width: 100%; border-collapse: collapse">
        <thead>
        <tr>
            <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
            <th style="width: 19%; border: 1px solid #000000;">Asal Contoh Uji</th>
            <th style="width: 19%; border: 1px solid #000000;">Jenis Contoh Uji</th>
            <th style="width: 19%; border: 1px solid #000000;">Jumlah Contoh Uji</th>
            <th style="width: 19%; border: 1px solid #000000;">Parameter Uji</th>
            <th style="width: 19%; text-align: center; border: 1px solid #000000;">Kode*</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
            <td style="border: 1px solid #000000;"><?= $uji->ASAL_CONTOH_UJI ?></td>
            <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
            <td style="text-align: center; border: 1px solid #000000;"><?= $uji->JUMLAH_CONTOH_UJI ?></td>
            <td style="border: 1px solid #000000;">
                <?= implode(', ', ArrayHelper::getColumn($model->dataRumusParameter, 'RUMUS')) ?>
            </td>
            <td style="text-align: center; border: 1px solid #000000;"><b><?= $model->KODE ?></b></td>
        </tr>
        </tbody>
    </table>
    <br/>
    <table style="width: 100%; border-collapse: collapse">
        <thead>
        <tr>
            <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
            <th style="width: 24%; border: 1px solid #000000;">Ketersediaan Rekaman**</th>
            <th style="width: 24%; border: 1px solid #000000;">Kemasan Contoh Uj</th>
            <th style="width: 24%; border: 1px solid #000000;">Proses Pengawetan</th>
            <th style="width: 24%; border: 1px solid #000000;">Catatan Abnormalitas</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
            <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiKetersediaan.KETERSEDIAAN') ?></td>
            <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiKemasan.KEMASAN') ?></td>
            <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiPengawetan.PENGAWETAN') ?></td>
            <td style="border: 1px solid #000000;"><?= $uji->CATATAN_ABNORMALITAS ?></td>
        </tr>
        </tbody>
    </table>
    <br/>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Dikirim Oleh: <?= $model->idpPengirim->NAMA_LENGKAP ?? null ?><br/>
                Paraf:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Tanggal: <?= Yii::$app->formatter->asDate($model->TGL_TERIMA, 'php:l, d F Y') ?><br/>
                Waktu:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Diterima Oleh: <?= $model->idpPenerima->NAMA_LENGKAP ?? null ?><br/>
                Paraf:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
        </tr>
        </tbody>
    </table>
    <p>Dibuat rangkap dua:</p>
    <ul type="-" style="padding-left: 20px">
        <li>Lembar pertama untuk penerima contoh uji</li>
        <li>Lembar kedua untuk koordinator analis</li>
    </ul>
</div>
