<?php


/* @var $this yii\web\View */
/* @var $model common\models\simlab\UjiLab */

$this->title = Yii::t('app', 'Serah Terima Contoh Uji');
$this->params['breadcrumbs'][] = ['label' => 'Dashboard Serah Terima', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uji-lab-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
