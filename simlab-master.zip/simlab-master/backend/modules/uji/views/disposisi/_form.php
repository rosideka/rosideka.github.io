<?php

use common\models\simlab\Pegawai;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $dataUjiParameter common\models\simlab\UjiParameter[] */

$formatter = Yii::$app->formatter;
$mapPenguji = Pegawai::map('ID', 'CONCAT("NAMA_LENGKAP", \' - \', "NIP")');
?>
<div class="uji-parameter-form">
    <?php $form = ActiveForm::begin(); ?>

    <?php foreach ($dataUjiParameter as $i => $ujiParameter) { ?>
        <?php
        $uji = $ujiParameter->idUji;
        $isFirst = $i === array_key_first($dataUjiParameter);
        ?>
        <div class="box box-success box-solid uji-item">
            <div class="box-header" data-toggle="collapse" data-target="#cu-param-<?= $i ?>" style="cursor: pointer">
                <h4 class="box-title">
                    <?= implode(' - ', [$ujiParameter->idUjiLab->KODE, '(' . $ujiParameter->RUMUS . ') ' . $ujiParameter->NAMA]) ?>
                </h4>
            </div>
            <div id="cu-param-<?= $i ?>" class="panel-body collapse<?= $isFirst ? ' in' : '' ?>">
                <table class="table table-bordered table-striped table-condensed">
                    <thead>
                    <tr>
                        <th style="width: 20%;"><?= Yii::t('app', 'Kode Uji Lab') ?></th>
                        <th style="width: 20%;"><?= Yii::t('app', 'Parameter') ?></th>
                        <th style="width: 20%;"><?= Yii::t('app', 'Lab') ?></th>
                        <th style="width: 20%;"><?= Yii::t('app', 'Baku Mutu') ?></th>
                        <th style="width: 20%;"><?= Yii::t('app', 'Metode Uji') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?= $ujiParameter->idUjiLab->KODE ?? '-' ?></td>
                        <td><?= '(' . Html::decode($ujiParameter->RUMUS) . ') ' . $ujiParameter->NAMA ?></td>
                        <td><?= $ujiParameter->idLab->NAMA ?? '-' ?></td>
                        <td><?= $ujiParameter->idBakuMutu->NAMA_BAKU_MUTU ?? '-' ?></td>
                        <td><?= $ujiParameter->idMetodeUji->NAMA_METODE ?? '-' ?></td>
                    </tr>
                    </tbody>
                </table>
                <?= $form->field($ujiParameter, "[{$i}]ID_PENGUJI")->widget(Select2::class, [
                    'data' => $mapPenguji,
                    'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                    'pluginOptions' => ['allowClear' => true],
                ]) ?>

            </div>
        </div>
    <?php } ?>

    <?php if ($pks = Yii::$app->request->post('pks')) { ?>
        <?= Html::hiddenInput('pks', $pks); ?>
    <?php } ?>

    <?php if (!Yii::$app->request->isAjax) { ?>
        <div class="form-group">
            <?= Html::submitButton(Yii::t('app', 'Simpan'), ['class' => 'btn btn-primary']) ?>
        </div>
    <?php } ?>

    <?php ActiveForm::end(); ?>
</div>
