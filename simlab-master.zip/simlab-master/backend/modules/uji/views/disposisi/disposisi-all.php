<?php

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiParameter common\models\simlab\UjiParameter[] */

$this->title = Yii::t('app', 'Disposisi Uji Parameter');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Disposisi'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uji-create">
    <?= $this->render('_form', [
        'dataUjiParameter' => $dataUjiParameter,
    ]) ?>
</div>
