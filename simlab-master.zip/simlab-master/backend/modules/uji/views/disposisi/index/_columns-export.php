<?php

/* @var $searchModel \backend\modules\uji\models\DisposisiSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_AGENDA',
        'label' => Yii::t('app', 'ID Agenda'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_AGENDA',
        'label' => $searchModel->getAttributeLabel('KODE_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_LAB',
        'label' => Yii::t('app', 'ID Uji Lab'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI_LAB',
        'label' => $searchModel->getAttributeLabel('KODE_UJI_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS',
        'label' => $searchModel->getAttributeLabel('RUMUS'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PAKET',
        'label' => Yii::t('app', 'ID Paket'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PAKET',
        'label' => $searchModel->getAttributeLabel('PAKET'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_BAKU_MUTU',
        'label' => Yii::t('app', 'ID Baku Mutu'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('BAKU_MUTU'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_METODE_UJI',
        'label' => Yii::t('app', 'ID Metode Uji'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'METODE_UJI',
        'label' => $searchModel->getAttributeLabel('METODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PENGUJI',
        'label' => Yii::t('app', 'ID Penguji'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PENGUJI',
        'label' => $searchModel->getAttributeLabel('PENGUJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_DISPOSISI',
        'label' => $searchModel->getAttributeLabel('TANGGAL_DISPOSISI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_ANALISIS',
        'label' => $searchModel->getAttributeLabel('TANGGAL_ANALISIS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_SELESAI',
        'label' => $searchModel->getAttributeLabel('TANGGAL_SELESAI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KETERANGAN',
        'label' => $searchModel->getAttributeLabel('KETERANGAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_STATUS_PARAMETER',
        'label' => Yii::t('app', 'ID Status Parameter'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_PARAMETER',
        'label' => $searchModel->getAttributeLabel('STATUS_PARAMETER'),
    ],
];
