<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

echo DetailView::widget([
    'model' => $model,
    'options' => [
        'class' => 'table table-striped table-bordered detail-view',
        'style' => 'margin-bottom: 0',
    ],
    'attributes' => [
        [
            'attribute' => 'LAB',
            'captionOptions' => ['style' => 'width: 33.33%'],
        ],
        'PAKET',
        'STATUS_PARAMETER',
        'TANGGAL_DISPOSISI',
        'TANGGAL_ANALISIS',
        'TANGGAL_SELESAI',
        'KETERANGAN',
    ],
]);
