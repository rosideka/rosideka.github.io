<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\Html;

?>
<table style="width: 100%; border-bottom: 1px solid #000000">
    <tbody>
    <tr>
        <td valign="top" style="width: 1.74cm">
            <?= Html::img('@appUrl/img/logo-uns-350x350.png', ['style' => ['width' => '1.74cm'], 'width' => 66, 'height' => 66]); ?>
        </td>
        <td valign="top" style="text-align: center">
            <h1 style="font-size: 9pt; margin: 0;font-weight: normal; line-height: 1.2">KEMENTERIAN PENDIDIKAN DAN KEBUDAYAAN</h1>
            <h2 style="font-size: 9pt; margin: 0;font-weight: bold">UNIVERSITAS SEBELAS MARET</h2>
            <h3 style="font-size: 11pt; margin: 0;font-weight: bold; line-height: 1.2">UPT LABORATORIUM TERPADU</h3>
            <p align="center" style="font-size: 5pt">
                Jl. Ir. Sutami 36 A Kentingan, Surakarta 57126
                <br/>
                Telp. <a href="tel:0271663379">0271-663379<a>, 
                <a href="tel:0271646994"></a> 
                psw. 398 
                Fax. <a href="fax:0271663379">0271-663379</a>;
                <br>
                Email : <a href="mailto:uptlabterpadu@unit.uns.ac.id">uptlabterpadu@unit.uns.ac.id</a>
                <br/>
                Laman <a href="https://uptlabterpadu.uns.ac.id">uptlabterpadu.uns.ac.id</a>
            </p>
        </td>
        <td valign="top" style="text-align: center">
            <?= Html::img('@appUrl/img/logo-kan-500x206.png', ['style' => ['width' => '1.52cm'], 'width' => 57, 'height' => 24]); ?>
            <p align="center" style="font-weight: bold; font-size: 6pt">
                Komite Akreditasi Nasional
                <br />
                LP-207-IDN
                <br />
                LK-161-IDN
            </p>
        </td>
        <td valign="top" style="font-size: 5pt">
            <p class="text-center" style="text-align: center; font-weight: bold">
                Laboratorium Lingkungan
                <br/>
                SK Gubernur
                <br/>
                Jawa Tengah
                <br/>
                No. 660.1/12/2005
            </p>
            <p class="text-center" style="text-align: center; font-size: 5pt">
                Kementerian Lingkungan Hidup
                <br/>
                No. Registrasi
                <br/>
                0016/LPJ/LABLING-1/LRK/KLH
            </p>
        </td>
    </tr>
    </tbody>
</table>
