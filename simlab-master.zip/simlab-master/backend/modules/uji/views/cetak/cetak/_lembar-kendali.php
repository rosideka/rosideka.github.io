<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

/* @var $this yii\web\View */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$this->registerCss('tr th, tr td {padding: 3px; text-align: left; vertical-align: top;}');

$formatter = Yii::$app->formatter;
$member = $agenda->idMember;
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();

$this->title = $agenda->KODE . ' - KESEPAKATAN PELAKSANAAN PENGUJIAN';
?>
<div class="uji-cetak-kesepakatan">
    <h2 class="text-center text-uppercase" style="text-transform: uppercase; text-align: center; font-weight: bold; font-size: 11pt; text-decoration: underline">
        Lembar Kendali Contoh Uji
    </h2>
    <br/>
    <table style="width: 100%; border-collapse: collapse">
        <tr>
            <td style="width: 20%">Tgl. Terima</td>
            <td style="width: 3%; text-align: left">:</td>
            <td style="width: 60%"></td>
            <td style="width: 20%">No. Agenda</td>
            <td style="width: 3%; text-align: left">:</td>
            <td><?= $agenda->KODE ?></td>
        </tr>
        <tr>
            <td>Asal Contoh Uji</td>
            <td>:</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </table>
    <br />
    <table style="width: 100%; border-collapse: collapse">
        <thead>
        <tr style="background: #f0f0f0">
            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 3%; border: 1px solid #000000;">No.</th>
            <th rowspan="2" colspan="2" style="text-align: center; vertical-align: middle; width: 20%; border: 1px solid #000000;">Kegiatan</th>
            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 10%;  border: 1px solid #000000;">Tanggal</th>
            <th colspan="2" style="text-align: center; vertical-align: middle; border: 1px solid #000000;">Penanggung Jawab</th>
            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 20%; border: 1px solid #000000;">Catatan</th>
        </tr>
        <tr style="background: #f0f0f0"">
            <th style="text-align: center; vertical-align: middle; width: 20%; border: 1px solid #000000;">Jabatan</th>
            <th style="text-align: center; vertical-align: middle; width: 20%; border: 1px solid #000000;">Nama</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">1.</td>
            <td colspan="2" style="; border: 1px solid #000000;">Penyerahan / pengambilan contoh uji*)</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Admin Pengujian / Petugas Sampling</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">2.</td>
            <td colspan="2" style="border: 1px solid #000000;">Coding/pemberian kode</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Admin Pengujian</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">3.</td>
            <td colspan="2" style="border: 1px solid #000000;">Analisis laboratorium</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Admin Laboratorium (Pembagian analis dan monitoring)</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">4.</td>
            <td colspan="2" style="border: 1px solid #000000;">Pengetikan draft hasil</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Analis</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">5.</td>
            <td colspan="2" style="border: 1px solid #000000;">Pemeriksaan draft hasil</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Penyelia</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">6.</td>
            <td colspan="2" style="border: 1px solid #000000;">Perbaikan hasil</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Analis</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">7.</td>
            <td colspan="2" style="border: 1px solid #000000;">Recoding</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Analis</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">8.</td>
            <td colspan="2" style="border: 1px solid #000000;">Pemeriksaan hasil</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td style="border-left: 1px solid #000000; border-right: 1px solid #000000;"></td>
            <td style="width: 5px; border-right: none;">-</td>
            <td style="border-left: none;">Kimia</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Mantek/Penyelia</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td style="border-left: 1px solid #000000; border-right: 1px solid #000000;"></td>
            <td style="border-right: none;">-</td>
            <td style="border-left: none;">Biologi</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Mantek/Penyelia</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td style="border-left: 1px solid #000000; border-right: 1px solid #000000;"></td>
            <td style="border-right: none;">-</td>
            <td style="border-left: none;">Udara</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Mantek/Penyelia</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">9.</td>
            <td colspan="2" style="border: 1px solid #000000;">SHP</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Admin Pengujian</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        <tr>
            <td class="text-center" style="text-align: center; border: 1px solid #000000;">10.</td>
            <td colspan="2" style="border: 1px solid #000000;">Tanda tangan hasil (SHP)</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;">Ka UPT</td>
            <td style="border: 1px solid #000000;"></td>
            <td style="border: 1px solid #000000;"></td>
        </tr>
        </tbody>
    </table>
    <br/>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td colspan="3">*) Coret salah satu</td>
        </tr>
        <tr>
            <td style="width: 15%">Penyerahan</td>
            <td width="10pt">:</td>
            <td>Hasil uji ini berdasarkan contoh uji yang masuk</td>
        </tr>
        <tr>
            <td>Pengambilan</td>
            <td>:</td>
            <td>Laboratorium bertanggung jawab atas kesalahan</td>
        </tr>
        </tbody>
    </table>
</div>
