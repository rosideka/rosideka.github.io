<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$this->registerCss('tr th, tr td {padding: 3px; text-align: left; vertical-align: top;}');

$formatter = Yii::$app->formatter;
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();

$this->title = $agenda->KODE . ' - BA PENGAMBILAN CONTOH UJI';
?>
<div class="uji-cetak-serah-terima">
    <h2 class="text-center text-uppercase" style="text-transform: uppercase; text-align: center; font-weight: bold; font-size: 11pt">
        <span style="text-decoration: underline">
            Lembar Serah Terima Dari Penerima Contoh Uji<br/>
            Kepada Admin Laboratorium<br/>
        </span>
        No. Agenda: <?= $agenda->KODE ?>
    </h2>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 22%;">
                Penerima Contoh Uji
            </td>
            <td class="text-center" style="width: 5pt;">:</td>
            <td><?= ArrayHelper::getValue($agenda, 'idpPenerima.NAMA_LENGKAP') ?></td>
        </tr>
        <tr>
            <td>Admin Laboratorium</td>
            <td class="text-center">:</td>
            <td></td>
        </tr>
        <tr>
            <td>Tanggal Penerimaan</td>
            <td class="text-center">:</td>
            <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:l, d F Y') ?></td>
        </tr>
        </tbody>
    </table>

    <?php if ($dataUjiDiterima) { ?>
        <p>
            Menyerahkan contoh uji untuk dianalisis di UPT Laboratorium Terpadu UNS dengan ketentuan/parameter sebagai
            berikut:
        </p>
        <table style="width: 100%; border-collapse: collapse">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
                <th style="width: 19%; border: 1px solid #000000;">Asal Contoh Uji</th>
                <th style="width: 19%; border: 1px solid #000000;">Jenis Contoh Uji</th>
                <th style="width: 19%; border: 1px solid #000000;">Jumlah Contoh Uji</th>
                <th style="width: 19%; border: 1px solid #000000;">Parameter Uji</th>
                <th style="width: 19%; text-align: center; border: 1px solid #000000;">Kode*</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <tr>
                    <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
                    <td style="border: 1px solid #000000;"><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td style="text-align: center; border: 1px solid #000000;"><?= $uji->JUMLAH_CONTOH_UJI ?></td>
                    <td style="border: 1px solid #000000;"><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                    <td style="text-align: center; border: 1px solid #000000;"><b><?= $uji->KODE ?></b></td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
        <br/>
        <table style="width: 100%; border-collapse: collapse">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
                <th style="width: 24%; border: 1px solid #000000;">Ketersediaan Rekaman**</th>
                <th style="width: 24%; border: 1px solid #000000;">Kemasan Contoh Uj</th>
                <th style="width: 24%; border: 1px solid #000000;">Proses Pengawetan</th>
                <th style="width: 24%; border: 1px solid #000000;">Catatan Abnormalitas</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <tr>
                    <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
                    <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiKetersediaan.KETERSEDIAAN') ?></td>
                    <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiKemasan.KEMASAN') ?></td>
                    <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idUjiPengawetan.PENGAWETAN') ?></td>
                    <td style="border: 1px solid #000000;"><?= $uji->CATATAN_ABNORMALITAS ?></td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
    <?php } ?>
    <br/>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Dikirim Oleh:<br/>
                Paraf:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Tanggal:<br/>
                Waktu:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
            <td style="width: 33.33%; border: 1px solid #000000;">
                Diterima Oleh:<br/>
                Paraf:
                <br/>
                <br/>
                <br/>
                <br/>
            </td>
        </tr>
        </tbody>
    </table>

    <p>Dibuat rangkap dua:</p>
    <ul type="-" style="padding-left: 20px">
        <li>Lembar pertama untuk penerima contoh uji</li>
        <li>Lembar kedua untuk koordinator analis</li>
    </ul>
</div>
