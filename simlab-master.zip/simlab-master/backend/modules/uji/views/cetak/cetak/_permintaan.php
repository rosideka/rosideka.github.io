<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $uji common\models\simlab\Uji */
/* @var $umFront yii\web\UrlManager */

$this->registerCss('tr th, tr td {padding: 3px; text-align: left; vertical-align: top;}');

$formatter = Yii::$app->formatter;
$member = $agenda->idMember;
$umFront = Yii::$app->get('umFront');

$this->title = $agenda->KODE . ' - PERMINTAAN PENGUJIAN';
?>
<div class="uji-cetak-permintaan">
    <h2 style="font-weight: bold; font-size: 11pt; text-align: center; text-transform: uppercase">
        <span style="text-transform: uppercase; text-decoration: underline">
            <?= Yii::t('app', 'Permintaan Pengujian') ?><br/>
        </span>
        <?= Yii::t('app', 'No. Agenda: ') . $agenda->KODE ?>
    </h2>
    <p>Yang bertanda tangan dibawah ini:</p>

    <?php if ($member->ID_JENIS_MEMBER == 2) { ?>
        <table style="width: 100%; border-collapse: collapse">
            <tbody>
            <tr>
                <td style="width: 30%;">Nama Instansi/Perusahaan</td>
                <td style=" width: 15px;">:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Penanggung Jawab</td>
                <td>:</td>
                <td><?= $agenda->NAMA_PJ ?></td>
            </tr>
            <tr>
                <td>Alamat Instansi/Perusahaan</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp./Fax</td>
                <td>:</td>
                <td><?= $agenda->TELP ?>/<?= $agenda->FAX ?></td>
            </tr>
            </tbody>
        </table>
    <?php } else { ?>
        <table style="width: 100%; border-collapse: collapse">
            <tbody>
            <tr>
                <td style="width: 25%;">Nama</td>
                <td>:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp</td>
                <td>:</td>
                <td><?= $agenda->TELP ?></td>
            </tr>
            </tbody>
        </table>
    <?php } ?>

    <br/>

    <?php foreach ($agenda->getDataUji()->orderBy(['ID' => SORT_ASC])->all() as $i => $uji) { ?>
        <table style="width: 100%; border-collapse: collapse">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
                <th style="width: 24%; border: 1px solid #000000;">Asal Contoh Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Jenis Contoh Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Parameter Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Klasifikasi Lokasi</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
                <td style="border: 1px solid #000000;"><?= $uji->ASAL_CONTOH_UJI ?></td>
                <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                <td style="border: 1px solid #000000;"><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                <td style="border: 1px solid #000000;"><?= $uji->KLASIFIKASI_LOKASI ?></td>
            </tr>
            <tr>
                <td colspan="5" style="border: 1px solid #000000;">
                    Baku Mutu: <?= ArrayHelper::getValue($uji, 'idBakuMutu.NAMA_BAKU_MUTU') ?>
                </td>
            </tr>
            </tbody>
        </table>
        <br>
    <?php } ?>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 30%;">Tanggal Permohonan</td>
            <td style="width: 15px;">:</td>
            <td><?= $formatter->asDate($agenda->TANGGAL_PERMOHONAN, 'php:l, d F Y') ?></td>
        </tr>
        <tr>
            <td >Pihak Pengambil</td>
            <td >:</td>
            <td ><?= ArrayHelper::getValue($agenda, 'idPihakPengambil.PIHAK_PENGAMBIL') ?></td>
        </tr>
        </tbody>
    </table>
    <p>
        Demikian permintaan pengujian ini saya buat, atas kerjasama yang baik saya mengucapkan terima kasih.
    </p>
   <table style="width: 100%;" class="table no-border table-condensed">
        <tbody>
        <tr>
            <td style="width: 65%; vertical-align: middle; text-align: center">
                <?= Html::img(
                    $umFront->createAbsoluteUrl(['/api/qr-code', 'label' => $agenda->KODE, 'text' => $agenda->KODE]),
                    ['width' => '95', 'height' => '126']
               ) ?>
            </td>
            <td>
                <?= $agenda->TEMPAT_PERMOHONAN ?>,
                <?= $formatter->asDate($agenda->TANGGAL_PERMOHONAN, 'php:d F Y') ?>
                <br/>
                Penanggung Jawab
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $member->ID_JENIS_MEMBER === 1 ? $agenda->NAMA : $agenda->NAMA_PJ ?>
            </td>
        </tr>
        </tbody>
    </table>
    <p>
        Pernyataan:
        <br>
        Data yang saya sampaikan dalam Permintaan ini adalah benar dan menjadi dasar dalam penerbitan Sertifikat Hasil
        Pengujian.
    </p>
    <table style="width: 100%;" class="table no-border table-condensed">
        <tbody>
        <tr>
            <td style="width: 65%; vertical-align: middle; text-align: center">
                <?= Html::img(
                    $umFront->createAbsoluteUrl(['/api/qr-code', 'label' => $agenda->KODE, 'text' => $agenda->KODE]),
                    ['width' => '95', 'height' => '126']
                ) ?>
            </td>
            <td>
                <?= $agenda->TEMPAT_PERMOHONAN ?>,
                <?= $formatter->asDate($agenda->TANGGAL_PERMOHONAN, 'php:d F Y') ?>
                <br/>
                Penanggung Jawab
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $member->ID_JENIS_MEMBER === 1 ? $agenda->NAMA : $agenda->NAMA_PJ ?>
            </td>
        </tr>
        </tbody>
    </table>
</div>
