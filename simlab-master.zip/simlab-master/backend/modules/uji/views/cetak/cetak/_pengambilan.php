<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use common\models\eis\PegawaiRiwayatJabKelola;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$this->registerCss('tr th, tr td {padding: 3px; text-align: left; vertical-align: top;}');

$formatter = Yii::$app->formatter;
$kaUpt = PegawaiRiwayatJabKelola::findByJabatan(250, $agenda->TANGGAL_PERMOHONAN)->one();
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();

$this->title = $agenda->KODE . ' - BA PENGAMBILAN CONTOH UJI';
?>
<div class="uji-cetak-kesepakatan">
    <h2 class="text-center text-uppercase" style="text-align: center; text-transform: uppercase; font-weight: bold; font-size: 11pt">
        <span style="text-decoration: underline">
             Berita Acara Pengambilan Contoh Uji<br/>
        </span>
        No. Agenda: <?= $agenda->KODE ?>
    </h2>
    <p>Yang bertandatangan di bawah ini:</p>
    <table style="width: 100%; border-collapse: collapse">
        <tbody>
        <tr>
            <td style="width: 100pt;">
                Nama
            </td>
            <td class="text-center" style="width: 5pt;">:</td>
            <td>
                <ol type="1" style="padding-left: 15px; margin-top: 1px">
                    <li>…………………………</li>
                    <li>…………………………</li>
                </ol>
            </td>
        </tr>
        <tr>
            <td>Tanggal</td>
            <td class="text-center">:</td>
            <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:l, d F Y') ?></td>
        </tr>
        </tbody>
    </table>
    <p>
        Mengambil contoh uji dari <?= $agenda->NAMA ?> untuk dianalisis di UPT Laboratorium Terpadu UNS, dengan
        penentuan titik sampling yang dilakukan oleh pihak <b>Perusahaan/Konsumen/Konsultan/UPT Lab Terpadu UNS</b>*.
    </p>

    <?php if ($dataUjiDiterima) { ?>
        <table style="width: 100%; border-collapse: collapse">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
                <th style="width: 24%; border: 1px solid #000000;">Asal Contoh Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Jenis Contoh Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Parameter Uji</th>
                <th style="width: 24%; border: 1px solid #000000;">Klasifikasi Lokasi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <?php $rekomendasi = $uji->idRekomendasi; ?>
                <tr>
                    <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
                    <td style="border: 1px solid #000000;"><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td style="border: 1px solid #000000;"><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td style="border: 1px solid #000000;"><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                    <td style="border: 1px solid #000000;"><?= $uji->KLASIFIKASI_LOKASI ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <br />
        <table style="width: 100%; border-collapse: collapse">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center; border: 1px solid #000000;">#CU</th>
                <th style="width: 48%; border: 1px solid #000000;">Keterangan Lokasi</th>
                <th style="width: 24%; border: 1px solid #000000;">Kode</th>
                <th style="width: 24%; border: 1px solid #000000;">Jam</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <tr>
                    <td style="text-align: center; border: 1px solid #000000;"><?= $uji->NO_CU ?></td>
                    <td style="border: 1px solid #000000;"></td>
                    <td style="border: 1px solid #000000;"><?= $uji->KODE ?></td>
                    <td style="border: 1px solid #000000;"></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } ?>

    <p>Pengambil Contoh Uji:</p>
    <ol type="1">
        <li>_____________</li>
        <li>_____________</li>
    </ol>
    <p>Saksi dari pihak konsumen:</p>
    <ol type="1">
        <li>_____________</li>
        <li>_____________</li>
    </ol>
    <p>Dinas/Masyarakat terkait**:</p>
    <ol type="1">
        <li>_____________</li>
        <li>_____________</li>
    </ol>
    <br/>
    <table class="table no-border table-condensed">
        <tbody>
        <tr>
            <td style="width: 60%; vertical-align: middle; text-align: center">
            </td>
            <td>
                <?= $formatter->asText($agenda->TEMPAT_PERMOHONAN) ?>,
                <?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:d F Y') ?>
                <br/>
                Kepala UPT Lab Terpadu UNS
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $kaUpt->NAMA_LENGKAP ?>
            </td>
        </tr>
        </tbody>
    </table>
    <p>Keterangan:</p>
    <table class="table table-condensed no-border">
        <tbody>
        <tr>
            <td>*</td>
            <td>
                Coret yang tidak perlu.<br>
                Jika penentuan titik sampling dilakukan oleh pihak perusahaan/Konsumen/Konsultan maka Lab Terpadu UNS tidak bertanggung jawab terhadap keabsahan dan kesesuaian hasil uji sampel.
            </td>
        </tr>
        <tr>
            <td>**</td>
            <td>
                Sosialisasi adanya pengambilan Contoh Uji di suatu tempat kepada masyarakat sekitarnya merupakan tanggung jawab pelanggan.
            </td>
        </tr>
        </tbody>
    </table>
</div>
