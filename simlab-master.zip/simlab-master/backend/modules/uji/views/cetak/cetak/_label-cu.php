<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$formatter = Yii::$app->formatter;
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();

$this->registerCss('.uji-cetak-label-cu .label-wrap + .label-wrap, .uji-cetak-label-cu .page-break + .label-wrap{margin-top: 29px !important}');
$this->registerCss('@media print {.uji-cetak-label-cu .page-break + .label-wrap{margin-top: 0 !important}');

$this->title = $agenda->KODE . ' - LABEL CONTOH UJI';
?>
<div class="uji-cetak-label-cu">

    <?php if ($dataUjiDiterima) { ?>

        <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
            <div class="label-wrap" style="width: 522px; height: 328px; margin: 0 auto; padding: 10px; border: 1px solid #000000">
                <h2 class="text-center text-uppercase" style="font-weight: bold; font-size: 11pt; margin-top: 0">
                    <span style="text-transform: uppercase; text-decoration: underline">
                         Label Contoh Uji<br/>
                    </span>
                    No. Agenda: <?= $agenda->KODE ?>
                </h2>
                <br/>
                <table class="table table-condensed no-border">
                    <tbody>
                    <tr>
                        <td style="width: 100pt">Kode Contoh Uji</td>
                        <td style="width: 5px">:</td>
                        <td><?= $uji->KODE ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Contoh Uji</td>
                        <td>:</td>
                        <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Masuk</td>
                        <td>:</td>
                        <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php: l, d F Y') ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Kadaluarsa</td>
                        <td>:</td>
                        <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php: l, d F Y') ?></td>
                    </tr>
                    </tbody>
                </table>
                <table class="table table-condensed no-border">
                    <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center; width: 30%">
                            <span style="font-size: 72pt; line-height: 72pt">2</span>
                            <br>
                            Kode Retensi
                        </td>
                        <td style="width: 50%">

                        </td>
                        <td style="width:40%;">
                            Penerima Contoh Uji
                            <br/>
                            <br/>
                            <br/>
                            ______________________
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <?php
            if ($i % 3 === 2) {
                echo Html::tag('div', '', ['class' => 'page-break']);
            }
            ?>
        <?php } ?>
    <?php } ?>

</div>
