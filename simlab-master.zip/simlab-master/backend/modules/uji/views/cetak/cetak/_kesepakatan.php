<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use common\models\eis\PegawaiRiwayatJabKelola;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */

$formatter = Yii::$app->formatter;
$member = $agenda->idMember;
$kaUpt = PegawaiRiwayatJabKelola::findByJabatan(250, $agenda->TANGGAL_PERMOHONAN)->one();
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();

$this->title = $agenda->KODE . ' - KESEPAKATAN PELAKSANAAN PENGUJIAN';
?>
<div class="uji-cetak-kesepakatan">
    <h2 class="text-center text-uppercase" style="font-weight: bold; font-size: 11pt">
        Kesepakatan Pelaksanaan Pengujian dan/atau Pengambilan Contoh Uji
    </h2>
    <br/>
    <p>
        UPT Laboratorium Terpadu UNS sebagai PIHAK PERTAMA akan melakukan pengujian dan/atau pengambilan contoh uji
        sebagaimana tertulis pada agenda No. <?= $agenda->KODE ?> untuk pelanggan sebagai PIHAK KEDUA dengan identitas
        di bawah ini:
    </p>

    <?php if ($member->ID_JENIS_MEMBER == 2) { ?>
        <table width="100%">
            <tbody>
            <tr>
                <td style="width: 25%">Nama Instansi/Perusahaan</td>
                <td>:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Penanggung Jawab</td>
                <td>:</td>
                <td><?= $agenda->NAMA_PJ ?></td>
            </tr>
            <tr>
                <td>Alamat Instansi/Perusahaan</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp./Fax</td>
                <td>:</td>
                <td><?= $agenda->TELP ?>/<?= $agenda->FAX ?></td>
            </tr>
            </tbody>
        </table>
    <?php } else { ?>
        <table width="100%">
            <tbody>
            <tr>
                <td style="width: 25%">Nama</td>
                <td>:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp</td>
                <td>:</td>
                <td><?= $agenda->TELP ?></td>
            </tr>
            </tbody>
        </table>
    <?php } ?>

    <br/>
    <p>Dengan informasi terkait Contoh Uji:</p>

    <?php if ($dataUjiDiterima) { ?>
        <table class="table table-bordered table-condensed">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center;">#CU</th>
                <th style="width: 24%;">Asal Contoh Uji</th>
                <th style="width: 24%;">Jenis Contoh Uji</th>
                <th style="width: 24%;">Parameter Uji</th>
                <th style="width: 24%;">Klasifikasi Lokasi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <tr>
                    <td style="text-align: center;"><?= $uji->NO_CU ?></td>
                    <td><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                    <td><?= $uji->KLASIFIKASI_LOKASI ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } ?>

    <table class="table table-condensed no-border">
        <tr>
            <td style="width: 40%;">Tanggal penyerahan/Pengambilan contoh uji</td>
            <td style="width: 5px;">:</td>
            <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:l, d F Y') ?></td>
        </tr>
        <tr>
            <td>Pihak pengambil contoh uji</td>
            <td>:</td>
            <td><?= ArrayHelper::getValue($agenda, 'idPihakPengambil.PIHAK_PENGAMBIL', '-') ?></td>
        </tr>
    </table>

    <p>Ketentuan tambahan dalam kesepakatan ini ditetapkan dalam berita acara penyerahan Contoh Uji dan/atau berita
        acara pengambilan Contoh Uji</p>

    <p>Biaya yang timbul dari kesepakatan ini dibebankan kepada PIHAK KEDUA sebagaimana tertulis dalam invoice yang
        merupakan bagian tidak terpisahkan dari kesepakatan ini.</p>

    <p>Demikian kesepakatan ini, kami buat bersama dengan sebenarnya untuk dilaksanakan sebagaimana mestinya.</p>

    <table class="table table-condensed no-border">
        <tbody>
        <tr>
            <td style="width: 50%">
                <br/>
                PIHAK KEDUA
                <br/>
                Pelanggan
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $member->ID_JENIS_MEMBER === 1 ? $agenda->NAMA : $agenda->NAMA_PJ ?>
            </td>
            <td>
                <?= $agenda->TEMPAT_PERMOHONAN ?>,
                <?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:d F Y') ?>
                <br/>
                PIHAK PERTAMA
                <br/>
                Kepala UPT Lab Terpadu UNS
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $kaUpt->NAMA_LENGKAP ?>
            </td>
        </tr>
        </tbody>
    </table>
</div>
