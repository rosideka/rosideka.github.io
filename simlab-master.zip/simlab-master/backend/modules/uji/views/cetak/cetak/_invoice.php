<?php
/**
 * @link https://simpeg.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $member common\models\simlab\Member */
/* @var $umFront yii\web\UrlManager */

$this->registerCss('@media {.invoice-col {width: 50%;}');

$formatter = Yii::$app->formatter;
$member = $agenda->idMember;
$user = $member->idUser;
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();
$dataUjiDitolak = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 2])->orderBy(['ID' => SORT_ASC])->all();
$umFront = Yii::$app->get('umFront');

$this->title = $agenda->KODE . ' - INVOICE';
?>
<div class="uji-cetak-invoice">
    <h2 class="text-center text-uppercase" style="font-weight: bold; font-size: 11pt">
        <span class="text-uppercase" style="text-decoration: underline">
            Invoice<br/>
        </span>
        No. Agenda: <?= $agenda->KODE ?>
    </h2>
    <table class="table no-border table-condensed">
        <tbody>
        <tr>
            <th colspan="2">Dari</th>
            <th colspan="2">Kepada</th>
        </tr>
        <tr>
            <th style="width: 7%">Nama</th>
            <td style="width: 43%;">UPT Lab Terpadu UNS</td>
            <th style="width: 7%">Nama</th>
            <td style="width: 43%;"><?= $agenda->NAMA ?></td>
        </tr>
        <tr>
            <th>Alamat</th>
            <td>A Kentingan, Jl. Ir Sutami No.36, Jebres, Kec. Jebres, Kota Surakarta, Jawa Tengah 57126</td>
            <th>Alamat</th>
            <td><?= $agenda->ALAMAT ?></td>
        </tr>
        <tr>
            <th>Telp</th>
            <td><a href="tel:0271663379">(0271) 663379</a></td>
            <th>Telp</th>
            <td><a href="tel:<?= $agenda->TELP ?>"><?= $agenda->TELP ?></a></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?= $formatter->asEmail('uptlabterpadu@unit.uns.ac.id') ?></td>
            <th>Email</th>
            <td><?= $formatter->asEmail($user->EMAIL) ?></td>
        </tr>
        </tbody>
    </table>

    <?php if ($dataUjiDiterima) { ?>
        <?php if ($agenda->ID_STATUS_UJI != 1) { ?>
            <h2 class="h5 text-uppercase" style="margin-bottom: 0">Diterima</h2>
        <?php } ?>

        <table class="table table-striped table-condensed">
            <thead>
            <tr>
                <th>#</th>
                <th>Contoh Uji</th>
                <th>Paket</th>
                <th class="text-right">Biaya</th>
                <th class="text-right" style="white-space: nowrap">Biaya Ambil</th>
                <th class="text-right">Diskon</th>
                <th class="text-right">Subtotal</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataUjiDiterima as $iu => $uji) { ?>
                <tr>
                    <td><?= $iu + 1 ?></td>
                    <td><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->BIAYA) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->BIAYA_AMBIL) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->DISKON) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->TOTAL_BIAYA) ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } ?>

    <?php if ($dataUjiDitolak) { ?>
        <h2 class="h5 text-uppercase" style="margin-bottom: 0">Ditolak</h2>
        <table class="table table-striped table-condensed">
            <thead>
            <tr>
                <th>#</th>
                <th>Contoh Uji</th>
                <th>Paket</th>
                <th class="text-right">Biaya</th>
                <th class="text-right" style="white-space: nowrap">Biaya Ambil</th>
                <th class="text-right">Diskon</th>
                <th class="text-right">Subtotal</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataUjiDitolak as $iu => $uji) { ?>
                <tr>
                    <td><?= $iu + 1 ?></td>
                    <td><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->BIAYA) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->BIAYA_AMBIL) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->DISKON) ?></td>
                    <td class="text-right"><?= $formatter->asCurrency($uji->TOTAL_BIAYA) ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } ?>

    <div class="row">
        <div class="col-xs-6">
            <?php if ($agenda->NO_VA_PEMBAYARAN) { ?>
                <div class="text-center" style="vertical-align: middle">
                    <?= Html::img(
                        $umFront->createAbsoluteUrl(['/api/qr-invoice', 'text' => $agenda->NO_VA_PEMBAYARAN, 'label' => $agenda->NO_VA_PEMBAYARAN]),
                        ['style' => ['width' => '100px']]
                    ) ?>
                    <p><?= Yii::t('app', 'NOMOR VA') ?><br/><?= $agenda->NO_VA_PEMBAYARAN ?></p>
                </div>
            <?php } else { ?>
                <p style="font-weight: bold">
                    Catatan: Pembayaran dapat dilakukan setelah informasi 
                    billing virtual account disampaikan
                </p>
            <?php } ?>
        </div>
        <div class="col-xs-6">
            <div class="table-responsive">
                <table class="table">
                    <tbody>
                    <tr>
                        <th style="width:50%">Subtotal:</th>
                        <td class="text-right">
                            <?= $formatter->asCurrency(array_sum(ArrayHelper::getColumn($dataUjiDiterima, 'BIAYA'))) ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Biaya Ambil:</th>
                        <td class="text-right">
                            <?= $formatter->asCurrency(array_sum(ArrayHelper::getColumn($dataUjiDiterima, 'BIAYA_AMBIL'))) ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Diskon:</th>
                        <td class="text-right">
                            <?= $formatter->asCurrency(array_sum(ArrayHelper::getColumn($dataUjiDiterima, 'DISKON'))) ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Total:</th>
                        <td class="text-right" style="font-weight: bold">
                            <?= $formatter->asCurrency(array_sum(ArrayHelper::getColumn($dataUjiDiterima, 'TOTAL_BIAYA'))) ?>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

