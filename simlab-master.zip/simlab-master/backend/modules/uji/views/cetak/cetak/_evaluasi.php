<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use common\models\eis\PegawaiRiwayatJabKelola;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $kaUpt common\models\eis\Pegawai */
/* @var $dataUji common\models\simlab\Uji[] */
/* @var $dataUjiDiterima common\models\simlab\Uji[] */
/* @var $dataUjiDitolak common\models\simlab\Uji[] */
/* @var $umFront yii\web\UrlManager */

$formatter = Yii::$app->formatter;
$member = $agenda->idMember;
$kaUpt = PegawaiRiwayatJabKelola::findByJabatan(250, $agenda->TANGGAL_PERMOHONAN)->one();
$dataUji = $agenda->getDataUji()->orderBy(['ID' => SORT_ASC])->all();
$dataUjiDiterima = $agenda->getDataUji()->where(['<>', 'ID_STATUS_UJI', 2])->orderBy(['ID' => SORT_ASC])->all();
$dataUjiDitolak = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 2])->orderBy(['ID' => SORT_ASC])->all();
$umFront = Yii::$app->get('umFront');

$this->title = $agenda->KODE . ' - EVALUASI PERMINTAAN PENGUJIAN';
?>
<div class="uji-cetak-evaluasi">
    <h2 class="text-center text-uppercase" style="font-weight: bold; font-size: 11pt">
        <span style="text-transform: uppercase; text-decoration: underline">
             Evaluasi Permintaan Pengujian<br/>
        </span>
        No. Agenda: <?= $agenda->KODE ?>
    </h2>
    <p>Berdasarkan permintaan yang diajukan oleh:</p>

    <?php if ($member->ID_JENIS_MEMBER == 2) { ?>
        <table width="100%">
            <tbody>
            <tr>
                <td style="width: 25%">Nama Instansi/Perusahaan</td>
                <td>:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Penanggung Jawab</td>
                <td>:</td>
                <td><?= $agenda->NAMA_PJ ?></td>
            </tr>
            <tr>
                <td>Alamat Instansi/Perusahaan</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp./Fax</td>
                <td>:</td>
                <td><?= $agenda->TELP ?>/<?= $agenda->FAX ?></td>
            </tr>
            </tbody>
        </table>
    <?php } else { ?>
        <table width="100%">
            <tbody>
            <tr>
                <td style="width: 25%">Nama</td>
                <td>:</td>
                <td><?= $agenda->NAMA ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?= $agenda->ALAMAT ?></td>
            </tr>
            <tr>
                <td>Telp</td>
                <td>:</td>
                <td><?= $agenda->TELP ?></td>
            </tr>
            </tbody>
        </table>
    <?php } ?>

    <br/>

    <?php if ($dataUjiDiterima) { ?>
        <p>
            UPT Laboratorium Terpadu UNS <b>dapat</b> melakukan pengujian terhadap contoh uji dengan data sebagai
            berikut:
        </p>
        <table class="table table-bordered table-condensed" style="margin-bottom: 0">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center;">#CU</th>
                <th style="width: 24%;">Asal Contoh Uji</th>
                <th style="width: 24%;">Jenis Contoh Uji</th>
                <th style="width: 24%;">Parameter Uji</th>
                <th style="width: 24%;text-align: center">Kode*</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <tr>
                    <td style="text-align: center;"><?= $uji->NO_CU ?></td>
                    <td><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                    <td style="text-align: center"><b><?= $uji->KODE ?></b></td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
        <p>* Mohon kode digunakan sebagai identifikasi Contoh Uji</p>
        <p>Bilamana memungkinkan saat penyerahan contoh uji memperhatikan hal berikut :</p>
        <table class="table table-bordered table-condensed" style="margin-bottom: 0">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center;">#CU</th>
                <th style="width: 24%;">Ketersediaan Rekaman</th>
                <th style="width: 24%;">Kemasan Contoh Uji</th>
                <th style="width: 24%;">Proses Pengawetan</th>
                <th style="width: 24%;text-align: center">Keterangan</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($dataUjiDiterima as $i => $uji) { ?>
                <?php $rekomendasi = $uji->idRekomendasi; ?>
                <tr>
                    <td style="text-align: center;"><?= $uji->NO_CU ?></td>
                    <td><?= ArrayHelper::getValue($rekomendasi, 'idUjiKetersediaan.KETERSEDIAAN') ?></td>
                    <td><?= ArrayHelper::getValue($rekomendasi, 'idUjiKemasan.KEMASAN') ?></td>
                    <td><?= ArrayHelper::getValue($rekomendasi, 'idUjiPengawetan.PENGAWETAN') ?></td>
                    <td><?= $rekomendasi->KETERANGAN ?></td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
        <br/>
        <table class="table table-condensed no-border">
            <tr>
                <td style="width: 40%;"><?= Yii::t('app', 'Tanggal penyerahan/Pengambilan contoh uji') ?></td>
                <td style="width: 5px;">:</td>
                <td><?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:l, d F Y') ?></td>
            </tr>
            <tr>
                <td><?= Yii::t('app', 'Pihak pengambil contoh uji') ?></td>
                <td>:</td>
                <td><?= ArrayHelper::getValue($agenda, 'idPihakPengambil.PIHAK_PENGAMBIL', '-') ?></td>
            </tr>
        </table>
    <?php } ?>

    <?php if ($dataUjiDitolak) { ?>
        <br/>
        <p>
            UPT Laboratorium Terpadu UNS <b>tidak dapat</b> melakukan pengujian terhadap contoh uji dengan data sebagai
            berikut:
        </p>
        <table class="table table-bordered table-condensed" style="margin-bottom: 0">
            <thead>
            <tr>
                <th style="width: 5%; text-align: center;">#CU</th>
                <th style="width: 24%;">Asal Contoh Uji</th>
                <th style="width: 24%;">Jenis Contoh Uji</th>
                <th style="width: 24%;">Parameter Uji</th>
                <th style="width: 24%;text-align: center">Keterangan</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($dataUjiDitolak as $i => $uji) { ?>
                <?php $rekomendasi = $uji->idRekomendasi; ?>
                <tr>
                    <td style="text-align: center;"><?= $uji->NO_CU ?></td>
                    <td><?= $uji->ASAL_CONTOH_UJI ?></td>
                    <td><?= ArrayHelper::getValue($uji, 'idPaket.NAMA', Yii::t('app', 'Non Paket')) ?></td>
                    <td><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                    <td><?= $rekomendasi->KETERANGAN ?></td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
        <br/>
    <?php } ?>

    <p>Catatan Kaji Ulang Permintaan</p>
    <table class="table table-bordered table-condensed text-center">
        <thead>
            <tr>
                <th style="width: 5%; vertical-align: top">#CU</th>
                <th style="width: 20%; vertical-align: top">Kemampuan Personel</th>
                <th style="width: 20%; vertical-align: top">Kondisi Akomodasi</th>
                <th style="width: 20%; vertical-align: top">Beban Pekerjaan Laboratorium</th>
                <th style="width: 20%; vertical-align: top">Kondisi Peralatan Pengujian</th>
                <th style="width: 20%; vertical-align: top">Kesesuaian Metode</th>
            </tr>
        </thead>

         <?php foreach ($dataUji as $i => $uji) { ?>
            <?php $evaluasi = $uji->idEvaluasi; ?>
            <tr>
                <td style="text-align: center;"><?= $uji->NO_CU ?></td>
                <td><?= $evaluasi->IS_KEMAMPUAN_PERSONEL ? '&#10003;' : '&#10005;'  ?></td>
                <td><?= $evaluasi->IS_KONDISI_AKOMODASI ? '&#10003;' : '&#10005;'  ?></td>
                <td><?= $evaluasi->IS_BEBAN_PEKERJAAN ? '&#10003;' : '&#10005;'  ?></td>
                <td><?= $evaluasi->IS_KONDISI_ALAT ? '&#10003;' : '&#10005;'  ?></td>
                <td><?= $evaluasi->IS_KESESUAIAN_METODE ? '&#10003;' : '&#10005;'  ?></td>
            </tr>
        <?php } ?>

    </table>
    <table class="table no-border table-condensed">
        <tbody>
        <tr>
            <td style="width: 60%; vertical-align: middle; text-align: center">
                <?= Html::img(
                    $umFront->createAbsoluteUrl(['/api/qr-code', 'label' => $agenda->KODE, 'text' => $agenda->KODE]),
                    ['style' => ['width' => '100px']]
                ) ?>
            </td>
            <td>
                <?= $formatter->asText($agenda->TEMPAT_PERMOHONAN) ?>,
                <?= $formatter->asDate($agenda->TANGGAL_PENERIMAAN, 'php:d F Y') ?>
                <br/>
                Kepala UPT Lab Terpadu UNS
                <br/>
                <br/>
                <br/>
                <br/>
                <?= $kaUpt->NAMA_LENGKAP ?>
            </td>
        </tr>
        </tbody>
    </table>

</div>
