<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

/* @var $this \yii\web\View */
/* @var $items array */

$this->title = Yii::t('app', 'Cetak Pengujian');

if (Yii::$app->request->isAjax) {
    echo $this->render('view/_ajax', [
        'items' => $items,
    ]);
} else {
    echo $this->render('view/_non-ajax', [
        'items' => $items,
    ]);
}
