<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this \yii\web\View */
/* @var $items array */
?>
<div class="cetak-site-index">
    <div class="row">

        <?php foreach ($items as $item) { ?>
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">

                <?php $visible = ArrayHelper::getValue($item, 'visible', true); ?>

                <?php if ($visible) { ?>
                    <?= Html::beginTag('a', array_merge(
                        ['class' => 'small-box-footer', 'target' => '_blank'],
                        $item['linkOptions'] ?? [],
                    )) ?>
                        <div class="inner">
                            <h4><b><?= $item['title'] ?></b></h4>
                            <p><?= $item['description'] ?></p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file-text"></i>
                        </div>
                        <?= Html::tag('span',
                            Yii::t('app', 'Cetak') . ' <i class="fa fa-arrow-circle-right"></i>',
                            ['class' => 'small-box-footer', 'target' => '_blank'],
                        ) ?>
                    <?= Html::endTag('a') ?>
                <?php } else { ?>
                    <div class="small-box bg-teal">
                        <div class="inner">
                            <h4><b><?= $item['title'] ?></b></h4>
                            <p><?= $item['description'] ?></p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file-text"></i>
                        </div>
                         <?= Html::tag('span',
                            Yii::t('app', 'Cetak') . ' <i class="fa fa-arrow-circle-right"></i>',
                            array_merge(
                                ['class' => 'small-box-footer', 'target' => '_blank'],
                                $item['linkOptions'] ?? []
                            )
                        ) ?>
                    </div>
                <?php } ?>

            </div>
        <?php } ?>

    </div>
</div>
