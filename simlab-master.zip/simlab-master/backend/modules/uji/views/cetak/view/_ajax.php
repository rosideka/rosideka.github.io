<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this \yii\web\View */
/* @var $items array */
?>
<div class="cetak-site-index">

    <?php foreach ($items as $item) { ?>
        <?php
        $visible = ArrayHelper::getValue($item, 'visible', true);

        if ($visible) {
            echo Html::a(
                Html::tag('i', '', ['class' => 'fa fa-file-text-o']) . ' ' . $item['title'],
                $item['url'],
                ArrayHelper::merge(
                    [
                        'class' => 'btn btn-block btn-social bg-teal-active',
                        'target' => '_blank',
                        'data-toggle' => 'tooltip',
                        'title' => $item['description'],
                        'data-pjax' => 0,
                    ],
                    $item['linkOptions'] ?? []
                )
            );
        } else {
            echo Html::button(
                Html::tag('i', '', ['class' => 'fa fa-file-text-o']) . ' ' . $item['title'],
                ['class' => 'btn btn-block btn-social bg-teal', 'disabled' => true]
            );
        }
        ?>
    <?php } ?>

</div>
