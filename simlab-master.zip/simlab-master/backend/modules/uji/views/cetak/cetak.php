<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $pageOptions array */

$this->registerCss($this->render('cetak/_style.css'));

$header = ArrayHelper::remove($pageOptions, 'header', true);

if (!($class = ArrayHelper::getValue($pageOptions, 'class'))) {
    $pageOptions['class'] = 'cetak portrait';
}
?>
<section<?= Html::renderTagAttributes($pageOptions) ?>>
    <?php
    if ($header) {
        echo $this->render('cetak/_header');
    }

    echo $this->render('cetak/_' . Yii::$app->request->get('d'), [
        'agenda' => $agenda,
    ]);
    ?>
</section>

