<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model array */
/* @var $searchModel common\models\simlab\searches\AgendaSearch */

$attributes = [
    [
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
        'captionOptions' => ['style' => 'width:33.33%'],
    ],
    [
        'attribute' => 'NO_IDENTITAS',
        'label' => $searchModel->getAttributeLabel('NO_IDENTITAS'),
    ],
    [
        'attribute' => 'ALAMAT',
        'label' => $searchModel->getAttributeLabel('ALAMAT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'FAX',
        'label' => $searchModel->getAttributeLabel('FAX'),
    ],
];

if ($model['ID_PJ']) {
    $attributes = array_merge($attributes, [
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'NAMA_PJ',
            'label' => $searchModel->getAttributeLabel('NAMA_PJ'),
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'EMAIL_PJ',
            'label' => $searchModel->getAttributeLabel('EMAIL_PJ'),
            'format' => 'email',
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'TELP_PJ',
            'label' => $searchModel->getAttributeLabel('TELP_PJ'),
        ],
    ]);
}

$attributes = array_merge($attributes, [
    [
        'attribute' => 'PIHAK_PENGAMBIL',
        'label' => $searchModel->getAttributeLabel('PIHAK_PENGAMBIL'),
    ],
    [
        'attribute' => 'PERMINTAAN_PROSES',
        'label' => $searchModel->getAttributeLabel('PERMINTAAN_PROSES'),
    ],
    [
        'attribute' => 'TEMPAT_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TEMPAT_PERMOHONAN'),
    ],
    [
        'attribute' => 'TANGGAL_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PERMOHONAN'),
        'format' => ['date', 'php:l, d F Y'],
    ],
    [
        'attribute' => 'TANGGAL_PENERIMAAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
        'format' => ['date', 'php:l, d F Y'],
    ],
    [
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
]);

echo DetailView::widget([
    'model' => $model,
    'options' => [
        'class' => 'table table-striped table-bordered detail-view',
        'style' => 'margin-bottom: 0',
    ],
    'attributes' => $attributes,
]);
