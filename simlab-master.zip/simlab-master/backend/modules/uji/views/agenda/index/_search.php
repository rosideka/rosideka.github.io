<?php

use common\models\refs\RefPermintaanProses;
use common\models\refs\RefPihakPengambil;
use common\models\refs\RefStatusUji;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\searches\AgendaSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="agenda-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'KODE') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA_PJ') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'TEMPAT_PERMOHONAN') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'TANGGAL_PERMOHONAN') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_PIHAK_PENGAMBIL')->widget(Select2::class, [
                'data' => RefPihakPengambil::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('PIHAK_PENGAMBIL')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_PERMINTAAN_PROSES')->widget(Select2::class, [
                'data' => RefPermintaanProses::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('PERMINTAAN_PROSES')) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_STATUS_UJI')->widget(Select2::class, [
                'data' => RefStatusUji::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ])->label($model->getAttributeLabel('STATUS_UJI')) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
