<?php

/* @var $searchModel common\models\simlab\searches\AgendaSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_MEMBER',
        'label' => $searchModel->getAttributeLabel('ID_MEMBER'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NO_IDENTITAS',
        'label' => $searchModel->getAttributeLabel('NO_IDENTITAS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ALAMAT',
        'label' => $searchModel->getAttributeLabel('ALAMAT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP',
        'label' => $searchModel->getAttributeLabel('TELP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'FAX',
        'label' => $searchModel->getAttributeLabel('FAX'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PJ',
        'label' => $searchModel->getAttributeLabel('ID_PJ'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_PJ',
        'label' => $searchModel->getAttributeLabel('NAMA_PJ'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'EMAIL_PJ',
        'label' => $searchModel->getAttributeLabel('EMAIL_PJ'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TELP_PJ',
        'label' => $searchModel->getAttributeLabel('TELP_PJ'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TEMPAT_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TEMPAT_PERMOHONAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PERMOHONAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PIHAK_PENGAMBIL',
        'label' => $searchModel->getAttributeLabel('ID_PIHAK_PENGAMBIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PIHAK_PENGAMBIL',
        'label' => $searchModel->getAttributeLabel('PIHAK_PENGAMBIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_PERMINTAAN_PROSES',
        'label' => $searchModel->getAttributeLabel('ID_PERMINTAAN_PROSES'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PERMINTAAN_PROSES',
        'label' => $searchModel->getAttributeLabel('PERMINTAAN_PROSES'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('ID_STATUS_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
