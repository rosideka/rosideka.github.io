<?php

use backend\modules\uji\models\DisposisiSearch;
use backend\modules\uji\models\PenerimaanSearch;
use kartik\grid\GridView;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\AgendaSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'width' => '30px',
        'expandAllTitle' => 'Detail Agenda',
        'collapseTitle' => 'Detail Agenda',
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PIHAK_PENGAMBIL',
        'label' => $searchModel->getAttributeLabel('PIHAK_PENGAMBIL'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PERMINTAAN_PROSES',
        'label' => $searchModel->getAttributeLabel('PERMINTAAN_PROSES'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PERMOHONAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PENERIMAAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Evaluasi'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{evaluasi}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['evaluasi', 'id' => $key]);
        },
        'buttons' => [
            'evaluasi' => function ($url, $model, $key) {
                if (in_array($model['ID_STATUS_UJI'], [1, 2, 3])) {
                    return Html::a(
                        Yii::t('app', 'Evaluasi'),
                        $url,
                        [
                            'role' => 'modal-remote',
                            'data-toggle' => 'tooltip',
                            'target' => '_blank',
                            'title' => Yii::t('app', 'Evaluasi'),
                            'class' => 'btn btn-sm btn-info',
                        ]
                    );
                }

                return '';
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Terima'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([
                'penerimaan/index',
                StringHelper::basename(PenerimaanSearch::class) => [
                    'TAHUN_PERMOHONAN' => (new DateTime($model['TANGGAL_PERMOHONAN']))->format('Y'),
                    'KODE_AGENDA' => $model['KODE'],
                    'ID_STATUS_UJI' => 3,
                ],
            ]);
        },
        'template' => '{penerimaan}',
        'buttons' => [
            'penerimaan' => function ($url, $model, $key) {
                if (in_array($model['ID_STATUS_UJI'], [3, 4])) {
                    return Html::a(
                        Yii::t('app', 'Terima'),
                        $url,
                        [
                            'data-toggle' => 'tooltip',
                            'title' => Yii::t('app', 'Terima'),
                            'class' => 'btn btn-sm btn-primary',
                            'data-pjax' => 0,
                        ]
                    );
                }

                return '';
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Disposisi'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([
                'disposisi/index',
                StringHelper::basename(DisposisiSearch::class) => [
                    'TAHUN_PERMOHONAN' => (new DateTime($model['TANGGAL_PERMOHONAN']))->format('Y'),
                    'KODE_AGENDA' => $model['KODE'],
                ],
            ]);
        },
        'template' => '{disposisi}',
        'buttons' => [
            'disposisi' => function ($url, $model, $key) {
                if (in_array($model['ID_STATUS_UJI'], [4, 5])) {
                    return Html::a(
                        Yii::t('app', 'Disposisi'),
                        $url,
                        [
                            'data-toggle' => 'tooltip',
                            'title' => Yii::t('app', 'Disposisi'),
                            'class' => 'btn btn-sm btn-success',
                            'data-pjax' => 0,
                        ]
                    );
                }

                return '';
            },
        ],
        'visible' => Yii::$app->user->can('koordinator_lab'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Cetak'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['cetak/view', 'id' => $key]);
        },
        'template' => '{uji}',
        'buttons' => [
            'uji' => function ($url, $model, $key) {
                return Html::a(
                    Yii::t('app', 'Cetak'),
                    $url,
                    [
                        'class' => 'btn btn-sm btn-danger',
                        'data-toggle' => 'tooltip',
                        'role' => 'modal-remote',
                        'target' => '_blank',
                        'title' => Yii::t('app', 'Cetak'),
                    ]
                );
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{view}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
    ],
];
