<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use kartik\grid\GridView;
use yii\data\ActiveDataProvider;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Agenda */
?>
<?php foreach ($model->dataUji as $iu => $uji): ?>
    <div class="box box-success box-solid uji-item">
        <div class="box-header" data-toggle="collapse" data-target="#carousel-uji-<?= $iu ?>" style="cursor: pointer">
            <h4 class="box-title"><?= implode(' - ', [$uji->ASAL_CONTOH_UJI]) ?></h4>
        </div>
        <div id="carousel-uji-<?= $iu ?>" class="sop-alur-body panel-body panel-collapse collapse<?= $iu === 0 ? ' in' : '' ?>">
            <?php
            echo DetailView::widget([
                'model' => $uji,
                'attributes' => [
                    [
                        'attribute' => 'KODE',
                        'captionOptions' => ['style' => 'width:33.33%'],
                    ],
                    'ASAL_CONTOH_UJI',
                    [
                        'attribute' => 'KLASIFIKASI_LOKASI',
                        'value' => $uji->KLASIFIKASI_LOKASI,
                    ],
                    [
                        'attribute' => 'ID_JENIS_PAKET',
                        'value' => $uji->ID_JENIS_PAKET ? $uji->idJenisPaket->JENIS_PAKET : null,
                    ],
                    [
                        'attribute' => 'ID_BAKU_MUTU',
                        'value' => $uji->ID_BAKU_MUTU ? $uji->idBakuMutu->NAMA_BAKU_MUTU : null,
                    ],
                    [
                        'attribute' => 'ID_PAKET',
                        'value' => $uji->ID_PAKET ? $uji->idPaket->NAMA : null,
                    ],
                    [
                        'attribute' => 'ID_STATUS_UJI',
                        'value' => $uji->ID_STATUS_UJI ? $uji->idStatusUji->STATUS_UJI : null,
                    ],
                ],
            ]);

            echo GridView::widget([
                'dataProvider' => new ActiveDataProvider([
                    'query' => $uji->getDataUjiParameter(),
                    'pagination' => false,
                ]),
                'pjax' => true,
                'pjaxSettings' => [
                    'options' => [
                        'enablePushState' => false,
                        'enableReplaceState' => false,
                    ],
                ],
                'summary' => false,
                'columns' => [
                    'NAMA',
                    'RUMUS:raw',
                    [
                        'attribute' => 'ID_STATUS_PARAMETER',
                        'value' => 'idStatusParameter.STATUS_PARAMETER',
                    ],
                ],
                'toolbar' => false,
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'panel' => false,
            ]);
            ?>

        </div>
    </div>
<?php endforeach; ?>

