<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Agenda */

$attributes = [
    [
        'attribute' => 'KODE',
        'captionOptions' => ['style' => 'width:33.33%'],
    ],
    'NAMA',
    [
        'attribute' => 'ID_PIHAK_PENGAMBIL',
        'value' => $model->ID_PIHAK_PENGAMBIL ? $model->idPihakPengambil->PIHAK_PENGAMBIL : null,
    ],
    [
        'attribute' => 'ID_PERMINTAAN_PROSES',
        'value' => $model->ID_PERMINTAAN_PROSES ? $model->idPermintaanProses->PERMINTAAN_PROSES : null,
    ],
    'NO_IDENTITAS',
    'ALAMAT',
    'TELP',
    'FAX',
];

if ($model->ID_PJ) {
    $attributes = array_merge($attributes, [
        'NAMA_PJ',
        'EMAIL_PJ:email',
        'TELP_PJ',
    ]);
}

$attributes = array_merge($attributes, [
    'TEMPAT_PERMOHONAN',
    [
        'attribute' => 'TANGGAL_PERMOHONAN',
        'format' => ['date', 'php:l, d F Y'],
    ],
    /*
    [
        'attribute' => 'ID_STATUS_UJI',
        'value' => $model->ID_STATUS_UJI ? $model->idStatusUji->STATUS_UJI : null,
    ],
    */
    [
        'label' => Yii::t('app', 'Create'),
        'value' => implode(' ', [
            '<i class="glyphicon glyphicon-user text-gray"></i>',
            $model->CREATE_BY ? $model->createBy->USERNAME : null,
            '<i class="glyphicon glyphicon-globe text-gray"></i>',
            $model->CREATE_IP,
            '<i class="glyphicon glyphicon-time text-gray"></i>',
            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
        ]),
        'format' => 'raw',
    ],
    [
        'label' => Yii::t('app', 'Update'),
        'value' => implode(' ', [
            '<i class="glyphicon glyphicon-user text-gray"></i>',
            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
            '<i class="glyphicon glyphicon-globe text-gray"></i>',
            $model->UPDATE_IP,
            '<i class="glyphicon glyphicon-time text-gray"></i>',
            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
        ]),
        'format' => 'raw',
    ],
]);

echo DetailView::widget([
    'model' => $model,
    'attributes' => $attributes,
]);
