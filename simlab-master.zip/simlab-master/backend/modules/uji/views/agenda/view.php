<?php

/* @var $this yii\web\View */
/* @var $model common\models\simlab\Agenda */

Yii::$app->formatter->nullDisplay = '-';

$this->title = Yii::t('app', 'Detail Pengujian');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Pengujian'), 'url' => ['index']];
?>
<div class="agenda-view">
    <div class="nav-tabs-custom">
        <ul class="nav nav-pills nav-justified nav-table bg-aqua">
            <li class="active">
                <a href="#tab-agenda" data-toggle="tab" class="text-white">
                    <?= Yii::t('app', 'Agenda'); ?>
                </a>
            </li>
            <li>
                <a href="#tab-pengujian" data-toggle="tab" class="text-white">
                    <?= Yii::t('app', 'Pengujian'); ?>
                </a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="tab-agenda">
                <?= $this->render('view/_agenda', [
                    'model' => $model,
                ]) ?>
            </div>
            <div class="tab-pane" id="tab-pengujian">
                <?= $this->render('view/_pengujian', [
                    'model' => $model,
                ]) ?>
            </div>
        </div>
    </div>
</div>
