<?php

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $riwayatAgenda common\models\simlab\RiwayatAgenda */
/* @var $dataUji common\models\simlab\Uji[] */
/* @var $dataRekomendasi common\models\simlab\UjiRekomendasi[] */
/* @var $dataRiwayatUji common\models\simlab\RiwayatUji[] */

use common\models\refs\RefStatusUji;
use common\models\refs\RefUjiKemasan;
use common\models\refs\RefUjiKetersediaan;
use common\models\refs\RefUjiPengawetan;
use common\models\simlab\Pegawai;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

$formatter = Yii::$app->formatter;

$mapKetersedian = RefUjiKetersediaan::map();
$mapKemasan = RefUjiKemasan::map();
$mapPengawetan = RefUjiPengawetan::map();
$mapStatusUji = RefStatusUji::map('ID', 'STATUS_UJI', ['in', 'ID', [1, 2, 3]]);
$mapPegawai = Pegawai::map();

$this->title = Yii::t('app', 'Update Rekomendasi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Agenda'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="agenda-update">
    <?php $form = ActiveForm::begin(); ?>

    <?php $i = 0; ?>

    <?php foreach ($dataUji as $i => $uji) { ?>
        <div class="box box-success box-solid uji-item">
            <div class="box-header" data-toggle="collapse" data-target="#carousel-uji-<?= ++$i ?>" style="cursor: pointer">
                <h4 class="box-title"><?= implode(' - ', [$uji->KODE, $uji->ASAL_CONTOH_UJI]) ?></h4>
            </div>
            <div id="carousel-uji-<?= $i ?>" class="box-body collapse in">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th style="width: 5%; text-align: center;">#CU</th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Asal Contoh Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Jenis Contoh Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Parameter Uji') ?></th>
                        <th style="width: 24%;text-align: center"><?= Yii::t('app', 'Kode*') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="text-center"><?= $i ?></td>
                        <td><?= $formatter->asText($uji->ASAL_CONTOH_UJI) ?></td>
                        <td><?= $formatter->asText(ArrayHelper::getValue($uji, 'idPaket.NAMA')) ?></td>
                        <td>
                            <?= implode(', ', ArrayHelper::getColumn(
                                $uji->dataUjiParameter,
                                'idParameter.RUMUS'
                            )) ?>
                        </td>
                        <td class="text-center"><?= $formatter->asText(ArrayHelper::getValue($uji, 'KODE')) ?></td>
                    </tr>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-8">
                        <div class="row" style="margin-top: 10px">
                            <div class="col-sm-6">
                                <?= $form->field($dataRiwayatUji[$uji->ID],
                                    "[{$uji->ID}]ID_STATUS_UJI")->widget(Select2::class, [
                                        'data' => $mapStatusUji,
                                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                        'pluginOptions' => ['allowClear' => true],
                                    ]) ?>

                            </div>
                            <div class="col-sm-6">
                                <?= $form->field($dataRekomendasi[$uji->ID],
                                    "[{$uji->ID}]ID_UJI_KETERSEDIAAN")->widget(Select2::class, [
                                        'data' => $mapKetersedian,
                                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                        'pluginOptions' => ['allowClear' => true],
                                    ]) ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <?= $form->field($dataRekomendasi[$uji->ID],
                                    "[{$uji->ID}]ID_UJI_PENGAWETAN")->widget(Select2::class, [
                                        'data' => $mapPengawetan,
                                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                        'pluginOptions' => [
                                            'allowClear' => true,
                                            'escapeMarkup' => new JsExpression('function (r) {return r}'),
                                        ],
                                    ]) ?>

                            </div>
                            <div class="col-sm-6">
                                <?= $form->field($dataRekomendasi[$uji->ID], "[{$uji->ID}]ID_UJI_KEMASAN")->widget(Select2::class, [
                                    'data' => $mapKemasan,
                                    'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                    'pluginOptions' => [
                                        'allowClear' => true,
                                        'escapeMarkup' => new JsExpression('function (r) {return r}'),
                                    ],
                                ]) ?>

                            </div>
                        </div>
                        <?= $form->field($dataRekomendasi[$uji->ID], "[{$uji->ID}]KETERANGAN")->textarea(['rows' => 1]); ?>

                    </div>
                    <div class="col-md-4">
                        <div style="margin-top: 10px">
                            <label class="form-label">Kaji Ulang Permintaan</label>
                            <?= $form->field($dataEvaluasi[$uji->ID], "[{$uji->ID}]IS_KEMAMPUAN_PERSONEL")->checkbox(); ?>

                            <?= $form->field($dataEvaluasi[$uji->ID], "[{$uji->ID}]IS_KONDISI_AKOMODASI")->checkbox(); ?>

                            <?= $form->field($dataEvaluasi[$uji->ID], "[{$uji->ID}]IS_BEBAN_PEKERJAAN")->checkbox(); ?>

                            <?= $form->field($dataEvaluasi[$uji->ID], "[{$uji->ID}]IS_KONDISI_ALAT")->checkbox(); ?>

                            <?= $form->field($dataEvaluasi[$uji->ID], "[{$uji->ID}]IS_KESESUAIAN_METODE")->checkbox(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title"><?= Yii::t('app', 'Agenda') ?></div>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($riwayatAgenda, 'ID_STATUS_UJI')->widget(Select2::class, [
                        'data' => $mapStatusUji,
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                        'pluginOptions' => ['allowClear' => true],
                    ])->label($agenda->getAttributeLabel('ID_STATUS_UJI')) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($agenda, 'TANGGAL_PENERIMAAN')->widget(DatePicker::class, [
                        'type' => DatePicker::TYPE_COMPONENT_APPEND,
                        'options' => ['placeholder' => 'Format: yyyy-mm-dd'],
                        'pluginOptions' => ['autoclose' => true, 'format' => 'yyyy-mm-dd'],
                    ]) ?>

                </div>
            </div>

            <?php if ($agenda->ID_PIHAK_PENGAMBIL == 2) { ?>
                <div class="row">
                    <div class="col-sm-6">
                        <?= $form->field($agenda, 'IDP_PENGAMBIL')->widget(Select2::class, [
                            'data' => $mapPegawai,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($agenda, 'NO_VA_PEMBAYARAN')->textInput(['maxlength' => true]) ?>

                    </div>
                </div>
            <?php } else { ?>
                <?= $form->field($agenda, 'NO_VA_PEMBAYARAN')->textInput(['maxlength' => true]) ?>

            <?php } ?>

        </div>
    </div>

    <?php if (!Yii::$app->request->isAjax) { ?>
        <div class="form-group" style="margin-bottom: 0">
            <?= Html::submitButton(
                Yii::t('app', 'Simpan'),
                ['class' => 'btn btn-primary']
            ) ?>

            <?php if (!in_array($agenda->ID_STATUS_UJI, [1, 2])) { ?>
                <?= Html::a(
                    '<i class="glyphicon glyphicon-send"></i> ' . Yii::t('app', 'Email'),
                    ['cetak', 'id' => $agenda->ID],
                    ['class' => 'btn btn-success']
                ) ?>

                <?= Html::a(
                    '<i class="glyphicon glyphicon-print"></i> ' . Yii::t('app', 'Cetak'),
                    ['cetak', 'id' => $agenda->ID],
                    ['class' => 'btn btn-danger', 'target' => '_blank']
                ) ?>
            <?php } ?>

        </div>
    <?php } ?>

    <?php ActiveForm::end() ?>

</div>
