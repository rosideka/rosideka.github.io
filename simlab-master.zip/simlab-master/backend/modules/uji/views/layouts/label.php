<?php
/**
 * @link https://simpeg.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use backend\assets\AppAsset;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $content string */

AppAsset::register($this);

// Favicon
$this->registerLinkTag([
    'rel' => 'icon',
    'href' => Yii::getAlias('@appUrl/favicon.ico'),
    'type' => 'image/x-icon',
]);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <?= Html::csrfMetaTags() ?>
    <title>SIMLAB UNS - <?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body onload="window.print()">
<?php $this->beginBody() ?>
<?= $content; ?>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
