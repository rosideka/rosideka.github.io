<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

/* @var $ujiParameter common\models\simlab\UjiParameter */
/* @var $this yii\web\View */

$this->title = Yii::t('app', 'Selesaikan Analisis');
?>
<div class="uji-pengujian-selesai">
    <?= $this->render('selesai/_form', [
        'ujiParameter' => $ujiParameter,
    ]); ?>
</div>
