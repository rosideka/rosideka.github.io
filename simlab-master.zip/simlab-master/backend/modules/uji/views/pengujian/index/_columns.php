<?php

use kartik\grid\GridView;
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $searchModel common\models\simlab\searches\UjiParameterSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'width' => '30px',
        'expandAllTitle' => 'Detail Agenda',
        'collapseTitle' => 'Detail Agenda',
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI_LAB',
        'label' => $searchModel->getAttributeLabel('KODE_UJI_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS',
        'label' => $searchModel->getAttributeLabel('RUMUS'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('BAKU_MUTU'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'METODE_UJI',
        'label' => $searchModel->getAttributeLabel('METODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'PENGUJI',
        'label' => $searchModel->getAttributeLabel('PENGUJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_DISPOSISI',
        'label' => $searchModel->getAttributeLabel('TANGGAL_DISPOSISI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_ANALISIS',
        'label' => $searchModel->getAttributeLabel('TANGGAL_ANALISIS'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Mulai'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{mulai}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'buttons' => [
            'mulai' => function ($url, $model, $key) {
                if ($model['ID_STATUS_PARAMETER'] == 3) {
                    return Html::a(
                        '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Mulai'),
                        $url,
                        [
                            'class' => 'btn btn-sm btn-primary',
                            'role' => 'modal-remote',
                            'title' => Yii::t('app', 'Mulai'),
                            'data-confirm' => false,
                            'data-method' => false,
                            'data-request-method' => 'post',
                            'data-toggle' => 'tooltip',
                            'data-confirm-title' => Yii::t('app', 'Apakah Anda Yakin?'),
                            'data-confirm-message' => Yii::t('app', 'Apakah anda yakin akan memulai pengujian'),
                        ]
                    );
                }

                return '';
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Selesai'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{selesai}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'buttons' => [
            'selesai' => function ($url, $model, $key) {
                if ($model['ID_STATUS_PARAMETER'] == 4) {
                    return Html::a(
                        '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Selesai'),
                        $url,
                        [
                            'class' => 'btn btn-sm btn-danger',
                            'role' => 'modal-remote',
                            'title' => Yii::t('app', 'Selesai'),
                        ]
                    );
                }

                return '';
            },
        ],
    ],
];
