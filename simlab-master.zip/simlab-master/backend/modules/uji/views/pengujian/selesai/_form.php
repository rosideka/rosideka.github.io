<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\DetailView;

/* @var $ujiParameter common\models\simlab\UjiParameter */
/* @var $uji common\models\simlab\Uji */
/* @var $agenda common\models\simlab\Agenda */
/* @var $this yii\web\View */

$formatter = Yii::$app->formatter;
$parameter = $ujiParameter->idParameter;
$uji = $ujiParameter->idUji;
$agenda = $uji->idAgenda;
?>
<div class="uji-pengujian-selesai-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Selesai Analisis') ?></h2>
        </div>
        <div class="box-body">
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th style="width: 33.33%;"><?= Yii::t('app', 'Asal Contoh Uji') ?></th>
                    <th style="width: 33.33%;"><?= Yii::t('app', 'Jenis Contoh Uji') ?></th>
                    <th style="width: 33.33%;text-align: center"><?= Yii::t('app', 'Kode*') ?></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?= $formatter->asText($uji->ASAL_CONTOH_UJI) ?></td>
                    <td><?= $formatter->asText(ArrayHelper::getValue($uji, 'idPaket.NAMA')) ?></td>
                    <td class="text-center"><?= $formatter->asText(ArrayHelper::getValue($uji, 'KODE')) ?></td>
                </tr>
                </tbody>
            </table>
            <?= DetailView::widget([
                'model' => $ujiParameter,
                'attributes' => [
                    [
                        'attribute' => 'ID_PARAMETER',
                        'value' => '(' . $parameter->RUMUS . ') ' . $parameter->NAMA,
                        'captionOptions' => ['style' => 'width:33.33%'],
                    ],
                    [
                        'attribute' => 'ID_BAKU_MUTU',
                        'value' => $ujiParameter->ID_BAKU_MUTU ? $ujiParameter->idBakuMutu->NAMA_BAKU_MUTU : null,
                    ],
                    [
                        'attribute' => 'ID_PENGUJI',
                        'value' => $ujiParameter->ID_PENGUJI ? $ujiParameter->idPenguji->NAMA_LENGKAP : null,
                    ],
                    [
                        'attribute' => 'TANGGAL_DISPOSISI',
                        'format' => ['date', 'php:l, d F Y'],
                    ],
                    [
                        'attribute' => 'TANGGAL_ANALISIS',
                        'format' => ['date', 'php:l, d F Y'],
                    ],
                ],
            ]) ?>
            <hr />
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($ujiParameter, 'KETERANGAN')->textarea(['rows' => 3]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        Yii::t('app', 'Selesaikan'),
                        ['class' => 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>

