<?php

/* @var $this yii\web\View */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUji common\models\simlab\Uji[] */

$this->title = Yii::t('app', 'Penerimaan Contoh Uji') . ' ' . $dataUji[array_key_first($dataUji)]->KODE;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Penerimaan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uji-create">
    <?= $this->render('_form', [
        'dataUji' => $dataUji,
    ]) ?>
</div>
