<?php

/* @var $searchModel common\models\simlab\searches\UjiSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_AGENDA',
        'label' => $searchModel->getAttributeLabel('ID_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_AGENDA',
        'label' => $searchModel->getAttributeLabel('KODE_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI',
        'label' => $searchModel->getAttributeLabel('KODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ASAL_CONTOH_UJI',
        'label' => $searchModel->getAttributeLabel('ASAL_CONTOH_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_KETERSEDIAAN',
        'label' => $searchModel->getAttributeLabel('ID_UJI_KETERSEDIAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KETERSEDIAAN',
        'label' => $searchModel->getAttributeLabel('UJI_KETERSEDIAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_KEMASAN',
        'label' => $searchModel->getAttributeLabel('ID_UJI_KEMASAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KEMASAN',
        'label' => $searchModel->getAttributeLabel('UJI_KEMASAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_PENGAWETAN',
        'label' => $searchModel->getAttributeLabel('ID_UJI_PENGAWETAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_PENGAWETAN',
        'label' => $searchModel->getAttributeLabel('UJI_PENGAWETAN'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_KONDISI',
        'label' => $searchModel->getAttributeLabel('ID_UJI_KONDISI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KONDISI',
        'label' => $searchModel->getAttributeLabel('UJI_KONDISI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UJI_KONDISI_DITERIMA',
        'label' => $searchModel->getAttributeLabel('ID_UJI_KONDISI_DITERIMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KONDISI_DITERIMA',
        'label' => $searchModel->getAttributeLabel('UJI_KONDISI_DITERIMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CATATAN_ABNORMALITAS',
        'label' => $searchModel->getAttributeLabel('CATATAN_ABNORMALITAS'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KETERANGAN',
        'label' => $searchModel->getAttributeLabel('KETERANGAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PERMOHONAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PERMOHONAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TANGGAL_PENERIMAAN',
        'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
    ],
];
