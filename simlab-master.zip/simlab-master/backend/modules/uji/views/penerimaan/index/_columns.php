<?php

use backend\modules\uji\models\LabelSearch;
use kartik\grid\GridView;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\helpers\Url;

/* @var $searchModel backend\modules\uji\models\PenerimaanSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
        'checkboxOptions' => function ($model) {
            if (!in_array($model['ID_STATUS_UJI'], [3, 4])) {
                return ['disabled' => true];
            }

            return [];
        },
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => 'kartik\grid\ExpandRowColumn',
        'width' => '30px',
        'expandAllTitle' => 'Detail Agenda',
        'collapseTitle' => 'Detail Agenda',
        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
        'value' => function () {
            return GridView::ROW_COLLAPSED;
        },
        'detail' => function ($model) use ($searchModel) {
            return $this->render('index/_columns-expand', [
                'model' => $model,
                'searchModel' => $searchModel,
            ]);
        },
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_AGENDA',
        'label' => $searchModel->getAttributeLabel('KODE_AGENDA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE_UJI',
        'label' => $searchModel->getAttributeLabel('KODE_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ASAL_CONTOH_UJI',
        'label' => $searchModel->getAttributeLabel('ASAL_CONTOH_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KETERSEDIAAN',
        'label' => $searchModel->getAttributeLabel('UJI_KETERSEDIAAN'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_PENGAWETAN',
        'label' => $searchModel->getAttributeLabel('UJI_PENGAWETAN'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KONDISI',
        'label' => $searchModel->getAttributeLabel('UJI_KONDISI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UJI_KONDISI_DITERIMA',
        'label' => $searchModel->getAttributeLabel('UJI_KONDISI_DITERIMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'STATUS_UJI',
        'label' => $searchModel->getAttributeLabel('STATUS_UJI'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Terima'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{terima}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to(['terima', 'id' => $key]);
        },
        'buttons' => [
            'terima' => function ($url, $model, $key) {
                if (in_array($model['ID_STATUS_UJI'], [3, 4])) {
                    return Html::a(
                        '<i class="glyphicon glyphicon-check"></i> ' . Yii::t('app', 'Terima'),
                        $url,
                        [
                            'data-toggle' => 'tooltip',
                            'title' => Yii::t('app', 'Terima'),
                            'class' => 'btn btn-sm btn-success',
                            'role' => 'modal-remote',
                        ]
                    );
                }

                return '';
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => '<i class="glyphicon glyphicon-tag"></i> ' . Yii::t('app', 'Label'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'template' => '{terima}',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([
                'label/index',
                StringHelper::basename(LabelSearch::class) => [
                    'TAHUN_PERMOHONAN' => $model['TAHUN_PERMOHONAN'],
                    'KODE_AGENDA' => $model['KODE_AGENDA'],
                    'KODE_UJI' => $model['KODE_UJI'],
                ],
            ]);
        },
        'buttons' => [
            'terima' => function ($url, $model, $key) {
                if (in_array($model['ID_STATUS_UJI'], [4, 5])) {
                    return Html::a(
                        '<i class="glyphicon glyphicon-tag"></i> ' . Yii::t('app', 'Label'),
                        $url,
                        [
                            'data-toggle' => 'tooltip',
                            'title' => Yii::t('app', 'Label'),
                            'class' => 'btn btn-sm btn-primary',
                            'data-pjax' => 0,
                        ]
                    );
                }

                return '';
            },
        ],
    ],
];
