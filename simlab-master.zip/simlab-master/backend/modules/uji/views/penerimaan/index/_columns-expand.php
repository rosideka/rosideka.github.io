<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $searchModel backend\modules\uji\models\PenerimaanSearch */

echo DetailView::widget([
    'model' => $model,
    'options' => [
        'class' => 'table table-striped table-bordered detail-view',
        'style' => 'margin-bottom: 0',
    ],
    'attributes' => [
        [
            'attribute' => 'UJI_KEMASAN',
            'label' => $searchModel->getAttributeLabel('UJI_KEMASAN'),
            'captionOptions' => ['style' => 'width: 33.33%'],
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'CATATAN_ABNORMALITAS',
            'label' => $searchModel->getAttributeLabel('CATATAN_ABNORMALITAS'),
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'KETERANGAN',
            'label' => $searchModel->getAttributeLabel('KETERANGAN'),
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'TANGGAL_PERMOHONAN',
            'label' => $searchModel->getAttributeLabel('TANGGAL_PERMOHONAN'),
        ],
        [
            'class' => '\kartik\grid\DataColumn',
            'attribute' => 'TANGGAL_PENERIMAAN',
            'label' => $searchModel->getAttributeLabel('TANGGAL_PENERIMAAN'),
        ],
    ],
]);
