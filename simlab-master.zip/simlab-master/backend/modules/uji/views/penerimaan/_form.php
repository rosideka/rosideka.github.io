<?php

use common\models\refs\RefUjiKemasan;
use common\models\refs\RefUjiKetersediaan;
use common\models\refs\RefUjiKondisi;
use common\models\refs\RefUjiKondisiDiterima;
use common\models\refs\RefUjiPengawetan;
use common\models\refs\RefUjiRetensi;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $agenda common\models\simlab\Agenda */
/* @var $dataUji common\models\simlab\Uji[] */

$mapUjiKetersediaan = RefUjiKetersediaan::map();
$mapUjiKemasan = RefUjiKemasan::map();
$mapUjiPengawetan = RefUjiPengawetan::map();
$mapUjiKondisi = RefUjiKondisi::map();
$mapUjiKondisiDiterima = RefUjiKondisiDiterima::map();
$mapUjiRetensi = RefUjiRetensi::map('ID', 'CONCAT("KODE", \' - \', "RETENSI")');
$mapKemasan = RefUjiKemasan::map();

$formatter = Yii::$app->formatter;
?>
<div class="uji-form">
    <?php $form = ActiveForm::begin(); ?>

    <?php foreach ($dataUji as $i => $uji) { ?>
        <div class="box box-success box-solid uji-item">
            <div class="box-header" data-toggle="collapse" data-target="#carousel-uji-<?= $i ?>" style="cursor: pointer">
                <h4 class="box-title"><?= implode(' - ', [$uji->KODE, $uji->ASAL_CONTOH_UJI]) ?></h4>
            </div>
            <div id="carousel-uji-<?= $i ?>" class="panel-body collapse<?= $i === array_key_first($dataUji) ? ' in' : '' ?>">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th style="width: 24%;"><?= Yii::t('app', 'Asal Contoh Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Jenis Contoh Uji') ?></th>
                        <th style="width: 24%;"><?= Yii::t('app', 'Parameter Uji') ?></th>
                        <th style="width: 24%;text-align: center"><?= Yii::t('app', 'Kode*') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?= $formatter->asText($uji->ASAL_CONTOH_UJI) ?></td>
                        <td><?= $formatter->asText(ArrayHelper::getValue($uji, 'idPaket.NAMA')) ?></td>
                        <td><?= implode(', ', ArrayHelper::getColumn($uji->dataUjiParameter, 'idParameter.RUMUS')) ?></td>
                        <td class="text-center"><?= $formatter->asText(ArrayHelper::getValue($uji, 'KODE')) ?></td>
                    </tr>
                    </tbody>
                </table>

                <div class="row">
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]ID_UJI_KETERSEDIAAN")->widget(Select2::class, [
                            'data' => $mapUjiKetersediaan,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]ID_UJI_PENGAWETAN")->widget(Select2::class, [
                            'data' => $mapUjiPengawetan,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'escapeMarkup' => new JsExpression('function (r) {return r}'),
                            ],
                        ]) ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]ID_UJI_KONDISI")->widget(Select2::class, [
                            'data' => $mapUjiKondisi,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]ID_UJI_KONDISI_DITERIMA")->widget(Select2::class, [
                            'data' => $mapUjiKondisiDiterima,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => ['allowClear' => true],
                        ]) ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]ID_UJI_KEMASAN")->widget(Select2::class, [
                            'data' => $mapKemasan,
                            'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'escapeMarkup' => new JsExpression('function (r) {return r}'),
                            ],
                        ]) ?>

                    </div>
                    <div class="col-sm-6">
                        <?= $form->field($uji, "[{$i}]JUMLAH_CONTOH_UJI")->input('number', ['step' => 1, 'min' => 1]) ?>

                    </div>
                </div>
                <?= $form->field($uji, "[{$i}]CATATAN_ABNORMALITAS")->textInput(['maxlength' => true]) ?>

                <?= $form->field($uji, "[{$i}]KETERANGAN")->textarea(['rows' => 2]); ?>

                <?=
                $form
                    ->field($uji, "[{$i}]IS_SESUAI_REKOMENDASI", ['template' => '<label>{input} {label}</label>{error}{hint}'])
                    ->checkbox(['label' => Yii::t('app', 'Pilih jika penerimaan contoh uji sesuai dengan rekomendasi')], false)
                ?>

            </div>
        </div>

    <?php } ?>

    <?php if ($pks = Yii::$app->request->post('pks')) { ?>
        <?= Html::hiddenInput('pks', $pks); ?>
    <?php } ?>

    <?php if (!Yii::$app->request->isAjax) { ?>
        <div class="form-group">
            <?= Html::submitButton(Yii::t('app', 'Simpan'), ['class' => 'btn btn-primary']) ?>
        </div>
    <?php } ?>

    <?php ActiveForm::end(); ?>

</div>
