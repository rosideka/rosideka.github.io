<?php

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\LabelSearch;
use common\helpers\DateHelper;
use common\models\MultipleModel;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\Uji;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use Yii;
use yii\db\ActiveQuery;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * LabelController implements the CRUD actions for UjiLab model.
 */
class LabelController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all UjiLab models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LabelSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * @param $id
     * @param mixed $idu
     * @param mixed $idl
     * @return mixed
     */
    public function actionPrint($idu, $idl)
    {
        $dataUjiLab = [];

        $model = UjiLab::findOne(['ID_UJI' => $idu, 'ID_LAB' => $idl]) ?: new UjiLab([
            'ID_UJI' => $idu,
            'ID_LAB' => $idl,
        ]);

        $model->IDP_KOORDINATOR = $model->idLab->IDP_KETUA;

        $dataUjiLab[] = $model;

        return $this->print($dataUjiLab);
    }

    /**
     * @return mixed
     */
    public function actionPrintSelected()
    {
        $request = Yii::$app->request;
        $dataUjiLab = [];
        $pks = explode(',', $request->post('pks'));

        foreach ($pks as $pk) {
            $xpk = explode('|', $pk);
            $idu = $xpk[0];
            $idl = $xpk[1];

            $model = UjiLab::findOne(['ID_UJI' => $idu, 'ID_LAB' => $idl]) ?: new UjiLab([
                'ID_UJI' => $idu,
                'ID_LAB' => $idl,
            ]);

            $model->IDP_KOORDINATOR = $model->idLab->IDP_KETUA;
            $dataUjiLab[] = $model;
        }

        return $this->print($dataUjiLab);
    }

    /**
     * @param int $id ID of UjiLab
     * @return mixed
     */
    public function actionPrintAll($id)
    {
        $request = Yii::$app->request;
        $uji = $this->findUji($id);
        $idsLab = $uji->getDataUjiParameter()->select(['DISTINCT "ID_LAB"'])->column();

        foreach ($idsLab as $idl) {
            $model = UjiLab::findOne(['ID_UJI' => $id, 'ID_LAB' => $idl]) ?: new UjiLab([
                'ID_UJI' => $uji->ID,
                'ID_LAB' => $idl,
            ]);

            $model->IDP_KOORDINATOR = $model->idLab->IDP_KETUA;
            $dataUjiLab[] = $model;
        }

        return $this->print($dataUjiLab);
    }

    /**
     * @param UjiLab[] $dataUjiLab
     * @return type
     */
    protected function print(array $dataUjiLab)
    {
        /* @var $identity User */

        $request = Yii::$app->request;
        $view = $this->action->id;

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;

            if (Yii::$app->request->post(StringHelper::basename(UjiLab::class))) {
                $success = true;

                MultipleModel::loadMultiple($dataUjiLab, $request->post());

                foreach ($dataUjiLab as $i => $ujiLab) {
                    $kode = UjiLab::maxKode($ujiLab->ID_LAB);
                    $ujiLab->NO_CU_LAB = $ujiLab->NO_CU_LAB ?: $kode + 1;
                    $ujiLab->setKode($kode + 1);

                    if ($ujiLab->save()) {
                        $this->saveRiwayatUji($ujiLab);
                        $ids[] = $ujiLab->ID;
                    } else {
                        $success = false;
                    }
                }

                if ($success) {
                    return [
                        'forceReload' => '#crud-datatable-pjax',
                        'title' => Yii::t('app', 'Labelisasi'),
                        'content' => '<p>Generate label berhasil. Silakan cetak label melalui tombol dibawah.</p>',
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::a(
                                Yii::t('app', 'Cetak'),
                                ['cetak', 'ids' => implode(',', $ids)],
                                ['class' => 'btn btn-primary', 'target' => '_blank']
                            ),
                    ];
                }

                return [
                    'title' => Yii::t('app', 'Labelisasi'),
                    'content' => $this->renderAjax($view, [
                        'dataUjiLab' => $dataUjiLab,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }

            return [
                'title' => Yii::t('app', 'Labelisasi'),
                'content' => $this->renderAjax($view, [
                    'dataUjiLab' => $dataUjiLab,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::button(
                        Yii::t('app', 'Simpan'),
                        ['class' => 'btn btn-primary', 'type' => 'submit']
                    ),
            ];
        }

        if (Yii::$app->request->post(StringHelper::basename(UjiLab::class))) {
            $ids = [];
            $success = true;
            MultipleModel::loadMultiple($dataUjiLab, $request->post());

            foreach ($dataUjiLab as $i => $ujiLab) {
                $kode = UjiLab::maxKode($ujiLab->ID_LAB);
                $ujiLab->NO_CU_LAB = $ujiLab->NO_CU_LAB ?: $kode + 1;
                $ujiLab->setKode($kode + 1);

                if ($ujiLab->save()) {
                    $this->saveRiwayatUji($ujiLab);
                    $ids[] = $ujiLab->ID;
                } else {
                    $success = false;
                }
            }

            if ($success) {
                return $this->redirect(['cetak', 'ids' => implode(',', $ids)]);
            }

            return $this->render($view, [
                'dataUjiLab' => $dataUjiLab,
            ]);
        }

        return $this->render($view, [
            'dataUjiLab' => $dataUjiLab,
        ]);
    }

    /**
     * @param string $ids IDs of UjiLab separated by coma
     * @return mixed
     */
    public function actionCetak($ids)
    {
        $this->layout = 'label';
        $dataUjiLab = UjiLab::find()
            ->where(['in', 'ID', explode(',', $ids)])
            ->indexBy('NO_CETAK')
            ->all();
        return $this->render('cetak', ['dataUjiLab' => $dataUjiLab]);
    }

    /**
     * @param UjiLab $ujiLab
     */
    protected function saveRiwayatUji(UjiLab $ujiLab)
    {
        $uji = $ujiLab->idUji;

        $idsLab1 = $ujiLab->getIdUji()
            ->select(['DISTINCT "ID_LAB"'])
            ->from(['A' => Uji::tableName()])
            ->joinWith([
                'dataUjiParameter' => function (ActiveQuery $q) {
                    return $q->from(['B' => UjiParameter::tableName()]);
                },
            ], false)
            ->andWhere(['A.ID_STATUS_UJI' => 4])
            ->column();

        $idsLab2 = UjiLab::find()
            ->select(['DISTINCT "ID_LAB"'])
            ->where(['ID_UJI' => $ujiLab->ID_UJI])
            ->column();

        if ($idsLab1 && !array_diff($idsLab1, $idsLab2)) {
            /* @var $identity \common\models\User */
            /* @var $pegawai \common\models\simlab\Pegawai */

            $user = Yii::$app->user;
            $identity = $user->identity;
            $pegawai = $identity->idPegawai;

            $riwayatUji = new RiwayatUji([
                'ID_UJI' => $ujiLab->ID_UJI,
                'ID_PEGAWAI' => $pegawai->ID,
                'ID_STATUS_UJI' => 5,
                'TANGGAL' => DateHelper::dbDatetime(),
            ]);

            $success = $riwayatUji->save();

            if ($success) {
                $agenda = $uji->idAgenda;
                if ($agenda && $agenda->ID_STATUS_UJI == 4) {
                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 4])->count();
                    if (!$count) {
                        $riwayatAgenda = new RiwayatAgenda([
                            'ID_AGENDA' => $agenda->ID,
                            'ID_PEGAWAI' => $pegawai->ID,
                            'ID_STATUS_UJI' => 5,
                            'TANGGAL' => DateHelper::dbDatetime(),
                        ]);

                        if (!$riwayatAgenda->save()) {
                            $success = false;
                        }
                    }
                }
            }
        }
    }

    /**
     * Finds the Uji model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Uji the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findUji($id)
    {
        if (($model = Uji::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
