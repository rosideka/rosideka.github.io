<?php

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\DisposisiSearch;
use common\helpers\DateHelper;
use common\models\MultipleModel;
use common\models\simlab\Agenda;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use common\models\User;
use Yii;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * DisposisiController implements the CRUD actions for UjiParameter model.
 */
class DisposisiController extends Controller
{
    /**
     * Lists all UjiParameter models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new DisposisiSearch(['TAHUN_PERMOHONAN' => date('Y')]);
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function actionDisposisi($id)
    {
        $dataUjiParameter[$id] = $this->findUjiParameter($id);
        return $this->disposisi($dataUjiParameter);
    }

    /**
     * @return mixed
     */
    public function actionDisposisiSelected()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks'));
        $dataUjiParameter = UjiParameter::find()
            ->where(['in', 'ID', $pks])
            ->orderBy(['ID' => SORT_ASC])
            ->indexBy('ID')
            ->all();
        return $this->disposisi($dataUjiParameter);
    }

    /**
     * @param int $ida
     * @param int $idu
     * @param mixed $id
     * @return mixed
     */
    public function actionDisposisiAll($id)
    {
        $request = Yii::$app->request;
        $ujiLab = $this->findUjiLab($id);
        $dataUjiParameter = $ujiLab
            ->getDataUjiParameter()
            ->where(['in', 'ID_STATUS_PARAMETER', [2, 3]])
            ->orderBy(['ID' => SORT_ASC])
            ->indexBy('ID')
            ->all();

        if (!$dataUjiParameter) {
            if ($request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return [
                    'forceReload' => '#crud-datatable-pjax',
                    'title' => Yii::t('app', 'Informasi'),
                    'content' =>
                        '<div class="alert alert-danger">'
                        . Yii::t('app', 'Tidak terdapat uji dengan status diterima')
                        . '</div>',
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                        ),
                ];
            }
            Yii::$app->session->setFlash('danger', Yii::t('app', 'Tidak terdapat uji dengan status diterima'));
            return $this->redirect(['index']);
        }

        return $this->disposisi($dataUjiParameter);
    }

    /**
     * @param UjiParameter[] $dataUjiParameter
     * @return mixed
     */
    protected function disposisi(array $dataUjiParameter)
    {
        $request = Yii::$app->request;
        $view = $this->action->id;
        $dbDatetime = DateHelper::dbDatetime();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->post(StringHelper::basename(UjiParameter::class))) {
                MultipleModel::loadMultiple($dataUjiParameter, $request->post());
                MultipleModel::validateMultiple($dataUjiParameter);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = true;

                    if ($success) {
                        foreach ($dataUjiParameter as $ujiParameter) {
                            $ujiParameter->TANGGAL_DISPOSISI = $dbDatetime;
                            $ujiParameter->ID_STATUS_PARAMETER = 3;

                            if ($ujiParameter->save()) {
                                $this->saveRiwayatUji($ujiParameter);
                            } else {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();

                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Disposisi Uji Parameter'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Disposisi berhasi disimpan') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Disposisi Uji Parameter'),
                        'content' => $this->renderAjax($view, [
                            'dataUjiParameter' => $dataUjiParameter,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Disposisi Uji Parameter'),
                    'content' => $this->renderAjax($view, [
                        'dataUjiParameter' => $dataUjiParameter,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->post(StringHelper::basename(UjiParameter::class))) {
                MultipleModel::loadMultiple($dataUjiParameter, $request->post());
                MultipleModel::validateMultiple($dataUjiParameter);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = true;

                    if ($success) {
                        foreach ($dataUjiParameter as $ujiParameter) {
                            $ujiParameter->TANGGAL_DISPOSISI = $dbDatetime;
                            $ujiParameter->ID_STATUS_PARAMETER = 3;

                            if ($ujiParameter->save()) {
                                $this->saveRiwayatUji($ujiParameter);
                            } else {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Disposisi berhasil diterima.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render($view, [
                        'dataUjiParameter' => $dataUjiParameter,
                    ]);
                }
            } else {
                return $this->render($view, [
                    'dataUjiParameter' => $dataUjiParameter,
                ]);
            }
        }
    }

    /**
     * @param UjiParameter $ujiParameter
     * @return boolean
     */
    protected function saveRiwayatUji(UjiParameter $ujiParameter)
    {
        /* @var $identity User */
        $success = true;

        $uji = $ujiParameter->idUji;
        $dbDatetime = DateHelper::dbDatetime();
        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        if ($uji && $uji->ID_STATUS_UJI == 6) {
            $count = $uji->getDataUjiParameter()->where(['ID_STATUS_PARAMETER' => 2])->count();

            if (!$count) {
                $riwayatUji = new RiwayatUji([
                    'ID_UJI' => $uji->ID,
                    'ID_PEGAWAI' => $pegawai->ID,
                    'ID_STATUS_UJI' => 7,
                    'TANGGAL' => $dbDatetime,
                ]);

                if (!$riwayatUji->save()) {
                    $success = false;
                }
            }

            if ($success) {
                $agenda = Agenda::findOne($uji->ID_AGENDA);

                if ($agenda && $agenda->ID_STATUS_UJI == 6) {
                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 6])->count();
                    if (!$count) {
                        $riwayatAgenda = new RiwayatAgenda([
                            'ID_AGENDA' => $agenda->ID,
                            'ID_PEGAWAI' => $pegawai->ID,
                            'ID_STATUS_UJI' => 7,
                            'TANGGAL' => DateHelper::dbDatetime(),
                        ]);

                        if (!$riwayatAgenda->save()) {
                            $success = false;
                        }
                    }
                }
            }
        }

        return $success;
    }

    /**
     * Finds the UjiLab model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UjiLab the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findUjiLab($id)
    {
        if (($model = UjiLab::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    /**
     * Finds the UjiParameter model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UjiParameter the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findUjiParameter($id)
    {
        if (($model = UjiParameter::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
