<?php

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\SerahTerimaSearch;
use common\helpers\DateHelper;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\Uji;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use Yii;
use yii\db\ActiveQuery;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * SerahTerimaController implements the CRUD actions for UjiLab model.
 */
class SerahTerimaController extends Controller
{
    /**
     * Lists all UjiLab models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SerahTerimaSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Updates an existing UjiLab model.
     * For ajax request will return json object
     * and for non-ajax request if terima is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionTerima($id)
    {
        /* @var $identity \common\models\User */
        /* @var $pegawai \common\models\simlab\Pegawai */

        $request = Yii::$app->request;

        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        $model = $this->findModel($id);
        $model->setAttributes([
            'TGL_TERIMA' => date('Y-m-d'),
            'IDP_PENERIMA' => $pegawai->ID,
        ]);
        $model->setScenario('serah-terima');

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($model->load($request->post()) && $model->save()) {
                $this->saveRiwayatUji($model);
                return [
                    'forceReload' => '#crud-datatable-pjax',
                    'title' => Yii::t('app', 'Serah Terima Contoh Uji'),
                    'content' => '<span class="text-success">' . Yii::t('app', 'Serah terima contoh uji berhasil') . '</span>',
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::a(
                            Yii::t('app', 'Cetak'),
                            ['cetak', 'id' => $id],
                            ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                        ),
                ];
            }
            return [
                'title' => Yii::t('app', 'Serah Terima Contoh Uji'),
                'content' => $this->renderAjax('terima', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::button(
                        Yii::t('app', 'Simpan'),
                        ['class' => 'btn btn-primary', 'type' => 'submit']
                    ),
            ];
        }
        /*
         * Process for non-ajax request
         */
        if ($model->load($request->post()) && $model->save()) {
            $this->saveRiwayatUji($model);
            Yii::$app->session->setFlash('success', Yii::t('app', 'Serah terima contoh uji berhasil'));
            return $this->redirect(['index']);
        }

        return $this->render('terima', [
            'model' => $model,
        ]);
    }

    public function actionCetak($id)
    {
        $this->layout = '//print';
        $model = $this->findModel($id);
        return $this->render('cetak', [
            'model' => $model,
        ]);
    }

    /**
     * @param UjiLab $ujiLab
     */
    protected function saveRiwayatUji(UjiLab $ujiLab)
    {
        $uji = $ujiLab->idUji;

        $idsLab1 = $ujiLab->getIdUji()
            ->select(['DISTINCT "ID_LAB"'])
            ->from(['A' => Uji::tableName()])
            ->joinWith([
                'dataUjiParameter' => function (ActiveQuery $q) {
                    return $q->from(['B' => UjiParameter::tableName()]);
                },
            ], false)
            ->andWhere(['A.ID_STATUS_UJI' => 5])
            ->column();

        $idsLab2 = UjiLab::find()
            ->select(['DISTINCT "ID_LAB"'])
            ->where(['is not', 'TGL_TERIMA', null])
            ->column();

        if ($idsLab1 && !array_diff($idsLab1, $idsLab2)) {
            /* @var $identity \common\models\User */
            /* @var $pegawai \common\models\simlab\Pegawai */

            $user = Yii::$app->user;
            $identity = $user->identity;
            $pegawai = $identity->idPegawai;

            $riwayatUji = new RiwayatUji([
                'ID_UJI' => $ujiLab->ID_UJI,
                'ID_PEGAWAI' => $pegawai->ID,
                'ID_STATUS_UJI' => 6,
                'TANGGAL' => DateHelper::dbDatetime(),
            ]);

            $success = $riwayatUji->save();

            if ($success) {
                $agenda = $uji->idAgenda;
                if ($agenda && $agenda->ID_STATUS_UJI == 5) {
                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 4])->count();
                    if (!$count) {
                        $riwayatAgenda = new RiwayatAgenda([
                            'ID_AGENDA' => $agenda->ID,
                            'ID_PEGAWAI' => $pegawai->ID,
                            'ID_STATUS_UJI' => 6,
                            'TANGGAL' => DateHelper::dbDatetime(),
                        ]);

                        if (!$riwayatAgenda->save()) {
                            $success = false;
                        }
                    }
                }
            }
        }
    }

    /**
     * Finds the UjiLab model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UjiLab the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = UjiLab::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
