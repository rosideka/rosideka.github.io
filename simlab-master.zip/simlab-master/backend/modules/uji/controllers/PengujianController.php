<?php

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\PengujianSearch;
use common\helpers\DateHelper;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\UjiParameter;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * PengujianController implements the CRUD actions for UjiParameter model.
 */
class PengujianController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all UjiParameter models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PengujianSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * @param int $id
     * @return mixed
     * @throws Exception
     */
    public function actionMulai($id)
    {
        /* @var $identity \common\models\User */

        $request = Yii::$app->request;
        $ujiParameter = $this->findUjiParameter($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;

            $ujiParameter->ID_STATUS_PARAMETER = 4;
            $ujiParameter->TANGGAL_ANALISIS = DateHelper::dbDatetime();
            $transaction = Yii::$app->db->beginTransaction();

            try {
                $success = $ujiParameter->save();

                if ($success) {
                    $success = $this->saveRiwayatMulai($ujiParameter);
                }

                if ($success) {
                    $transaction->commit();
                    return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
                }

                throw new Exception(Yii::t('app', 'Terjadi kesalahan saat menyimpan data'));
            } catch (Exception $e) {
                $transaction->rollBack();
                return [
                    'title' => Yii::t('app', 'Mulai Analisis'),
                    'content' =>
                        '<span class="text-danger">'
                        . Yii::t('app', 'Terjadi kesalahan saat menyimpan data')
                        . '</span>',
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                        ),
                ];
            }
        } else {
            $ujiParameter->ID_STATUS_PARAMETER = 4;
            $transaction = Yii::$app->db->beginTransaction();

            try {
                $success = $ujiParameter->save();

                if ($success) {
                    $success = $this->saveRiwayatMulai($ujiParameter);
                }

                if ($success) {
                    $transaction->commit();
                    Yii::$app->session->setFlash('success', 'Anda berhasil memulai analisis');
                    return $this->redirect(['index']);
                }

                throw new Exception(Yii::t('app', 'Terjadi kesalahan saat menyimpan data'));
            } catch (Exception $e) {
                $transaction->rollBack();
                Yii::$app->session->setFlash('danger', 'Terjadi kesalahan saat menyimpan data');
                return $this->redirect(['index']);
            }
        }
    }

    public function actionSelesai($id)
    {
        /* @var $identity \common\models\User */

        $request = Yii::$app->request;
        $ujiParameter = $this->findUjiParameter($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($ujiParameter->load($request->post())) {
                $ujiParameter->ID_STATUS_PARAMETER = 5;
                $ujiParameter->TANGGAL_SELESAI = DateHelper::dbDatetime();
                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $ujiParameter->save();

                    if ($success) {
                        $success = $this->saveRiwayatSelesai($ujiParameter);
                    }

                    if ($success) {
                        $transaction->commit();
                        return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan saat menyimpan data'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Selesaikan Analisis'),
                        'content' => $this->renderAjax('selesai', [
                            'ujiParameter' => $ujiParameter,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Selesaikan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Selesaikan Analisis'),
                    'content' => $this->renderAjax('selesai', [
                        'ujiParameter' => $ujiParameter,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Selesaikan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            if ($ujiParameter->load($request->post())) {
                $ujiParameter->ID_STATUS_PARAMETER = 5;
                $ujiParameter->TANGGAL_SELESAI = DateHelper::dbDatetime();
                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $ujiParameter->save();

                    if ($success) {
                        $this->saveRiwayatSelesai($ujiParameter);
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', 'Anda berhasil menyelesaikan analisis');
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan saat menyimpan data'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->renderAjax('selesai', [
                        'ujiParameter' => $ujiParameter,
                    ]);
                }
            } else {
                return $this->renderAjax('selesai', [
                    'ujiParameter' => $ujiParameter,
                ]);
            }
        }
    }

    /**
     * @param UjiParameter $ujiParameter
     * @return boolean
     */
    protected function saveRiwayatMulai(UjiParameter $ujiParameter)
    {
        /* @var $user \yii\web\User */
        /* @var $identity \common\models\User */

        $success = true;

        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        $uji = $ujiParameter->idUji;
        $agenda = $uji->idAgenda;
        $dbDatetime = DateHelper::dbDatetime();

        if ($uji && $uji->ID_STATUS_UJI == 7) {
            $count = $uji->getDataUjiParameter()->where(['ID_STATUS_PARAMETER' => 3])->count();

            if (!$count) {
                $riwayatUji = new RiwayatUji([
                    'ID_UJI' => $uji->ID,
                    'ID_PEGAWAI' => $pegawai->ID,
                    'ID_STATUS_UJI' => 8,
                    'TANGGAL' => $dbDatetime,
                ]);

                if (!$riwayatUji->save()) {
                    $success = false;
                }
            }

            if ($success) {
                if ($agenda && $agenda->ID_STATUS_UJI == 7) {
                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 7])->count();
                    if (!$count) {
                        $riwayatAgenda = new RiwayatAgenda([
                            'ID_AGENDA' => $agenda->ID,
                            'ID_PEGAWAI' => $pegawai->ID,
                            'ID_STATUS_UJI' => 8,
                            'TANGGAL' => DateHelper::dbDatetime(),
                        ]);

                        if (!$riwayatAgenda->save()) {
                            $success = false;
                        }
                    }
                }
            }
        }

        return $success;
    }

    /**
     * @param UjiParameter $ujiParameter
     * @return boolean
     */
    protected function saveRiwayatSelesai(UjiParameter $ujiParameter)
    {
        /* @var $user \yii\web\User */
        /* @var $identity \common\models\User */

        $success = true;

        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        $uji = $ujiParameter->idUji;
        $agenda = $uji->idAgenda;
        $dbDatetime = DateHelper::dbDatetime();

        if ($uji && $uji->ID_STATUS_UJI == 8) {
            $count = $uji->getDataUjiParameter()->where(['ID_STATUS_PARAMETER' => 4])->count();

            if (!$count) {
                $riwayatUji = new RiwayatUji([
                    'ID_UJI' => $uji->ID,
                    'ID_PEGAWAI' => $pegawai->ID,
                    'ID_STATUS_UJI' => 9,
                    'TANGGAL' => $dbDatetime,
                ]);

                if (!$riwayatUji->save()) {
                    $success = false;
                }
            }

            if ($success) {
                if ($agenda && $agenda->ID_STATUS_UJI == 8) {
                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 8])->count();
                    if (!$count) {
                        $riwayatAgenda = new RiwayatAgenda([
                            'ID_AGENDA' => $agenda->ID,
                            'ID_PEGAWAI' => $pegawai->ID,
                            'ID_STATUS_UJI' => 9,
                            'TANGGAL' => DateHelper::dbDatetime(),
                        ]);

                        if (!$riwayatAgenda->save()) {
                            $success = false;
                        }
                    }
                }
            }
        }

        return $success;
    }

    /**
     * Finds the UjiParameter model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UjiParameter the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findUjiParameter($id)
    {
        if (($model = UjiParameter::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
