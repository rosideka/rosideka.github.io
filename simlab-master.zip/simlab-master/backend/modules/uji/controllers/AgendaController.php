<?php

namespace backend\modules\uji\controllers;

use common\helpers\DateHelper;
use common\models\MultipleModel;
use common\models\simlab\Agenda;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\searches\AgendaSearch;
use common\models\simlab\UjiEvaluasi;
use common\models\simlab\UjiRekomendasi;
use Exception;
use kartik\mpdf\Pdf;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * AgendaController implements the CRUD actions for Agenda model.
 */
class AgendaController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Agenda models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AgendaSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single Agenda model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findAgenda($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Agenda'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function actionEvaluasi($id)
    {
        /* @var $identity \common\models\User */
        /* @var $dataUji \common\models\simlab\Uji[] */
        /* @var $dataRiwayatUji \common\models\simlab\RiwayatUji[] */
        /* @var $dataRekomendasi \common\models\simlab\UjiRekomendasi[] */

        $request = Yii::$app->request;
        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        $agenda = $this->findAgenda($id);
        $riwayatAgenda = new RiwayatAgenda([
            'ID_AGENDA' => $agenda->ID,
            'ID_PEGAWAI' => $pegawai->ID,
            'ID_STATUS_UJI' => $agenda->ID_STATUS_UJI,
            'TANGGAL' => DateHelper::dbDatetime(),
        ]);
        $dataUji = $agenda->getDataUji()->orderBy(['ID' => SORT_ASC])->indexBy('ID')->all();
        $dataRekomendasi = $agenda->getDataUjiRekomendasi()->orderBy(['ID' => SORT_ASC])->indexBy('ID')->all();
        $dataEvaluasi = $agenda->getDataUjiEvaluasi()->orderBy(['ID' => SORT_ASC])->indexBy('ID')->all();

        $dataRiwayatUji = [];

        foreach ($dataUji as $uji) {
            $dataRiwayatUji[$uji->ID] = new RiwayatUji([
                'ID_UJI' => $uji->ID,
                'ID_PEGAWAI' => $pegawai->ID,
                'ID_STATUS_UJI' => $uji->ID_STATUS_UJI,
                'TANGGAL' => DateHelper::dbDatetime(),
            ]);
        }

        if (!$dataRekomendasi) {
            foreach (array_keys($dataUji) as $idUji) {
                $dataRekomendasi[$idUji] = new UjiRekomendasi([
                    'ID' => $idUji,
                ]);
            }
        }

        if (!$dataEvaluasi) {
            foreach (array_keys($dataUji) as $idUji) {
                $dataEvaluasi[$idUji] = new UjiEvaluasi([
                    'ID' => $idUji,
                ]);
            }
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            $footer = '';

            if (!in_array($agenda->ID_STATUS_UJI, [1, 2])) {
                $footer .= Html::a(
                    '<i class="glyphicon glyphicon-send"></i> ' . Yii::t('app', 'Email'),
                    ['cetak', 'id' => $agenda->ID],
                    ['class' => 'btn btn-success']
                );
            }

            if ($request->isPost) {
                $agenda->load($request->post());
                $riwayatAgenda->load($request->post());
                MultipleModel::loadMultiple($dataRekomendasi, $request->post());
                MultipleModel::loadMultiple($dataRiwayatUji, $request->post());
                MultipleModel::loadMultiple($dataEvaluasi, $request->post());

                $agenda->validate();
                $riwayatAgenda->load($request->post());
                MultipleModel::validateMultiple($dataRekomendasi);
                MultipleModel::validateMultiple($dataRiwayatUji);
                MultipleModel::validateMultiple($dataEvaluasi);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $agenda->save();

                    if ($success) {
                        foreach ($dataRekomendasi as $idr => $rekomendasi) {
                            if (!$rekomendasi->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataEvaluasi as $ide => $evaluasi) {
                            if (!$evaluasi->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataRiwayatUji as $riwayatUji) {
                            if ($riwayatUji->ID_STATUS_UJI == $dataUji[$riwayatUji->ID_UJI]->ID_STATUS_UJI) {
                                continue;
                            }

                            if (!$riwayatUji->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        if ($riwayatAgenda->ID_STATUS_UJI != $agenda->ID_STATUS_UJI) {
                            if (!$riwayatAgenda->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();

                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Update Rekomendasi'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Rekomendasi berhasi disimpan') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                ) . $footer,
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Update Rekomendasi'),
                        'content' => $this->renderAjax('evaluasi', [
                            'agenda' => $agenda,
                            'riwayatAgenda' => $riwayatAgenda,
                            'dataUji' => $dataUji,
                            'dataRekomendasi' => $dataRekomendasi,
                            'dataRiwayatUji' => $dataRiwayatUji,
                            'dataEvaluasi' => $dataEvaluasi,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . $footer
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Update Rekomendasi'),
                    'content' => $this->renderAjax('evaluasi', [
                        'agenda' => $agenda,
                        'riwayatAgenda' => $riwayatAgenda,
                        'dataUji' => $dataUji,
                        'dataRekomendasi' => $dataRekomendasi,
                        'dataRiwayatUji' => $dataRiwayatUji,
                        'dataEvaluasi' => $dataEvaluasi,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . $footer
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $agenda->load($request->post());
                $riwayatAgenda->load($request->post());
                MultipleModel::loadMultiple($dataRekomendasi, $request->post());
                MultipleModel::loadMultiple($dataRiwayatUji, $request->post());
                MultipleModel::loadMultiple($dataEvaluasi, $request->post());

                $agenda->validate();
                $riwayatAgenda->load($request->post());
                MultipleModel::validateMultiple($dataRekomendasi);
                MultipleModel::validateMultiple($dataRiwayatUji);
                MultipleModel::validateMultiple($dataEvaluasi);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $agenda->save();

                    if ($success) {
                        foreach ($dataRekomendasi as $idr => $rekomendasi) {
                            if (!$rekomendasi->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataEvaluasi as $ide => $evaluasi) {
                            if (!$evaluasi->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Rekomendasi berhasil diupdate.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('evaluasi', [
                        'agenda' => $agenda,
                        'riwayatAgenda' => $riwayatAgenda,
                        'dataUji' => $dataUji,
                        'dataRekomendasi' => $dataRekomendasi,
                        'dataRiwayatUji' => $dataRiwayatUji,
                        'dataEvaluasi' => $dataEvaluasi,
                    ]);
                }
            } else {
                return $this->render('evaluasi', [
                    'agenda' => $agenda,
                    'riwayatAgenda' => $riwayatAgenda,
                    'dataUji' => $dataUji,
                    'dataRekomendasi' => $dataRekomendasi,
                    'dataRiwayatUji' => $dataRiwayatUji,
                    'dataEvaluasi' => $dataEvaluasi,
                ]);
            }
        }
    }

    /**
     * @param $id
     * @return mixed
     */
    public function actionCetak($id)
    {
        $agenda = $this->findAgenda($id);
        $member = $agenda->idMember;

        $content = $this->renderPartial('cetak', [
            'agenda' => $agenda,
            'member' => $member,
        ]);

        $response = Yii::$app->response;
        $response->format = Response::FORMAT_RAW;
        $response->headers->add('Content-Type', 'application/pdf');

        $pdf = new Pdf([
            'mode' => Pdf::MODE_CORE,
            'format' => Pdf::FORMAT_A4,
            'orientation' => Pdf::ORIENT_PORTRAIT,
            'destination' => Pdf::DEST_BROWSER,
            'content' => $content,
            'cssIanline' => $this->renderPartial('cetak/_style.css'),
            'options' => ['title' => Yii::t('app', 'EVALUASI-PERMINTAAN-PENGUJIAN-{KODE}', ['KODE' => $agenda->KODE])],
            'filename' => Yii::t('app', 'EVALUASI-PERMINTAAN-PENGUJIAN-{KODE}' . '.pdf', ['KODE' => $agenda->KODE]),
            'methods' => [
                'SetHeader' => [''],
                'SetFooter' => [''],
            ],
        ]);

        return $pdf->render();
    }

    /**
     * Finds the Agenda model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Agenda the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findAgenda($id)
    {
        if (($model = Agenda::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
