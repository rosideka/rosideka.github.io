<?php

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\PenerimaanSearch;
use common\helpers\DateHelper;
use common\models\MultipleModel;
use common\models\simlab\Agenda;
use common\models\simlab\RiwayatAgenda;
use common\models\simlab\RiwayatUji;
use common\models\simlab\Uji;
use common\models\simlab\UjiParameter;
use Exception;
use Yii;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * PenerimaanController implements the CRUD actions for Uji model.
 */
class PenerimaanController extends Controller
{
    /**
     * Lists all Uji models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PenerimaanSearch(['TAHUN_PERMOHONAN' => date('Y')]);
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single Uji model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findAgenda($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Uji'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['view', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function actionTerima($id)
    {
        $dataUji[$id] = $this->findUji($id);

        return $this->terima($dataUji);
    }

    /**
     * @return mixed
     */
    public function actionTerimaSelected()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks'));
        $dataUji = Uji::find()->where(['in', 'ID', $pks])->orderBy(['ID' => SORT_ASC])->indexBy('ID')->all();

        return $this->terima($dataUji);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function actionTerimaAll($id)
    {
        $request = Yii::$app->request;

        $agenda = $this->findAgenda($id);
        $dataUji = $agenda->getDataUji()
            ->where(['in', 'ID_STATUS_UJI', [3, 4]])
            ->orderBy(['ID' => SORT_ASC])
            ->indexBy('ID')
            ->all();

        if (!$dataUji) {
            if ($request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return [
                    'forceReload' => '#crud-datatable-pjax',
                    'title' => Yii::t('app', 'Informasi'),
                    'content' =>
                        '<div class="alert alert-danger">'
                        . Yii::t('app', 'Tidak terdapat uji dengan status diterima')
                        . '</div>',
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                        ),
                ];
            }
            Yii::$app->session->setFlash('danger', Yii::t('app', 'Tidak terdapat uji dengan status diterima'));
            return $this->redirect(['index']);
        }

        return $this->terima($dataUji);
    }

    /**
     * @param Uji[] $dataUji
     * @return mixed
     */
    protected function terima(array $dataUji)
    {
        /* @var $identity \common\models\User */

        $request = Yii::$app->request;
        $view = $this->action->id;

        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->post(StringHelper::basename(Uji::class))) {
                MultipleModel::loadMultiple($dataUji, $request->post());
                MultipleModel::validateMultiple($dataUji);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = true;

                    foreach ($dataUji as $uji) {
                        $uji->setScenario('penerimaan');

                        if ($uji->save()) {
                            if ($uji->ID_STATUS_UJI == 3) {
                                $riwayatUji = new RiwayatUji([
                                    'ID_UJI' => $uji->ID,
                                    'ID_PEGAWAI' => $pegawai->ID,
                                    'ID_STATUS_UJI' => 4,
                                    'TANGGAL' => DateHelper::dbDatetime(),
                                ]);

                                if ($riwayatUji->save()) {
                                    UjiParameter::updateAll(
                                        ['ID_STATUS_PARAMETER' => 2],
                                        ['ID_UJI' => $uji->ID, 'ID_STATUS_PARAMETER' => 1]
                                    );
                                } else {
                                    $success = false;
                                }
                            }

                            if ($success) {
                                $agenda = Agenda::findOne($uji->ID_AGENDA);

                                if ($agenda && $agenda->ID_STATUS_UJI == 3) {
                                    $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 3])->count();
                                    if (!$count) {
                                        $agenda->IDP_PENERIMA = $pegawai->ID;
                                        $agenda->save();

                                        $riwayatAgenda = new RiwayatAgenda([
                                            'ID_AGENDA' => $agenda->ID,
                                            'ID_PEGAWAI' => $pegawai->ID,
                                            'ID_STATUS_UJI' => 4,
                                            'TANGGAL' => DateHelper::dbDatetime(),
                                        ]);

                                        if (!$riwayatAgenda->save()) {
                                            $success = false;
                                        }
                                    }
                                }
                            }
                        } else {
                            $success = false;
                        }
                    }

                    if ($success) {
                        $transaction->commit();

                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Penerimaan Contoh Uji'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Penerimaan berhasi disimpan') . '</span>',
                            'footer' => Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            ),
                        ];
                    }

                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Penerimaan Contoh Uji'),
                        'content' => $this->renderAjax($view, [
                            'dataUji' => $dataUji,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            }

            return [
                'title' => Yii::t('app', 'Penerimaan Contoh Uji'),
                'content' => $this->renderAjax($view, [
                    'dataUji' => $dataUji,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::button(
                        Yii::t('app', 'Simpan'),
                        ['class' => 'btn btn-primary', 'type' => 'submit']
                    ),
            ];
        }

        /*
         * Process for non-ajax request
         */
        if ($request->post(StringHelper::basename(Uji::class))) {
            MultipleModel::loadMultiple($dataUji, $request->post());
            MultipleModel::validateMultiple($dataUji);

            $transaction = Yii::$app->db->beginTransaction();

            try {
                $success = true;

                foreach ($dataUji as $uji) {
                    $uji->setScenario('penerimaan');

                    if ($uji->save()) {
                        if ($uji->ID_STATUS_UJI == 3) {
                            $riwayatUji = new RiwayatUji([
                                'ID_UJI' => $uji->ID,
                                'ID_PEGAWAI' => $pegawai->ID,
                                'ID_STATUS_UJI' => 4,
                                'TANGGAL' => DateHelper::dbDatetime(),
                            ]);

                            if ($riwayatUji->save()) {
                                UjiParameter::updateAll(
                                    ['ID_STATUS_PARAMETER' => 2],
                                    ['ID_UJI' => $uji->ID, 'ID_STATUS_PARAMETER' => 1]
                                );
                            } else {
                                $success = false;
                            }
                        }

                        if ($success) {
                            $agenda = Agenda::findOne($uji->ID_AGENDA);

                            if ($agenda && $agenda->ID_STATUS_UJI == 3) {
                                $count = $agenda->getDataUji()->where(['ID_STATUS_UJI' => 3])->count();
                                if (!$count) {
                                    $agenda->IDP_PENERIMA = $pegawai->ID;
                                    $agenda->save();

                                    $riwayatAgenda = new RiwayatAgenda([
                                        'ID_AGENDA' => $agenda->ID,
                                        'ID_PEGAWAI' => $pegawai->ID,
                                        'ID_STATUS_UJI' => 4,
                                        'TANGGAL' => DateHelper::dbDatetime(),
                                    ]);

                                    if (!$riwayatAgenda->save()) {
                                        $success = false;
                                    }
                                }
                            }
                        }
                    } else {
                        $success = false;
                    }
                }

                if ($success) {
                    $transaction->commit();
                    Yii::$app->session->setFlash('success', Yii::t('app', 'Penerimaan berhasil diterima.'));
                    return $this->redirect(['index']);
                }

                throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
            } catch (Exception $e) {
                $transaction->rollBack();
                return $this->render($view, [
                    'dataUji' => $dataUji,
                ]);
            }
        }

        return $this->render($view, [
            'dataUji' => $dataUji,
        ]);
    }

    /**
     * Finds the Uji model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Agenda the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findAgenda($id)
    {
        if (($model = Agenda::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }

    /**
     * Finds the Uji model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Uji the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findUji($id)
    {
        if (($model = Uji::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
