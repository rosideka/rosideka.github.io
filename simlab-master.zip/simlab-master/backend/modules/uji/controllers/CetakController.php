<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace backend\modules\uji\controllers;

use backend\modules\uji\models\LabelSearch;
use common\models\simlab\Agenda;
use DateTime;
use Yii;
use yii\helpers\Html;
use yii\helpers\StringHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class CetakController extends Controller
{
    /**
     * @param $id
     * @return array|string
     */
    public function actionView($id)
    {
        /* @var $user \common\models\User */

        $request = Yii::$app->request;

        $agenda = $this->findAgenda($id);

        $items = [
            [
                'title' => Yii::t('app', 'Surat Permintaan'),
                'description' => Yii::t('app', 'Surat Permintaan Pengujian'),
                'url' => ['cetak', 'id' => $id, 'd' => 'permintaan'],
            ],
            [
                'title' => Yii::t('app', 'Invoice'),
                'description' => Yii::t('app', 'Invoice Pembayaran'),
                'url' => ['cetak', 'id' => $id, 'd' => 'invoice'],
            ],
            [
                'title' => Yii::t('app', 'Surat Evaluasi'),
                'description' => Yii::t('app', 'Surat Evaluasi Permintaan'),
                'url' => ['cetak', 'id' => $id, 'd' => 'evaluasi'],
                'visible' => $agenda->ID_STATUS_UJI >= 3,
            ],
            [
                'title' => Yii::t('app', 'Kesepakatan Pelaksanaan'),
                'description' => Yii::t('app', 'Kesepakatan Pelaksanaan Pengujian'),
                'url' => ['cetak', 'id' => $id, 'd' => 'kesepakatan'],
                'visible' => $agenda->ID_STATUS_UJI >= 3,
            ],
            [
                'title' => Yii::t('app', 'BA Pengambilan CU'),
                'description' => Yii::t('app', 'Berita Acara Pengambilan Contoh Uji'),
                'url' => ['cetak', 'id' => $id, 'd' => 'pengambilan'],
                'visible' => $agenda->ID_STATUS_UJI >= 3,
            ],
            [
                'title' => Yii::t('app', 'BA Penerimaan CU'),
                'description' => Yii::t('app', 'Berita Acara Penerimaan Contoh Uji'),
                'url' => ['cetak', 'id' => $id, 'd' => 'penerimaan'],
                'visible' => $agenda->ID_STATUS_UJI >= 4,
            ],
            [
                'title' => Yii::t('app', 'Label Contoh Uji'),
                'description' => Yii::t('app', 'Lembar Serah Terima Dari Penerima Contoh Uji  Kepada Koordinator Analis'),
                'url' => [
                    'label/index',
                    StringHelper::basename(LabelSearch::class) => [
                        'TAHUN_PERMOHONAN' => (new DateTime($agenda->TANGGAL_PERMOHONAN))->format('Y'),
                        'KODE_AGENDA' => $agenda->KODE,
                    ],
                ],
                'visible' => $agenda->ID_STATUS_UJI >= 4,
            ],
            [
                'title' => Yii::t('app', 'Lembar Serah Terima Koordinator'),
                'description' => Yii::t('app', 'Lembar Serah Terima Dari Penerima Contoh Uji  Kepada Koordinator Analis'),
                'url' => ['serah-terima/index'],
                'visible' => $agenda->ID_STATUS_UJI >= 5,
            ],
            [
                'title' => Yii::t('app', 'Lembar Kendali CU'),
                'description' => Yii::t('app', 'Lembar Kendali Contoh Uji'),
                'url' => ['cetak', 'id' => $id, 'd' => 'lembar-kendali'],
                'visible' => $agenda->ID_STATUS_UJI >= 6,
            ],
        ];

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Cetak Pengujian'),
                'content' => $this->renderAjax('view', [
                    'agenda' => $agenda,
                    'items' => $items,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-defaul', 'data-dismiss' => 'modal']
                    ),
            ];
        }
        return $this->render('view', [
            'agenda' => $agenda,
            'items' => $items,
        ]);
    }

    /**
     * @param $id
     * @param mixed $d
     * @param mixed $type
     * @return string
     */
    public function actionCetak($id, $d, $type = 'print')
    {
        /* @var $user \common\models\User */

        $this->layout = '//print';
        $agenda = $this->findAgenda($id);
        $pageOptions = [];

        if (in_array($d, ['permintaan', 'label-cu'])) {
            $pageOptions['header'] = false;
        }

        if (in_array($d, ['permintaan', 'pengambilan', 'serah-terima', 'lembar-kendali'])) {
            $this->layout = '//docx';
        }

        return $this->render('cetak', [
            'agenda' => $agenda,
            'pageOptions' => $pageOptions,
        ]);
    }

    /**
     * Finds the MemberPj model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Agenda the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findAgenda($id)
    {
        if (($model = Agenda::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException(Yii::t('app', 'Halaman yang diminta tidak tersedia.'));
    }
}
