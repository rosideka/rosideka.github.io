<?php

namespace backend\modules\uji\models;

use common\models\refs\RefBakuMutu;
use common\models\refs\RefLab;
use common\models\refs\RefMetodeUji;
use common\models\refs\RefParameter;
use common\models\refs\RefStatusParameter;
use common\models\simlab\Agenda;
use common\models\simlab\Paket;
use common\models\simlab\Pegawai;
use common\models\simlab\Uji;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use Yii;
use yii\base\Model;
use yii\data\SqlDataProvider;
use yii\db\ActiveQuery;

/**
 * DisposisiSearch represents the model behind the search form about `common\models\simlab\UjiParameter`.
 *
 * @property string $TAHUN_PERMOHONAN
 * @property string $KODE_AGENDA
 * @property string $KODE_UJI_LAB
 * @property array $IDS_PARAMETER
 */
class PengujianSearch extends UjiParameter
{
    /**
     * {@inheritdoc}
     */
    public function attributes()
    {
        return array_merge(parent::attributes(), [
            'ID_UJI_LAB',
            'KODE_UJI_LAB',
            'BAKU_MUTU',
            'METODE_UJI',
            'PENGUJI',
            'TAHUN_PERMOHONAN',
            'KODE_AGENDA',
            'IDS_PARAMETER',
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [[
                'TAHUN_PERMOHONAN',
                'ID_LAB',
                'ID_PAKET',
                'ID_BAKU_MUTU',
                'ID_METODE_UJI',
                'ID_PENGUJI',
                'ID_STATUS_PARAMETER',
            ], 'integer'],
            [['KODE_AGENDA', 'KODE_UJI_LAB', 'IDS_PARAMETER', 'TANGGAL_DISPOSISI', 'TANGGAL_ANALISIS'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return array_merge(parent::attributeLabels(), [
            'IDS_PARAMETER' => Yii::t('app', 'Parameter'),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function search($params)
    {
        $this->load($params);
        $query = static::query();
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Creates data provider instance with search query applied for export
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function export($params)
    {
        $this->load($params);
        $query = static::query()
            ->select([
                'A.*',
                'ID_AGENDA' => 'D.ID',
                'KODE_AGENDA' => 'D.KODE',
                'ID_UJI_LAB' => 'B.ID',
                'KODE_UJI_LAB' => 'B.KODE',
                'PAKET' => 'G.NAMA',
                'BAKU_MUTU' => 'H.NAMA_BAKU_MUTU',
                'METODE_UJI' => 'I.NAMA_METODE',
                'PENGUJI' => 'J.NAMA_LENGKAP',
                'STATUS_PARAMETER' => 'K.STATUS_PARAMETER',
            ]);
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Create query for data provider
     *
     * @return ActiveQuery
     */
    public static function query()
    {
        return UjiParameter::find()
            ->select([
                'ID' => 'A.ID',
                'KODE_UJI_LAB' => 'B.KODE',
                'LAB' => 'F.NAMA',
                'RUMUS' => 'A.RUMUS',
                'NAMA' => 'A.NAMA',
                'PAKET' => 'G.NAMA',
                'BAKU_MUTU' => 'H.NAMA_BAKU_MUTU',
                'METODE_UJI' => 'I.NAMA_METODE',
                'ID_STATUS_PARAMETER' => 'A.ID_STATUS_PARAMETER',
                'PENGUJI' => 'J.NAMA_LENGKAP',
                'STATUS_PARAMETER' => 'K.STATUS_PARAMETER',
                'TANGGAL_ANALISIS' => 'A.TANGGAL_ANALISIS',
                'TANGGAL_DISPOSISI' => 'A.TANGGAL_DISPOSISI',
                'TANGGAL_SELESAI' => 'A.TANGGAL_SELESAI',
                'KETERANGAN' => 'A.KETERANGAN',
            ])
            ->from(['A' => UjiParameter::tableName()])
            ->innerJoinWith([
                'idUjiLab' => function (ActiveQuery $q) {
                    return $q->from(['B' => UjiLab::tableName()]);
                },
            ])
            ->joinWith([
                'idUji' => function (ActiveQuery $q) {
                    return $q->from(['C' => Uji::tableName()])
                        ->joinWith([
                            'idAgenda' => function (ActiveQuery $q) {
                                return $q->from(['D' => Agenda::tableName()]);
                            },
                        ], false);
                },
                'idParameter' => function (ActiveQuery $q) {
                    return $q->from(['E' => RefParameter::tableName()]);
                },
                'idLab' => function (ActiveQuery $q) {
                    return $q->from(['F' => RefLab::tableName()]);
                },
                'idPaket' => function (ActiveQuery $q) {
                    return $q->from(['G' => Paket::tableName()]);
                },
                'idBakuMutu' => function (ActiveQuery $q) {
                    return $q->from(['H' => RefBakuMutu::tableName()]);
                },
                'idMetodeUji' => function (ActiveQuery $q) {
                    return $q->from(['I' => RefMetodeUji::tableName()]);
                },
                'idPenguji' => function (ActiveQuery $q) {
                    return $q->from(['J' => Pegawai::tableName()]);
                },
                'idStatusParameter' => function (ActiveQuery $q) {
                    return $q->from(['K' => RefStatusParameter::tableName()]);
                },
            ], false);
    }

    /**
     * @param ActiveQuery $query
     */
    protected function setFilter(ActiveQuery &$query)
    {
        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        /* @var $user \yii\web\User */
        /* @var $identity \common\models\User */
        /* @var $pegawai Pegawai */

        $user = Yii::$app->user;
        $identity = $user->identity;
        $pegawai = $identity->idPegawai;

        $query->andWhere([
            'A.ID_PENGUJI' => $pegawai->ID,
        ]);

        $query->andFilterWhere([
            'EXTRACT(YEAR FROM "D"."TANGGAL_PERMOHONAN")' => $this->TAHUN_PERMOHONAN,
            'D.KODE' => $this->KODE_AGENDA,
            'B.KODE' => $this->KODE_UJI_LAB,
            'B.ID_LAB' => $this->ID_LAB,
            'G.ID' => $this->ID_PAKET,
            'H.ID' => $this->ID_BAKU_MUTU,
            'I.ID' => $this->ID_METODE_UJI,
            'J.ID' => $this->ID_PENGUJI,
            'A.ID_STATUS_PARAMETER' => $this->ID_STATUS_PARAMETER,
        ]);

        $query->andFilterWhere(['in', 'A.ID_PARAMETER', $this->IDS_PARAMETER])
            ->andFilterWhere(['>=', 'A.TANGGAL_DISPOSISI', $this->TANGGAL_DISPOSISI])
            ->andFilterWhere(['>=', 'A.TANGGAL_ANALISIS', $this->TANGGAL_ANALISIS]);
    }
}
