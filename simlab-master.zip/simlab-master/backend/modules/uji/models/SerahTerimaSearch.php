<?php

namespace backend\modules\uji\models;

use common\models\refs\RefLab;
use common\models\refs\RefUjiRetensi;
use common\models\simlab\Pegawai;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use yii\base\Model;
use yii\data\SqlDataProvider;
use yii\db\ActiveQuery;
use yii\db\Expression;

/**
 * SerahTerimaSearch represents the model behind the search form about `common\models\simlab\UjiLab`.
 */
class SerahTerimaSearch extends UjiLab
{
    /**
     * {@inheritdoc}
     */
    public function attributes()
    {
        return array_merge(parent::attributes(), [
            'LAB',
            'RUMUS_PARAMETER',
            'UJI_RETENSI',
            'KOORDINATOR',
            'PENGIRIM',
            'PENERIMA',
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ID', 'ID_LAB', 'ID_UJI_RETENSI'], 'integer'],
            [['KODE', 'TGL_TERIMA', 'PENGIRIM'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function search($params)
    {
        $this->load($params);

        $queryUjiParameter = UjiParameter::find()
            ->from(['G' => UjiParameter::tableName()])
            ->select(['RUMUS_PARAMETER' => new Expression('string_agg ( DISTINCT "RUMUS", \', \' )')])
            ->where(['G.ID_UJI' => new Expression('"A"."ID_UJI"'), 'G.ID_LAB' => new Expression('"A"."ID_LAB"')]);

        $query = static::query()
            ->select([
                'ID' => 'A.ID',
                'KODE' => 'A.KODE',
                'LAB' => 'B.NAMA',
                'UJI_RETENSI' => 'CONCAT(\'[\', "C"."KODE", \']\', \' \', "C"."RETENSI")',
                'KOORDINATOR' => 'D.NAMA_LENGKAP',
                'PENGIRIM' => 'E.NAMA_LENGKAP',
                'PENERIMA' => 'F.NAMA_LENGKAP',
                'TGL_TERIMA' => 'A.TGL_TERIMA',
                'RUMUS_PARAMETER' => $queryUjiParameter,
            ]);
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes(), 'defaultOrder' => ['ID' => SORT_DESC]],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Creates data provider instance with search query applied for export
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function export($params)
    {
        $this->load($params);

        $queryUjiParameter = UjiParameter::find()
            ->from(['G' => UjiParameter::tableName()])
            ->select(['RUMUS_PARAMETER' => new Expression('string_agg ( DISTINCT "RUMUS", \', \' )')])
            ->where(['G.ID_UJI' => new Expression('"A"."ID_UJI"'), 'G.ID_LAB' => new Expression('"A"."ID_LAB"')]);

        $query = static::query()
            ->select([
                'A.*',
                'LAB' => 'B.NAMA',
                'UJI_RETENSI' => 'CONCAT(\'[\', "C"."KODE", \']\', \' \', "C"."RETENSI")',
                'KOORDINATOR' => 'D.NAMA_LENGKAP',
                'PENGIRIM' => 'E.NAMA_LENGKAP',
                'PENERIMA' => 'F.NAMA_LENGKAP',
                'TGL_TERIMA' => 'A.TGL_TERIMA',
                'RUMUS_PARAMETER' => $queryUjiParameter,
            ]);

        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Create query for data provider
     *
     * @return ActiveQuery
     */
    public static function query()
    {
        return UjiLab::find()
            ->from(['A' => UjiLab::tableName()])
            ->joinWith([
                'idLab' => function (ActiveQuery $q) {
                    return $q->from(['B' => RefLab::tableName()]);
                },
                'idUjiRetensi' => function (ActiveQuery $q) {
                    return $q->from(['C' => RefUjiRetensi::tableName()]);
                },
                'idpKoordinator' => function (ActiveQuery $q) {
                    return $q->from(['D' => Pegawai::tableName()]);
                },
                'idpPengirim' => function (ActiveQuery $q) {
                    return $q->from(['E' => Pegawai::tableName()]);
                },
                'idpPenerima' => function (ActiveQuery $q) {
                    return $q->from(['F' => Pegawai::tableName()]);
                },
            ], false);
    }

    protected function setFilter(ActiveQuery &$query)
    {
        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        $query->andFilterWhere([
            'A.ID' => $this->ID,
            'A.ID_LAB' => $this->ID_LAB,
            'A.ID_UJI_RETENSI' => $this->ID_UJI_RETENSI,
            'A.IDP_PENGIRIM' => $this->IDP_PENGIRIM,
        ]);

        $query->andFilterWhere(['ilike', 'A.KODE', $this->KODE])
            ->andFilterWhere(['>=', 'A.TGL_TERIMA', $this->TGL_TERIMA]);
    }
}
