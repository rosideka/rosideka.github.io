<?php

/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace backend\modules\uji\models;

use common\models\refs\RefLab;
use common\models\refs\RefStatusUji;
use common\models\simlab\Agenda;
use common\models\simlab\searches\UjiSearch;
use common\models\simlab\Uji;
use common\models\simlab\UjiLab;
use common\models\simlab\UjiParameter;
use Yii;
use yii\base\Model;
use yii\data\SqlDataProvider;
use yii\db\ActiveQuery;
use yii\db\Expression;

/**
 * Class LabelSearch
 * @package backend\modules\uji\models
 *
 * @property string $KODE_AGENDA
 * @property string $KODE_UJI
 * @property int TAHUN_PERMOHONAN
 * @property string $TANGGAL_PENERIMAAN_AWAL
 * @property string $TANGGAL_PENERIMAAN_AKHIR
 */
class LabelSearch extends UjiSearch
{
    /**
     * {@inheritdoc}
     */
    public function attributes()
    {
        return array_merge(parent::attributes(), [
            'TAHUN_PERMOHONAN',
            'TANGGAL_PENERIMAAN',
            'KODE_AGENDA',
            'KODE_UJI',
            'STATUS_UJI',
            'ID_LAB',
            'NAMA_LAB',
            'RUMUS_PARAMETER',
            'NAMA_PARAMETER',
            'NO_CU_LAB',
            'KODE_UJI_LAB',
            'TANGGAL_PENERIMAAN_AWAL',
            'TANGGAL_PENERIMAAN_AKHIR',
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [[
                'KODE_AGENDA', 'KODE_UJI', 'ASAL_CONTOH_UJI', 'TANGGAL_PENERIMAAN_AWAL', 'TANGGAL_PENERIMAAN_AKHIR',
            ], 'safe'],
            [[
                'TAHUN_PERMOHONAN', 'ID_JENIS_PAKET', 'ID_BAKU_MUTU', 'ID_KLASIFIKASI_LOKASI', 'ID_STATUS_UJI', 'ID_LAB',
            ], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'ID_AGENDA' => Yii::t('app', 'ID Agenda'),
            'KODE_AGENDA' => Yii::t('app', 'Kode Agenda'),
            'ID_UJI' => Yii::t('app', 'ID Uji'),
            'KODE_UJI' => Yii::t('app', 'Kode Uji'),
            'TAHUN_PERMOHONAN' => Yii::t('app', 'Tahun Permohonan'),
            'TANGGAL_PENERIMAAN' => Yii::t('app', 'Tgl. Penerimaan'),
            'ASAL_CONTOH_UJI' => Yii::t('app', 'Asal Contoh Uji'),
            'ID_STATUS_UJI' => Yii::t('app', 'ID Status Uji'),
            'STATUS_UJI' => Yii::t('app', 'Status Uji'),
            'KETERANGAN' => Yii::t('app', 'Keterangan'),
            'RUMUS_PARAMETER' => Yii::t('app', 'Rumus Parameter'),
            'NAMA_PARAMETER' => Yii::t('app', 'Nama Parameter'),
            'ID_LAB' => Yii::t('app', 'ID Lab'),
            'NAMA_LAB' => Yii::t('app', 'Nama Lab'),
            'TAHUN_PERMOHONAN' => Yii::t('app', 'Tahun Permohonan'),
            'JENIS_PAKET' => Yii::t('app', 'Jenis Paket'),
            'BAKU_MUTU' => Yii::t('app', 'Baku Mutu'),
            'KLASIFIKASI_LOKASI' => Yii::t('app', 'Klasifikasi Lokasi'),
            'TANGGAL_PENERIMAAN_AWAL' => Yii::t('app', 'Tgl. Penerimaan Awal'),
            'TANGGAL_PENERIMAAN_AKHIR' => Yii::t('app', 'Tgl. Penerimaan Akhir'),
        ];
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function search($params)
    {
        $this->load($params);
        $query = static::query();
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Creates data provider instance with search query applied for export
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function export($params)
    {
        $this->load($params);
        $query = static::query();
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Set query filter for searching and exporting
     *
     * @param ActiveQuery $query
     */
    protected function setFilter(ActiveQuery &$query)
    {
        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        $query->andFilterWhere([
            'EXTRACT(YEAR FROM "B"."TANGGAL_PERMOHONAN")' => $this->TAHUN_PERMOHONAN,
            'A.ID_JENIS_PAKET' => $this->ID_JENIS_PAKET,
            'A.ID_BAKU_MUTU' => $this->ID_BAKU_MUTU,
            'A.ID_KLASIFIKASI_LOKASI' => $this->ID_KLASIFIKASI_LOKASI,
            'A.ID_STATUS_UJI' => $this->ID_STATUS_UJI,
            'E.ID' => $this->ID_LAB,
        ]);

        $query->andFilterWhere(['ilike', 'B.KODE', $this->KODE_AGENDA])
            ->andFilterWhere(['ilike', 'A.KODE', $this->KODE_UJI])
            ->andFilterWhere(['ilike', 'A.ASAL_CONTOH_UJI', $this->ASAL_CONTOH_UJI])
            ->andFilterWhere(['>=', 'B.TANGGAL_PENERIMAAN', $this->TANGGAL_PENERIMAAN_AWAL])
            ->andFilterWhere(['<=', 'B.TANGGAL_PENERIMAAN', $this->TANGGAL_PENERIMAAN_AKHIR]);
    }

    /**
     * Create query for data provider
     *
     * @return ActiveQuery
     */
    public static function query()
    {
        $select = [
            'ID' => 'A.ID',
            'TAHUN_PERMOHONAN' => 'EXTRACT(YEAR FROM "B"."TANGGAL_PERMOHONAN")',
            'TANGGAL_PENERIMAAN' => 'B.TANGGAL_PENERIMAAN',
            'ID_AGENDA' => 'B.ID',
            'KODE_AGENDA' => 'B.KODE',
            'ID_UJI' => 'A.ID',
            'KODE_UJI' => 'A.KODE',
            'ASAL_CONTOH_UJI' => 'A.ASAL_CONTOH_UJI',
            'ID_STATUS_UJI' => 'A.ID_STATUS_UJI',
            'STATUS_UJI' => 'C.STATUS_UJI',
            'RUMUS_PARAMETER' => 'D.RUMUS_PARAMETER',
            'NAMA_PARAMETER' => 'D.NAMA_PARAMETER',
            'ID_LAB' => 'E.ID',
            'NAMA_LAB' => 'E.NAMA',
            'NO_CU_LAB' => 'F.NO_CU_LAB',
            'KODE_UJI_LAB' => 'F.KODE',
        ];

        $queryUjiParameter = UjiParameter::find()
            ->select([
                'ID_UJI' => 'ID_UJI',
                'ID_LAB' => 'ID_LAB',
                'RUMUS_PARAMETER' => new Expression('string_agg ( DISTINCT "RUMUS", \', \' )'),
                'NAMA_PARAMETER' => new Expression('string_agg ( DISTINCT "NAMA", \', \' )'),
            ])
            ->groupBy(['ID_UJI', 'ID_LAB']);

        return Uji::find()
            ->from(['A' => static::tableName()])
            ->select($select)
            ->joinWith([
                'idAgenda' => function (ActiveQuery $q) {
                    return $q->from(['B' => Agenda::tableName()]);
                },
                'idStatusUji' => function (ActiveQuery $q) {
                    return $q->from(['C' => RefStatusUji::tableName()]);
                },
            ], false)
            ->innerJoin(['D' => $queryUjiParameter], ['D.ID_UJI' => new Expression('"A"."ID"')])
            ->leftJoin(['E' => RefLab::tableName()], ['D.ID_LAB' => new Expression('"E"."ID"')])
            ->leftJoin(['F' => UjiLab::tableName()], [
                'F.ID_UJI' => new Expression('"D"."ID_UJI"'),
                'F.ID_LAB' => new Expression('"D"."ID_LAB"'),
            ]);
    }

    /**
     * @return Agenda|null
     */
    public function getAgendaByKode()
    {
        return Agenda::findOne(['KODE' => $this->KODE_AGENDA]);
    }
}
