<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace backend\modules\uji\models;

use common\models\refs\RefStatusUji;
use common\models\refs\RefUjiKemasan;
use common\models\refs\RefUjiKetersediaan;
use common\models\refs\RefUjiKondisi;
use common\models\refs\RefUjiKondisiDiterima;
use common\models\refs\RefUjiPengawetan;
use common\models\simlab\Agenda;
use common\models\simlab\searches\UjiSearch;
use common\models\simlab\Uji;
use Yii;
use yii\base\Model;
use yii\data\SqlDataProvider;
use yii\db\ActiveQuery;

/**
 * Class PenerimaanSearch
 * @package backend\modules\uji\models
 *
 * @property string $KODE_AGENDA
 * @property string $KODE_UJI
 * @property int TAHUN_PERMOHONAN
 */
class PenerimaanSearch extends UjiSearch
{
    /**
     * {@inheritdoc}
     */
    public function attributes()
    {
        return array_merge(parent::attributes(), [
            'KODE_AGENDA',
            'TAHUN_PERMOHONAN',
            'KODE_UJI',
            'UJI_KETERSEDIAAN',
            'UJI_PENGAWETAN',
            'UJI_KONDISI',
            'UJI_KONDISI_DITERIMA',
            'STATUS_UJI',
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KODE_AGENDA', 'KODE_UJI', 'ASAL_CONTOH_UJI', 'CATATAN_ABNORMALITAS'], 'safe'],
            [
                [
                    'ID_UJI_KETERSEDIAAN',
                    'ID_UJI_PENGAWETAN',
                    'ID_UJI_KONDISI',
                    'ID_UJI_KONDISI_DITERIMA',
                    'ID_JENIS_PAKET',
                    'ID_BAKU_MUTU',
                    'ID_KLASIFIKASI_LOKASI',
                    'TAHUN_PERMOHONAN',
                    'ID_STATUS_UJI',
                ],
                'integer',
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return array_merge(parent::attributeLabels(), [
            'ID_KLASIFIKASI_LOKASI' => Yii::t('app', 'ID Klasifikasi Lokasi'),
            'ID_UJI_KETERSEDIAAN' => Yii::t('app', 'ID Ketersediaan Rekaman'),
            'ID_UJI_KEMASAN' => Yii::t('app', 'ID Kemasan'),
            'ID_UJI_PENGAWETAN' => Yii::t('app', 'ID Proses Pengawetan'),
            'ID_UJI_KONDISI' => Yii::t('app', 'ID Kondisi Contoh Uji'),
            'ID_UJI_KONDISI_DITERIMA' => Yii::t('app', 'ID Kondisi Saat Diterima'),
            'ID_BAKU_MUTU' => Yii::t('app', 'ID Baku Mutu'),
            'ID_JENIS_PAKET' => Yii::t('app', 'ID Jenis Paket'),
            'ID_STATUS_UJI' => Yii::t('app', 'ID Status Uji'),
            'KLASIFIKASI_LOKASI' => Yii::t('app', 'Klasifikasi Lokasi'),
            'UJI_KETERSEDIAAN' => Yii::t('app', 'Ketersediaan Rekaman'),
            'UJI_KEMASAN' => Yii::t('app', 'Kemasan'),
            'UJI_PENGAWETAN' => Yii::t('app', 'Proses Pengawetan'),
            'UJI_KONDISI' => Yii::t('app', 'Kondisi Contoh Uji'),
            'UJI_KONDISI_DITERIMA' => Yii::t('app', 'Kondisi Saat Diterima'),
            'CATATAN_ABNORMALITAS' => Yii::t('app', 'Catatan Abnormalitas'),
            'JENIS_PAKET' => Yii::t('app', 'Jenis Paket'),
            'BAKU_MUTU' => Yii::t('app', 'Baku Mutu'),
            'STATUS_UJI' => Yii::t('app', 'Status Uji'),
            'TAHUN_PERMOHONAN' => Yii::t('app', 'Tahun Permohonan'),
            'ASAL_CONTOH_UJI' => Yii::t('app', 'Asal Contoh Uji'),
            'ASAL_CONTOH_UJI' => Yii::t('app', 'Asal Contoh Uji'),
            'TANGGAL_PENERIMAAN' => Yii::t('app', 'Tanggal Penerimaan'),
            'TANGGAL_PERMOHONAN' => Yii::t('app', 'Tanggal Permohonan'),
        ]);
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function search($params)
    {
        $this->load($params);
        $query = static::query();

        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        $query->andFilterWhere([
            'B.KODE' => $this->KODE_AGENDA,
            'EXTRACT(YEAR FROM "B"."TANGGAL_PERMOHONAN")' => $this->TAHUN_PERMOHONAN,
            'A.KODE' => $this->KODE_UJI,
            'A.ID_UJI_KETERSEDIAAN' => $this->ID_UJI_KETERSEDIAAN,
            'A.ID_UJI_PENGAWETAN' => $this->ID_UJI_PENGAWETAN,
            'A.ID_UJI_KONDISI' => $this->ID_UJI_KONDISI,
            'A.ID_UJI_KONDISI_DITERIMA' => $this->ID_UJI_KONDISI_DITERIMA,
            'A.ID_JENIS_PAKET' => $this->ID_JENIS_PAKET,
            'A.ID_BAKU_MUTU' => $this->ID_BAKU_MUTU,
            'A.ID_KLASIFIKASI_LOKASI' => $this->ID_KLASIFIKASI_LOKASI,
            'A.ID_STATUS_UJI' => $this->ID_STATUS_UJI,
        ]);

        $query->andFilterWhere(['ilike', 'A.KODE', $this->KODE_UJI])
            ->andFilterWhere(['ilike', 'A.ASAL_CONTOH_UJI', $this->ASAL_CONTOH_UJI])
            ->andFilterWhere(['ilike', 'A.CATATAN_ABNORMALITAS', $this->CATATAN_ABNORMALITAS]);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Creates data provider instance with search query applied for export
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function export($params)
    {
        $this->load($params);
        $query = static::query();

        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        $query->andFilterWhere([
            'B.KODE' => $this->KODE_AGENDA,
            'EXTRACT(YEAR FROM "B"."TANGGAL_PERMOHONAN")' => $this->TAHUN_PERMOHONAN,
            'A.KODE' => $this->KODE_UJI,
            'A.ID_UJI_KETERSEDIAAN' => $this->ID_UJI_KETERSEDIAAN,
            'A.ID_UJI_PENGAWETAN' => $this->ID_UJI_PENGAWETAN,
            'A.ID_UJI_KONDISI' => $this->ID_UJI_KONDISI,
            'A.ID_UJI_KONDISI_DITERIMA' => $this->ID_UJI_KONDISI_DITERIMA,
            'A.ID_JENIS_PAKET' => $this->ID_JENIS_PAKET,
            'A.ID_BAKU_MUTU' => $this->ID_BAKU_MUTU,
            'A.ID_KLASIFIKASI_LOKASI' => $this->ID_KLASIFIKASI_LOKASI,
            'A.ID_STATUS_UJI' => $this->ID_STATUS_UJI,
        ]);

        $query->andFilterWhere(['ilike', 'A.KODE', $this->KODE_UJI])
            ->andFilterWhere(['ilike', 'A.ASAL_CONTOH_UJI', $this->ASAL_CONTOH_UJI])
            ->andFilterWhere(['ilike', 'A.CATATAN_ABNORMALITAS', $this->CATATAN_ABNORMALITAS]);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'key' => 'ID',
            'totalCount' => $query->count(),
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Create query for data provider
     *
     * @return ActiveQuery
     */
    public static function query()
    {
        $select = [
            'ID' => 'A.ID',
            'ID_AGENDA' => 'B.KODE',
            'KODE_AGENDA' => 'B.KODE',
            'KODE_UJI' => 'A.KODE',
            'TAHUN_PERMOHONAN' => 'EXTRACT(YEAR FROM "B"."TANGGAL_PERMOHONAN")',
            'ASAL_CONTOH_UJI' => 'A.ASAL_CONTOH_UJI',
            'ID_UJI_KETERSEDIAAN' => 'A.ID_UJI_KETERSEDIAAN',
            'UJI_KETERSEDIAAN' => 'C.KETERSEDIAAN',
            'ID_UJI_KEMASAN' => 'A.ID_UJI_KEMASAN',
            'UJI_KEMASAN' => 'D.KEMASAN',
            'ID_UJI_PENGAWETAN' => 'A.ID_UJI_PENGAWETAN',
            'UJI_PENGAWETAN' => 'E.PENGAWETAN',
            'ID_UJI_KONDISI' => 'A.ID_UJI_KONDISI',
            'UJI_KONDISI' => 'F.KONDISI',
            'ID_UJI_KONDISI_DITERIMA' => 'A.ID_UJI_KONDISI_DITERIMA',
            'UJI_KONDISI_DITERIMA' => 'G.KONDISI_TERIMA',
            'CATATAN_ABNORMALITAS' => 'A.CATATAN_ABNORMALITAS',
            'ID_STATUS_UJI' => 'A.ID_STATUS_UJI',
            'STATUS_UJI' => 'H.STATUS_UJI',
            'KETERANGAN' => 'A.KETERANGAN',
            'TANGGAL_PERMOHONAN' => 'B.TANGGAL_PERMOHONAN',
            'TANGGAL_PENERIMAAN' => 'B.TANGGAL_PENERIMAAN',
        ];

        /*
        if (Yii::$app->db->driverName === 'pgsql') {
            $select['UJI_KEMASAN'] = UjiKemasan::find()
                ->from(['SA' => UjiKemasan::tableName()])
                ->select(['string_agg(DISTINCT "SB"."KEMASAN", \',\')'])
                ->joinWith([
                    'idUjiKemasan' => function (ActiveQuery $q) {
                        return $q->from(['SB' => RefUjiKemasan::tableName()]);
                    },
                ])
                ->where(['SA.ID_UJI' => new Expression('"A"."ID"')])
                ->groupBy(['SA.ID_UJI']);
        } else {
            $select['UJI_KEMASAN'] = UjiKemasan::find()
                ->from(['SA' => UjiKemasan::tableName()])
                ->select(['GROUP_CONCAT("SB"."KEMASAN" SEPARATOR \', \')'])
                ->joinWith([
                    'idUjiKemasan' => function (ActiveQuery $q) {
                        return $q->from(['SB' => RefUjiKemasan::tableName()]);
                    },
                ])
                ->where(['SA.ID_UJI' => new Expression('"A"."ID"')])
                ->groupBy(['SA.ID_UJI']);
        }
        */

        return Uji::find()
            ->from(['A' => static::tableName()])
            ->select($select)
            ->joinWith([
                'idAgenda' => function (ActiveQuery $q) {
                    return $q->from(['B' => Agenda::tableName()]);
                },
                'idUjiKetersediaan' => function (ActiveQuery $q) {
                    return $q->from(['C' => RefUjiKetersediaan::tableName()]);
                },
                'idUjiKemasan' => function (ActiveQuery $q) {
                    return $q->from(['D' => RefUjiKemasan::tableName()]);
                },
                'idUjiPengawetan' => function (ActiveQuery $q) {
                    return $q->from(['E' => RefUjiPengawetan::tableName()]);
                },
                'idUjiKondisi' => function (ActiveQuery $q) {
                    return $q->from(['F' => RefUjiKondisi::tableName()]);
                },
                'idUjiKondisiDiterima' => function (ActiveQuery $q) {
                    return $q->from(['G' => RefUjiKondisiDiterima::tableName()]);
                },
                'idStatusUji' => function (ActiveQuery $q) {
                    return $q->from(['H' => RefStatusUji::tableName()]);
                },
            ], false);
    }

    /**
     * @return Agenda|null
     */
    public function getAgendaByKode()
    {
        return Agenda::findOne(['KODE' => $this->KODE_AGENDA]);
    }
}
