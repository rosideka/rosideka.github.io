<?php
return [
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'ID',
    // ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USER_ID',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USER_IP',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ACTION_TYPE',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ACTION_DATE',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'APP_NAME',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CONTROLLER',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CONTROLLER_ID',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ACTION_ID',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TABLE_NAME',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'MODEL_NAME',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'MODEL_ID',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'DATA_OLD',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'DATA_NEW',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IS_ROLLBACK',
    ],
];
