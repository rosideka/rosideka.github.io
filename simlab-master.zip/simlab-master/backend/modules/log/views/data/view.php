<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\logs\LogData */

$this->title = Yii::t('app', 'Log Data');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Log Datum'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="log-data-view">
    <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#log-data-1" data-toggle="tab"><?= Yii::t('app', 'Detail Aksi') ?></a></li>
            <li><a href="#log-data-2" data-toggle="tab"><?= Yii::t('app', 'Data Beda') ?></a></li>
            <li><a href="#log-data-3" data-toggle="tab"><?= Yii::t('app', 'Data Lama') ?></a></li>
            <li><a href="#log-data-4" data-toggle="tab"><?= Yii::t('app', 'Data Baru') ?></a></li>
        </ul>
        <div class="tab-content">
            <div class="active tab-pane" id="log-data-1">
                <?= DetailView::widget([
                    'model' => $model,
                    'attributes' => [
                        'USER_ID',
                        [
                            'label' => 'Username',
                            'value' => $model->USER_ID ? $model->userId->USERNAME : null,
                        ],
                        'USER_IP',
                        [
                            'attribute' => 'ACTION_TYPE',
                            'value' => $model->getActionTypeText(),
                        ],
                        'ACTION_DATE',
                        'APP_NAME',
                        'CONTROLLER',
                        'CONTROLLER_ID',
                        'ACTION_ID',
                        'TABLE_NAME',
                        'MODEL_NAME',
                        'MODEL_ID',
                    ],
                ]) ?>
            </div>
            <div class="tab-pane" id="log-data-2">
                <?= DetailView::widget([
                    'model' => array_filter($model->getDataDiff(), function ($data) {
                        return !is_array($data);
                    }),
                ]) ?>
            </div>
            <div class="tab-pane" id="log-data-3">
                <?= DetailView::widget([
                    'model' => array_filter($model->getDataOld(), function ($data) {
                        return !is_array($data);
                    }),
                ]) ?>
            </div>
            <div class="tab-pane" id="log-data-4">
                <?= DetailView::widget([
                    'model' => array_filter($model->getDataNew(), function ($data) {
                        return !is_array($data);
                    }),
                ]) ?>
            </div>

            <?php if (!($model->IS_ROLLBACK || Yii::$app->request->isAjax)): ?>
                <?= \yii\helpers\Html::a(
                    '<i class="fa fa-rotate-left"></i> Rollback',
                    ['rollback', 'action' => $model->ACTION_TYPE, 'id' => $model->ID],
                    [
                        'class' => 'btn btn-warning',
                        'data' => [
                            'confirm' => Yii::t('app', 'Apakah anda yakin ingin mengembalikan data ke data lama?'),
                            'method' => 'post',
                        ],
                    ]
                ) ?>
            <?php endif; ?>

        </div>
    </div>
</div>
