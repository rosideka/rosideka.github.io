<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\logs\searches\LogDataSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="log-data-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'USER_ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'USERNAME') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ACTION_TYPE')->dropDownList(
                $model::getActionTypeList(),
                ['prompt' => '-- Pilih --']
            ) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'USER_IP') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'TABLE_NAME') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'MODEL_NAME') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'MODEL_ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'IS_ROLLBACK')->dropDownList(
                ['1' => Yii::t('app', 'Ya'), '0' => Yii::t('app', 'Tidak')],
                ['prompt' => '-- Pilih --']
            ) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
