<?php

use johnitvn\ajaxcrud\CrudAsset;
use kartik\export\ExportMenu;
use kartik\grid\GridView;
use yii\bootstrap\Modal;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $searchModel common\models\logs\searches\LogDataSearch */
/* @var $dpSearch yii\data\SqlDataProvider|yii\data\ActiveDataProvider */
/* @var $dpExport yii\data\SqlDataProvider|yii\data\ActiveDataProvider */
/* @var $actionCount array */

CrudAsset::register($this);
$this->registerCss('#crud-datatable th, #crud-datatable td{white-space:normal} #crud-datatable .panel{margin-bottom: 0}');

$this->title = Yii::t('app', 'Dashboard Log Data');
$this->params['breadcrumbs'][] = $this->title;

$totalCount = array_sum(ArrayHelper::getColumn($actionCount, 'ACTION_COUNT'));
$createCount = ArrayHelper::getValue($actionCount, '1.ACTION_COUNT', 0);
$updateCount = ArrayHelper::getValue($actionCount, '2.ACTION_COUNT', 0);
$deleteCount = ArrayHelper::getValue($actionCount, '3.ACTION_COUNT', 0);
?>
<div class="log-data-index">
    <div class="box box-primary">
        <div class="box-header with-border">
            <?= ExportMenu::widget([
                'container' => ['class' => 'btn-group', 'role' => 'group'],
                'dataProvider' => $dpExport,
                'columns' => require(__DIR__ . '/_columns-export.php'),
                'fontAwesome' => true,
                'columnSelectorOptions' => ['label' => 'Kolom'],
                'columnSelectorMenuOptions' => ['style' => ['height' => '240px', 'overflow-y' => 'auto']],
                'dropdownOptions' => ['label' => 'Export', 'class' => 'btn btn-default'],
                'batchSize' => $dpExport->pagination->pageSize,
                'target' => '_blank',
                'stream' => true,
                'deleteAfterSave' => true,
                'filename' => 'EXPORT-DATA-LOG-DATA-' . date('Y-m-d'),
            ]); ?>

            <div class="pull-right">
                <?= Html::button(
                    '<i class="glyphicon fa fa-search"></i> ' . Yii::t('app', 'Pencarian'),
                    [
                        'class' => 'btn btn-info search-button',
                        'data-toggle' => 'collapse',
                        'data-target' => '.search-collapse',
                    ]
                ) ?>

                <?= Html::a(
                    '<i class="glyphicon glyphicon-refresh"></i>',
                    ['index'],
                    ['class' => 'btn btn-warning']
                ) ?>

            </div>
        </div>
        <div class="box-body search-collapse collapse">
            <?= $this->render('_search', [
                'model' => $searchModel,
            ]); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-6 col-md-3">
            <div class="info-box bg-yellow">
                <span class="info-box-icon"><i class="glyphicon glyphicon-th-large"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?= Yii::t('app', 'Total Log') ?></span>
                    <span class="info-box-number"><?= $totalCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 100%"></div>
                    </div>
                    <span class="progress-description">
                    100% <?= Yii::t('app', 'Dari total data') ?>
                </span>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="info-box bg-green">
                <span class="info-box-icon"><i class="glyphicon glyphicon-plus"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?= Yii::t('app', 'Create Data') ?></span>
                    <span class="info-box-number"><?= $createCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: <?= $createCount / ($totalCount ?: 1) * 100 ?>%"></div>
                    </div>
                    <span class="progress-description">
                    <?= round($createCount / ($totalCount ?: 1) * 100) ?>% <?= Yii::t('app', 'Dari total data') ?>
                </span>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="info-box bg-red">
                <span class="info-box-icon"><i class="glyphicon glyphicon-pencil"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?= Yii::t('app', 'Update Data') ?></span>
                    <span class="info-box-number"><?= $updateCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: <?= $updateCount / ($totalCount ?: 1) * 100 ?>%"></div>
                    </div>
                    <span class="progress-description">
                    <?= round($updateCount / ($totalCount ?: 1) * 100) ?>% <?= Yii::t('app', 'Dari total data') ?>
                </span>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="info-box bg-aqua">
                <span class="info-box-icon"><i class="glyphicon glyphicon-trash"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><?= Yii::t('app', 'Delete Data') ?></span>
                    <span class="info-box-number"><?= $deleteCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: <?= $deleteCount / ($totalCount ?: 1) * 100 ?>%"></div>
                    </div>
                    <span class="progress-description">
                    <?= round($deleteCount / ($totalCount ?: 1) * 100) ?>% <?= Yii::t('app', 'Dari total data') ?>
                </span>
                </div>
            </div>
        </div>
    </div>
    <?= GridView::widget([
        'id' => 'crud-datatable',
        'filterModel' => $searchModel,
        'dataProvider' => $dpSearch,
        'pjax' => true,
        'columns' => require(__DIR__ . '/_columns.php'),
        'toolbar' => [
            [
                'content' =>
                    Html::a(
                        '<i class="glyphicon glyphicon-repeat"></i>',
                        ['index'],
                        ['data-pjax' => 1, 'class' => 'btn btn-default', 'title' => Yii::t('app', 'Reset')]
                    )
                    . '{toggleData}'
                    . '{export}',
            ],
        ],
        'striped' => true,
        'condensed' => true,
        'responsive' => true,
        'responsiveWrap' => false,
        'panel' => [
            'type' => 'default',
            'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Log Data'),
            'after' => Html::a(
                    '<i class="glyphicon glyphicon-repeat"></i> ' . Yii::t('app', 'Reset'),
                    ['index'],
                    ['data-pjax' => 1, 'class' => 'btn btn-primary btn-sm']
                )
                . '<div class="clearfix"></div>',
        ],
    ]) ?>

</div>
<?php
Modal::begin([
    'id' => 'ajaxCrudModal',
    'footer' => '',
]);
Modal::end();
?>
