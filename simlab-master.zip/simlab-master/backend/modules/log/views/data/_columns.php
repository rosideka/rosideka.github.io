<?php

use yii\helpers\ArrayHelper;
use yii\helpers\Url;

/* @var $searchModel common\models\logs\searches\LogDataSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USER_ID',
        'label' => $searchModel->getAttributeLabel('USER_ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USERNAME',
        'label' => $searchModel->getAttributeLabel('USERNAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'USER_IP',
        'label' => $searchModel->getAttributeLabel('USER_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ACTION_TYPE',
        'label' => $searchModel->getAttributeLabel('ACTION_TYPE'),
        'value' => function ($model) use ($searchModel) {
            return ArrayHelper::getValue($searchModel::getActionTypeList(), $model['ACTION_TYPE']);
        },
        'filter' => $searchModel::getActionTypeList(),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ACTION_DATE',
        'label' => $searchModel->getAttributeLabel('ACTION_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TABLE_NAME',
        'label' => $searchModel->getAttributeLabel('TABLE_NAME'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'MODEL_ID',
        'label' => $searchModel->getAttributeLabel('MODEL_ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IS_ROLLBACK',
        'label' => $searchModel->getAttributeLabel('IS_ROLLBACK'),
        'format' => 'boolean',
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'template' => '{view}',
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
    ],
];
