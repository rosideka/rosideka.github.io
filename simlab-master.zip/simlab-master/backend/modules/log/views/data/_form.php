<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\logs\LogData */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="log-data-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= Yii::t('app', 'Form Log Datum') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($model, 'USER_ID')->textInput() ?>

            <?= $form->field($model, 'USER_IP')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'ACTION_TYPE')->textInput() ?>

            <?= $form->field($model, 'ACTION_DATE')->textInput() ?>

            <?= $form->field($model, 'APP_NAME')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'CONTROLLER')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'CONTROLLER_ID')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'ACTION_ID')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'TABLE_NAME')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'MODEL_NAME')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'MODEL_ID')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'DATA_OLD')->textarea(['rows' => 6]) ?>

            <?= $form->field($model, 'DATA_NEW')->textarea(['rows' => 6]) ?>

            <?= $form->field($model, 'IS_ROLLBACK')->textInput() ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
