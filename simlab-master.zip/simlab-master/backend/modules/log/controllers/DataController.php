<?php

namespace backend\modules\log\controllers;

use common\models\logs\LogData;
use common\models\logs\searches\LogDataSearch;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * DataController implements the CRUD actions for LogData model.
 */
class DataController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'rollback' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all LogData models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LogDataSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);
        $actionCount = LogData::find()
            ->select(['ACTION_TYPE', 'ACTION_COUNT' => 'COUNT(*)'])
            ->groupBy(['ACTION_TYPE'])
            ->indexBy(['ACTION_TYPE'])
            ->asArray()
            ->all();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
            'actionCount' => $actionCount,
        ]);
    }

    /**
     * Displays a single LogData model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $footer = $footer = Html::button(
                Yii::t('app', 'Tutup'),
                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
            );
            if (!$model->IS_ROLLBACK) {
                $footer .= Html::a(
                    '<i class="fa fa-rotate-left"></i> Roll Back',
                    ['rollback', 'action' => $model->ACTION_TYPE, 'id' => $model->ID],
                    [
                        'title' => Yii::t('app', 'Rollback data ke data lama'),
                        'role' => 'modal-remote',
                        'class' => 'btn btn-warning',
                        'data' => [
                            'pjax' => false,
                            'pjax-container' => 'crud-datatable-pjax',
                            'request-method' => 'post',
                            'toggle' => 'tooltip',
                            'confirm-title' => Yii::t('app', 'Apakah anda yakin?'),
                            'confirm-message' => Yii::t('app', 'Apakah anda yakin ingin mengembalikan data ke data lama'),
                            'original-title' => 'Rollback',
                        ],
                    ]
                );
            }
            return [
                'title' => 'Log Data #' . $id,
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' => $footer,
            ];
        }
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * @param integer $action
     * @param integer $id
     * @return array|string
     * @throws \Throwable
     */
    public function actionRollback($action, $id)
    {
        $request = Yii::$app->request;

        if ($action > 3) {
            return [
                'title' => Yii::t('app', 'Rollback Data'),
                'content' => '<span class="text-danger">' . Yii::t('app', 'Data tidak valid.') . '</span>',
                'footer' => Html::button('Tutup', ['class' => 'btn btn-default', 'data-dismiss' => "modal"]),
            ];
        }

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            if ($this->rollback($action, $id)) {
                return [
                    'forceReload' => '#crud-datatable-pjax',
                    'title' => "Rollback Data",
                    'content' => '<span class="text-danger">' . Yii::t('app', 'Data berhasil di-rollback.') . '</span>',
                    'footer' => Html::button('Tutup', ['class' => 'btn btn-default', 'data-dismiss' => "modal"]),
                ];
            }
            return [
                'forceReload' => '#crud-datatable-pjax',
                'title' => "Rollback Data",
                'content' => '<span class="text-danger">' . Yii::t('app', 'Data gagal di-rollback.') . '</span>',
                'footer' => Html::button('Tutup', ['class' => 'btn btn-default', 'data-dismiss' => "modal"]),
            ];
        }
        if ($this->rollback($action, $id)) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Data berhasil di-rollback.'));
            return $this->render('index');
        }
        Yii::$app->session->setFlash('danger', Yii::t('app', 'Data gagal di-rollback.'));
        return $this->render('index');
    }

    /**
     * @param integer $action
     * @param integer $id
     * @return bool|false|int
     * @throws \Throwable
     */
    protected function rollback($action, $id)
    {
        /* @var $model \yii\db\ActiveRecord */

        $action = (int)$action;
        $log = $this->findModel($id);

        if ($action === 1) {
            $model = Yii::createObject($log->MODEL_NAME);
            if (($modelFind = $model::findOne($log->MODEL_ID))) {
                if ($modelFind->delete()) {
                    $log->updateAttributes(['IS_ROLLBACK' => 1]);
                    return true;
                }
                return false;
            }
        } elseif ($action === 2) {
            $model = Yii::createObject($log->MODEL_NAME);
            if (($modelFind = $model::findOne($log->MODEL_ID))) {
                $modelFind->setAttributes($log->getDataOld());
                if ($modelFind->save()) {
                    $log->updateAttributes(['IS_ROLLBACK' => 1]);
                    return true;
                }
                return false;
            }
        } elseif ($action === 3) {
            $model = Yii::createObject($log->MODEL_NAME);
            foreach ($log->getDataOld() as $index => $value) {
                $model->{$index} = $value;
            }
            if ($model->save()) {
                $log->updateAttributes(['IS_ROLLBACK' => 1]);
                return true;
            }
            return false;
        }

        return false;
    }

    /**
     * Finds the LogData model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return LogData the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = LogData::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
