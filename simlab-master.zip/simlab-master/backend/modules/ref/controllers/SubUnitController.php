<?php

namespace backend\modules\ref\controllers;

use common\models\eis\RefSubUnit as RefSubUnitEis;
use common\models\refs\RefSubUnit;
use common\models\refs\searches\RefSubUnitSearch;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * SubUnitController implements the CRUD actions for RefSubUnit model.
 */
class SubUnitController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all RefSubUnit models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RefSubUnitSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single RefSubUnit model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Ref Sub Unit'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * @return array|Response
     */
    public function actionSynchronize()
    {
        /* @var $dataSync array */

        $request = Yii::$app->request;
        $lastDate = RefSubUnit::find()->select(['UPDATE_DATE'])->orderBy(['UPDATE_DATE' => SORT_DESC])->scalar();
        $dataSync = RefSubUnitEis::find()
            ->select([
                'ID' => 'ID',
                'ID_UNIT' => 'ID_UNIT',
                'KODE' => 'KODE',
                'SUB_UNIT' => 'NAMA',
                'CREATE_DATE' => 'CREATE_DATE',
                'CREATE_BY' => 'CREATE_BY',
                'CREATE_IP' => 'CREATE_IP',
                'UPDATE_DATE' => 'UPDATE_DATE',
                'UPDATE_BY' => 'UPDATE_BY',
                'UPDATE_IP' => 'UPDATE_IP',
            ])
            ->where(['>', 'UPDATE_DATE', $lastDate ?: '0000-00-00'])
            ->asArray()
            ->all();

        $success = true;

        foreach ($dataSync as $sync) {
            $model = RefSubUnit::findOne($sync['ID']);
            $model = $model ?: new RefSubUnit();
            $model->setAttributes($sync);
            if (!$model->save()) {
                $success = false;
            }
        }

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'forceReload' => '#crud-datatable-pjax',
                'title' => Yii::t('app', 'Synchronize Ref Unit'),
                'content' => $success
                    ? '<span class="text-success">' . Yii::t('app', 'Synchronize ref sub unit berhasil.') . '</span>'
                    : '<span class="text-success">' . Yii::t('app', 'Synchronize ref sub unit gagal.') . '</span>',
                'footer' => Html::button(
                    Yii::t('app', 'Tutup'),
                    ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                ),
            ];
        }
        $success
                ? Yii::$app->session->setFlash('success', Yii::t('app', 'Synchronize ref sub unit berhasil.'))
                : Yii::$app->session->setFlash('danger', Yii::t('app', 'Synchronize ref sub unit gagal.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the RefSubUnit model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RefSubUnit the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RefSubUnit::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
