<?php

namespace backend\modules\ref\controllers;

use backend\modules\ref\models\NominasiSearch;
use backend\modules\ref\models\ReferensiSearch;
use Yii;
use yii\web\Controller;

/**
 * Default controller for the `ref` module
 */
class SiteController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
        $smReferensi = new ReferensiSearch();
        $dpReferensi = $smReferensi->search(Yii::$app->request->queryParams);

        $smNominasi = new NominasiSearch();
        $dpNominasi = $smNominasi->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'smReferensi' => $smReferensi,
            'dpReferensi' => $dpReferensi,
            'smNominasi' => $smNominasi,
            'dpNominasi' => $dpNominasi,
        ]);
    }
}
