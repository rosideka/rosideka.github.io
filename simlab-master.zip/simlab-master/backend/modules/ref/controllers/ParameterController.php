<?php

namespace backend\modules\ref\controllers;

use common\models\MultipleModel;
use common\models\refs\RefParameter;
use common\models\refs\RefParameterMetode;
use common\models\refs\searches\RefParameterSearch;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * ParameterController implements the CRUD actions for RefParameter model.
 */
class ParameterController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all RefParameter models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RefParameterSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single RefParameter model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Ref Parameter'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new RefParameter model.
     * For ajax request will return json object
     * and for non-ajax request if creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        /* @var $dataParameterMetode RefParameterMetode[] */

        $request = Yii::$app->request;

        $model = new RefParameter();
        $dataParameterMetode = [new RefParameterMetode()];
        $dataParameterMetode = MultipleModel::create(RefParameterMetode::class, $dataParameterMetode, 'ID');

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());
                $model->validate();

                MultipleModel::loadMultiple($dataParameterMetode, Yii::$app->request->post());
                MultipleModel::validateMultiple($dataParameterMetode);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataParameterMetode as $parameterMetode) {
                            $parameterMetode->ID_PARAMETER = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Tambah Ref Parameter'),
                            'content' => '<span class="text-success">' . Yii::t('app',
                                    'Tambah ref parameter berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Tambah Lagi'),
                                    ['create'],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Tambah Ref Parameter'),
                        'content' => $this->renderAjax('create', [
                            'model' => $model,
                            'dataParameterMetode' => $dataParameterMetode ?: [new RefParameterMetode()],
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Tambah Ref Parameter'),
                    'content' => $this->renderAjax('create', [
                        'model' => $model,
                        'dataParameterMetode' => $dataParameterMetode ?: [new RefParameterMetode()],
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());
                $model->validate();

                MultipleModel::loadMultiple($dataParameterMetode, Yii::$app->request->post());
                MultipleModel::validateMultiple($dataParameterMetode);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataParameterMetode as $parameterMetode) {
                            $parameterMetode->ID_PARAMETER = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Tambah ref parameter berhasil.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('create', [
                        'model' => $model,
                        'dataParameterMetode' => $dataParameterMetode ?: [new RefParameterMetode()],
                    ]);
                }
            } else {
                return $this->render('create', [
                    'model' => $model,
                    'dataParameterMetode' => $dataParameterMetode ?: [new RefParameterMetode()],
                ]);
            }
        }
    }

    /**
     * Updates an existing RefParameter model.
     * For ajax request will return json object
     * and for non-ajax request if update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionUpdate($id)
    {
        /* @var $dataParameterMetode RefParameterMetode[] */

        $request = Yii::$app->request;

        $model = $this->findModel($id);
        $dataParameterMetode = $model->dataParameterMetode;

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataParameterMetode, 'ID', 'ID');
                $dataParameterMetode = MultipleModel::create(RefParameterMetode::class, $dataParameterMetode);
                MultipleModel::loadMultiple($dataParameterMetode, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataParameterMetode, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataParameterMetode);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = RefParameterMetode::findOne($delId);
                            if (!$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataParameterMetode as $parameterMetode) {
                            $parameterMetode->ID_PARAMETER = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Update Ref Layanan'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Update ref layanan berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Update'),
                                    ['update', 'id' => $id],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Update Ref Layanan'),
                        'content' => $this->renderAjax('update', [
                            'model' => $model,
                            'dataParameterMetode' => $dataParameterMetode,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Update Ref Layanan'),
                    'content' => $this->renderAjax('update', [
                        'model' => $model,
                        'dataParameterMetode' => $dataParameterMetode,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataParameterMetode, 'ID', 'ID');
                $dataParameterMetode = MultipleModel::create(RefParameterMetode::class, $dataParameterMetode);
                MultipleModel::loadMultiple($dataParameterMetode, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataParameterMetode, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataParameterMetode);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = RefParameterMetode::findOne($delId);
                            if (!$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataParameterMetode as $parameterMetode) {
                            $parameterMetode->ID_PARAMETER = $model->ID;
                            if (!$parameterMetode->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Update ref layanan berhasil'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('update', [
                        'model' => $model,
                        'dataParameterMetode' => $dataParameterMetode,
                    ]);
                }
            } else {
                return $this->render('update', [
                    'model' => $model,
                    'dataParameterMetode' => $dataParameterMetode,
                ]);
            }
        }
    }

    /**
     * Delete an existing RefParameter model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionDelete($id)
    {
        $request = Yii::$app->request;
        $this->findModel($id)->delete();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus ref parameterberhasil'));
        return $this->redirect(['index']);
    }

    /**
     * Delete multiple existing RefParameter model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionBulkDelete()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks')); // Array or selected records primary keys

        foreach ($pks as $pk) {
            $model = $this->findModel($pk);
            $model->delete();
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus user berhasil.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the RefParameter model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RefParameter the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RefParameter::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
