<?php

namespace backend\modules\ref\controllers;

use common\models\MultipleModel;
use common\models\refs\RefJenisPaket;
use common\models\refs\RefJenisPaketChild;
use common\models\refs\searches\RefJenisPaketSearch;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * JenisPaketController implements the CRUD actions for RefJenisPaket model.
 */
class JenisPaketController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all RefJenisPaket models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RefJenisPaketSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single RefJenisPaket model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Ref Jenis Paket'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new RefJenisPaket model.
     * For ajax request will return json object
     * and for non-ajax request if creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        /* @var $dataJenisPaket RefJenisPaketChild[] */

        $request = Yii::$app->request;

        $model = new RefJenisPaket();
        $dataJenisPaket = [new RefJenisPaketChild()];
        $dataJenisPaket = MultipleModel::create(RefJenisPaketChild::class, $dataJenisPaket, 'ID');

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());
                MultipleModel::loadMultiple($dataJenisPaket, Yii::$app->request->post());

                MultipleModel::validateMultiple($dataJenisPaket);
                $model->validate();

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataJenisPaket as $jenisPaket) {
                            $jenisPaket->ID_PARENT = $model->ID;
                            if (!$jenisPaket->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Tambah Ref Jenis Paket'),
                            'content' => '<span class="text-success">' . Yii::t('app',
                                    'Tambah ref parameter berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Tambah Lagi'),
                                    ['create'],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Tambah Ref Jenis Paket'),
                        'content' => $this->renderAjax('create', [
                            'model' => $model,
                            'dataJenisPaket' => $dataJenisPaket ?: [new RefJenisPaketChild()],
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Tambah Ref Jenis Paket'),
                    'content' => $this->renderAjax('create', [
                        'model' => $model,
                        'dataJenisPaket' => $dataJenisPaket ?: [new RefJenisPaketChild()],
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());
                MultipleModel::loadMultiple($dataJenisPaket, Yii::$app->request->post());

                $model->validate();
                MultipleModel::validateMultiple($dataJenisPaket);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if ($success) {
                        foreach ($dataJenisPaket as $jenisPaket) {
                            $jenisPaket->ID_PARENT = $model->ID;
                            if (!$jenisPaket->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Tambah ref parameter berhasil.'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('create', [
                        'model' => $model,
                        'dataJenisPaket' => $dataJenisPaket ?: [new RefJenisPaketChild()],
                    ]);
                }
            } else {
                return $this->render('create', [
                    'model' => $model,
                    'dataJenisPaket' => $dataJenisPaket ?: [new RefJenisPaketChild()],
                ]);
            }
        }
    }

    /**
     * Updates an existing RefJenisPaket model.
     * For ajax request will return json object
     * and for non-ajax request if update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionUpdate($id)
    {
        /* @var $dataJenisPaket RefJenisPaketChild[] */

        $request = Yii::$app->request;

        $model = $this->findModel($id);
        $dataJenisPaket = $model->dataJenisPaket ?: [new RefJenisPaketChild()];

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;

            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataJenisPaket, 'ID', 'ID');
                $dataJenisPaket = MultipleModel::create(RefJenisPaketChild::class, $dataJenisPaket);
                MultipleModel::loadMultiple($dataJenisPaket, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataJenisPaket, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataJenisPaket);

                $transaction = Yii::$app->db->beginTransaction();

                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = RefJenisPaketChild::findOne($delId);
                            if ($delModel && !$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataJenisPaket as $jenisPaket) {
                            $jenisPaket->ID_PARENT = $model->ID;
                            if (!$jenisPaket->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        return [
                            'forceReload' => '#crud-datatable-pjax',
                            'title' => Yii::t('app', 'Update Ref Jenis Paket'),
                            'content' => '<span class="text-success">' . Yii::t('app', 'Update ref layanan berhasil') . '</span>',
                            'footer' =>
                                Html::button(
                                    Yii::t('app', 'Tutup'),
                                    ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                                )
                                . Html::a(
                                    Yii::t('app', 'Update'),
                                    ['update', 'id' => $id],
                                    ['class' => 'btn btn-primary', 'role' => 'modal-remote']
                                ),
                        ];
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return [
                        'title' => Yii::t('app', 'Update Ref Jenis Paket'),
                        'content' => $this->renderAjax('update', [
                            'model' => $model,
                            'dataJenisPaket' => $dataJenisPaket,
                        ]),
                        'footer' =>
                            Html::button(
                                Yii::t('app', 'Tutup'),
                                ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                            )
                            . Html::button(
                                Yii::t('app', 'Simpan'),
                                ['class' => 'btn btn-primary', 'type' => 'submit']
                            ),
                    ];
                }
            } else {
                return [
                    'title' => Yii::t('app', 'Update Ref Jenis Paket'),
                    'content' => $this->renderAjax('update', [
                        'model' => $model,
                        'dataJenisPaket' => $dataJenisPaket,
                    ]),
                    'footer' =>
                        Html::button(
                            Yii::t('app', 'Tutup'),
                            ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                        )
                        . Html::button(
                            Yii::t('app', 'Simpan'),
                            ['class' => 'btn btn-primary', 'type' => 'submit']
                        ),
                ];
            }
        } else {
            /*
             * Process for non-ajax request
             */
            if ($request->isPost) {
                $model->load($request->post());

                $addIds = ArrayHelper::map($dataJenisPaket, 'ID', 'ID');
                $dataJenisPaket = MultipleModel::create(RefJenisPaketChild::class, $dataJenisPaket);
                MultipleModel::loadMultiple($dataJenisPaket, Yii::$app->request->post());
                $delIds = array_diff($addIds, array_filter(ArrayHelper::map($dataJenisPaket, 'ID', 'ID')));

                $model->validate();
                MultipleModel::validateMultiple($dataJenisPaket);

                $transaction = Yii::$app->db->beginTransaction();
                try {
                    $success = $model->save();

                    if (!empty($delIds)) {
                        foreach ($delIds as $delId) {
                            $delModel = RefJenisPaketChild::findOne($delId);
                            if ($delModel && !$delModel->delete()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        foreach ($dataJenisPaket as $jenisPaket) {
                            $jenisPaket->ID_PARENT = $model->ID;
                            if (!$jenisPaket->save()) {
                                $success = false;
                            }
                        }
                    }

                    if ($success) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Update ref layanan berhasil'));
                        return $this->redirect(['index']);
                    }
                    throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
                } catch (Exception $e) {
                    $transaction->rollBack();
                    return $this->render('update', [
                        'model' => $model,
                        'dataJenisPaket' => $dataJenisPaket,
                    ]);
                }
            } else {
                return $this->render('update', [
                    'model' => $model,
                    'dataJenisPaket' => $dataJenisPaket,
                ]);
            }
        }
    }

    /**
     * Delete an existing RefJenisPaket model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionDelete($id)
    {
        $request = Yii::$app->request;
        $this->findModel($id)->delete();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus ref jenis paketberhasil'));
        return $this->redirect(['index']);
    }

    /**
     * Delete multiple existing RefJenisPaket model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionBulkDelete()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks')); // Array or selected records primary keys

        foreach ($pks as $pk) {
            $model = $this->findModel($pk);
            $model->delete();
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus user berhasil.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the RefJenisPaket model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RefJenisPaket the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RefJenisPaket::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
