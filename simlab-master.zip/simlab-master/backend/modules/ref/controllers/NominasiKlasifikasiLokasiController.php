<?php

namespace backend\modules\ref\controllers;

use backend\modules\ref\models\NominasiKlasifikasiLokasiSearch;
use common\models\simlab\Uji;
use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/**
 * NominasiKlasifikasiLokasiController implements the CRUD actions for Uji model.
 */
class NominasiKlasifikasiLokasiController extends Controller
{
    /**
     * Lists all Uji models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new NominasiKlasifikasiLokasiSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Finds the Uji model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Uji the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Uji::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
