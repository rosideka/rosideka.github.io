<?php

namespace backend\modules\ref\controllers;

use common\models\refs\RefLab;
use common\models\refs\searches\RefLabSearch;
use Exception;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\FileHelper;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\web\UploadedFile;

/**
 * LabController implements the CRUD actions for RefLab model.
 */
class LabController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                    'bulk-delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all RefLab models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RefLabSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single RefLab model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Ref Lab'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default pull-left', 'data-dismiss' => 'modal']
                    )
                    . Html::a(
                        Yii::t('app', 'Update'),
                        ['update', 'id' => $id],
                        ['class' => 'btn btn-primary', 'data-pjax' => '0']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * Creates a new RefLab model.
     * For ajax request will return json object
     * and for non-ajax request if creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $request = Yii::$app->request;
        $model = new RefLab();

        /*
         * Process for non-ajax request
         */
        if ($model->load($request->post())) {
            $transaction = Yii::$app->db->beginTransaction();
            try {
                $model->file = UploadedFile::getInstance($model, 'file');

                if ($model->file) {
                    FileHelper::createDirectory(Yii::getAlias('@basePath/uploads/' . date('Y/m/')));
                    $model->FILE_NAME = date('Y/m/')
                        . Yii::$app->security->generateRandomString()
                        . '.'
                        . $model->file->extension;
                }

                $success = $model->save();

                if ($success) {
                    if ($model->file) {
                        $success = $model->file->saveAs($model->getFilePath());
                    }
                }

                if ($success) {
                    $transaction->commit();
                    Yii::$app->session->setFlash('success', Yii::t('app', 'Tambah ref lab berhasil.'));
                    return $this->redirect(['index']);
                }
                throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
            } catch (Exception $e) {
                $transaction->rollBack();
                return $this->render('create', [
                    'model' => $model,
                ]);
            }
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing RefLab model.
     * For ajax request will return json object
     * and for non-ajax request if update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionUpdate($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        /*
         * Process for non-ajax request
         */
        if ($model->load($request->post())) {
            $transaction = Yii::$app->db->beginTransaction();
            try {
                $model->file = UploadedFile::getInstance($model, 'file');
                $delFile = $model->getFilePath();

                if ($model->file) {
                    FileHelper::createDirectory(Yii::getAlias('@basePath/uploads/' . date('Y/m/')));
                    $model->FILE_NAME = date('Y/m/')
                        . Yii::$app->security->generateRandomString()
                        . '.'
                        . $model->file->extension;
                }

                $success = $model->save();

                if ($success) {
                    if ($model->file) {
                        $success = $model->file->saveAs($model->getFilePath());
                    }
                }

                if ($success) {
                    if (is_file($delFile)) {
                        unlink($delFile);
                    }

                    $transaction->commit();
                    Yii::$app->session->setFlash('success', Yii::t('app', 'Update ref lab berhasil.'));
                    return $this->redirect(['index']);
                }
                throw new Exception(Yii::t('app', 'Terjadi kesalahan pada saat menyimpan data.'));
            } catch (Exception $e) {
                $transaction->rollBack();
                return $this->render('update', [
                    'model' => $model,
                ]);
            }
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Delete an existing RefLab model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionDelete($id)
    {
        $request = Yii::$app->request;
        $this->findModel($id)->delete();

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus ref labberhasil'));
        return $this->redirect(['index']);
    }

    /**
     * Delete multiple existing RefLab model.
     * For ajax request will return json object
     * and for non-ajax request if deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws \Throwable
     */
    public function actionBulkDelete()
    {
        $request = Yii::$app->request;
        $pks = explode(',', $request->post('pks')); // Array or selected records primary keys

        foreach ($pks as $pk) {
            $model = $this->findModel($pk);
            $model->delete();
        }

        if ($request->isAjax) {
            /*
             * Process for ajax request
             */
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['forceClose' => true, 'forceReload' => '#crud-datatable-pjax'];
        }
        /*
         * Process for non-ajax request
         */
        Yii::$app->session->setFlash('success', Yii::t('app', 'Hapus user berhasil.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the RefLab model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RefLab the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RefLab::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
