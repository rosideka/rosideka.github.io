<?php

namespace backend\modules\ref\controllers;

use common\models\eis\RefUnit as RefUnitEis;
use common\models\refs\RefUnit;
use common\models\refs\searches\RefUnitSearch;
use Yii;
use yii\helpers\Html;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

/**
 * UnitController implements the CRUD actions for RefUnit model.
 */
class UnitController extends Controller
{
    /**
     * Lists all RefUnit models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RefUnitSearch();
        $dpSearch = $searchModel->search(Yii::$app->request->queryParams);
        $dpExport = $searchModel->export(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dpSearch' => $dpSearch,
            'dpExport' => $dpExport,
        ]);
    }

    /**
     * Displays a single RefUnit model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $request = Yii::$app->request;
        $model = $this->findModel($id);

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'title' => Yii::t('app', 'Ref Unit'),
                'content' => $this->renderAjax('view', [
                    'model' => $model,
                ]),
                'footer' =>
                    Html::button(
                        Yii::t('app', 'Tutup'),
                        ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                    ),
            ];
        }
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    /**
     * @return array|Response
     */
    public function actionSynchronize()
    {
        /* @var $dataSync array */

        $request = Yii::$app->request;
        $lastDate = RefUnit::find()->select(['UPDATE_DATE'])->orderBy(['UPDATE_DATE' => SORT_DESC])->scalar();
        $dataSync = RefUnitEis::find()
            ->select([
                'ID' => 'ID_FAKULTAS',
                'KODE' => 'FAKULTAS',
                'UNIT' => 'FAKULTAS_LENGKAP',
                'CREATE_DATE' => 'CREATE_DATE',
                'CREATE_BY' => 'CREATE_BY',
                'CREATE_IP' => 'CREATE_IP',
                'UPDATE_DATE' => 'UPDATE_DATE',
                'UPDATE_BY' => 'UPDATE_BY',
                'UPDATE_IP' => 'UPDATE_IP',
            ])
            ->where(['>', 'UPDATE_DATE', $lastDate ?: '0000-00-00'])
            ->asArray()
            ->all();

        $success = true;

        foreach ($dataSync as $sync) {
            $model = RefUnit::findOne($sync['ID']);
            $model = $model ?: new RefUnit();
            $model->setAttributes($sync);
            if (!$model->save()) {
                $success = false;
            }
        }

        if ($request->isAjax) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return [
                'forceReload' => '#crud-datatable-pjax',
                'title' => Yii::t('app', 'Synchronize Ref Unit'),
                'content' => $success
                    ? '<span class="text-success">' . Yii::t('app', 'Synchronize ref unit berhasil.') . '</span>'
                    : '<span class="text-success">' . Yii::t('app', 'Synchronize ref unit gagal.') . '</span>',
                'footer' => Html::button(
                    Yii::t('app', 'Tutup'),
                    ['class' => 'btn btn-default', 'data-dismiss' => 'modal']
                ),
            ];
        }
        $success
                ? Yii::$app->session->setFlash('success', Yii::t('app', 'Synchronize ref unit berhasil.'))
                : Yii::$app->session->setFlash('danger', Yii::t('app', 'Synchronize ref unit gagal.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the RefUnit model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RefUnit the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RefUnit::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
