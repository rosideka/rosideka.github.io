<?php

use kartik\grid\GridView;
use yii\data\ActiveDataProvider;
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefParameter */

$this->title = Yii::t('app', 'Ref Parameter');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Parameter'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-parameter-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Parameter') ?></div>
        </div>
        <div class="box-body">
            <?php
            echo DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width: 33.33%'],
                    ],
                    [
                        'attribute' => 'ID_LAB',
                        'value' => $model->ID_LAB ? $model->idLab->NAMA : null,
                    ],
                    'RUMUS',
                    'NAMA',
                    'NAMA_LENGKAP',
                    [
                        'attribute' => 'TARIF_UJI',
                        'format' => 'currency',
                    ],
                    'IS_AKTIF:boolean',
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]);

            echo Html::tag('h4', Yii::t('app', 'Metode Uji'), ['class' => 'text-uppercase']);

            echo GridView::widget([
                'dataProvider' => new ActiveDataProvider([
                    'query' => $model->getDataParameterMetode(),
                    'pagination' => false,
                ]),
                'pjax' => true,
                'pjaxSettings' => [
                    'options' => [
                        'enablePushState' => false,
                        'enableReplaceState' => false,
                    ],
                ],
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'ID_METODE_UJI',
                        'value' => 'idMetodeUji.NAMA_METODE',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'IS_AKTIF',
                        'format' => 'boolean',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'IS_DEFAULT',
                        'format' => 'boolean',
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'panel' => false,
                'summary' => false,
            ])
            ?>

        </div>
    </div>
</div>
