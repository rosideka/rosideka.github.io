<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefParameter */
/* @var $dataParameterMetode common\models\refs\RefParameterMetode[] */

$this->title = Yii::t('app', 'Update Ref Parameter');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Parameter'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-parameter-update">
    <?= $this->render('_form', [
        'model' => $model,
        'dataParameterMetode' => $dataParameterMetode,
    ]) ?>
</div>
