<?php

use common\models\refs\RefLab;
use common\models\refs\RefMetodeUji;
use kartik\select2\Select2;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $model common\models\refs\RefParameter */
/* @var $dataParameterMetode common\models\refs\RefParameterMetode[] */

$this->registerJs($this->render('form/_script.min.js'));

$mapMetodeUji = RefMetodeUji::map();
?>
<div class="ref-parameter-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= Yii::t('app', 'Form Ref Parameter') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(['id' => 'pm_form']); ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'ID_LAB')->widget(Select2::class, [
                        'data' => RefLab::map(),
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                        'pluginOptions' => ['allowClear' => true],
                    ]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'RUMUS')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'NAMA')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'NAMA_LENGKAP')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'TARIF_UJI')->textInput() ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'IS_AKTIF')->dropDownList(
                        [1 => 'Ya', 0 => 'Tidak'],
                        ['prompt' => Yii::t('app', '-- Pilih --')]
                    ) ?>

                </div>
            </div>

            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'pm_container',
                'widgetBody' => '.pm-items',
                'widgetItem' => '.pm-item',
                'min' => 1,
                'insertButton' => '.pm-add-item',
                'deleteButton' => '.pm-del-item',
                'model' => $dataParameterMetode[0],
                'formId' => 'pm_form',
                'formFields' => ['ID', 'ID_METODE_UJI', 'IS_AKTIF', 'IS_DEFAULT'],
            ]); ?>

            <div class="callout callout-info pm-callout">
                <h4 class="text-uppercase"><?= Yii::t('app', 'Sub Layanan') ?></h4>
                <p><?= Yii::t('app', 'Silakan isikan sub layanan melalui form berikut:') ?></p>
            </div>

            <div class="pm-items">
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-xs-4">
                        <label class="control-label">
                            <?= $dataParameterMetode[0]->getAttributeLabel('ID_METODE_UJI'); ?>
                        </label>

                    </div>
                    <div class="col-xs-3">
                        <label class="control-label">
                            <?= $dataParameterMetode[0]->getAttributeLabel('IS_AKTIF'); ?>
                        </label>

                    </div>
                    <div class="col-xs-3">
                        <label class="control-label">
                            <?= $dataParameterMetode[0]->getAttributeLabel('IS_DEFAULT') ?>
                        </label>

                    </div>
                    <div class="col-xs-2">
                        <?= Html::button(
                            '<i class="glyphicon glyphicon-plus"></i> ' . Yii::t('app', 'Tambah'),
                            ['class' => 'btn btn-success pm-add-item btn-block']
                        ) ?>

                    </div>
                </div>
                <?php foreach ($dataParameterMetode as $index => $parameterMetode): ?>
                    <div class="row pm-item">
                        <?= $parameterMetode->isNewRecord ? Html::activeHiddenInput($parameterMetode, "[{$index}]ID") : '' ?>

                        <div class="col-xs-4">
                            <?= $form->field($parameterMetode, "[{$index}]ID_METODE_UJI")->widget(Select2::class, [
                                'data' => $mapMetodeUji,
                                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                'pluginOptions' => ['allowClear' => true],
                            ])->label(false) ?>

                        </div>
                        <div class="col-xs-3">
                            <?= $form->field($parameterMetode, "[{$index}]IS_AKTIF")->widget(Select2::class, [
                                'data' => [1 => 'Ya', 0 => 'Tidak'],
                                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                                'pluginOptions' => ['allowClear' => true],
                            ])->label(false) ?>

                        </div>
                        <div class="col-xs-3">
                            <?= $form->field($parameterMetode, "[{$index}]IS_DEFAULT")->widget(Select2::class, [
                                'data' => [1 => 'Ya', 0 => 'Tidak'],
                                'options' => ['placeholder' => Yii::t('app', '-- Pilih --'), 'class' => 'fi-is-default'],
                                'pluginOptions' => ['allowClear' => true],
                            ])->label(false) ?>

                        </div>
                        <div class="col-xs-2">
                            <?= Html::button(
                                '<i class="glyphicon glyphicon-trash"></i> Hapus',
                                ['class' => 'btn btn-block btn-danger pm-del-item']
                            ) ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php DynamicFormWidget::end(); ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
