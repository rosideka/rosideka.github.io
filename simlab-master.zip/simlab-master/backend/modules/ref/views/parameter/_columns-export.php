<?php

/* @var $searchModel common\models\refs\searches\RefParameterSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_LAB',
        'label' => $searchModel->getAttributeLabel('ID_LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS',
        'label' => $searchModel->getAttributeLabel('RUMUS'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LENGKAP',
        'label' => $searchModel->getAttributeLabel('NAMA_LENGKAP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TARIF_UJI',
        'label' => $searchModel->getAttributeLabel('TARIF_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IS_AKTIF',
        'label' => $searchModel->getAttributeLabel('IS_AKTIF'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_DATE',
        'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_BY',
        'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'CREATE_IP',
        'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_DATE',
        'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_BY',
        'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UPDATE_IP',
        'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    ],
];
