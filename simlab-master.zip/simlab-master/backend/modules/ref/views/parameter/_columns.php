<?php

use yii\helpers\Url;

/* @var $searchModel common\models\refs\searches\RefParameterSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LAB',
        'label' => $searchModel->getAttributeLabel('LAB'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'RUMUS',
        'label' => $searchModel->getAttributeLabel('RUMUS'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_LENGKAP',
        'label' => $searchModel->getAttributeLabel('NAMA_LENGKAP'),
        'format' => 'raw',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'TARIF_UJI',
        'label' => $searchModel->getAttributeLabel('TARIF_UJI'),
        'format' => 'currency',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'IS_AKTIF',
        'label' => $searchModel->getAttributeLabel('IS_AKTIF'),
        'format' => 'boolean',
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
