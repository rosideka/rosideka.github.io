(function ($) {
  $('.pm_container').on('change', '.fi-is-default', function (){
    let element = $(this);
    let value = element.val();

    if (parseInt(value) === 1) {
      let parent = element.closest('.pm-item');
      let siblings = parent.siblings('.pm-item');

      siblings.find('.fi-is-default').each(function (i, e) {
        $(e).val('0').change();
      });
    }
  })
}(jQuery));