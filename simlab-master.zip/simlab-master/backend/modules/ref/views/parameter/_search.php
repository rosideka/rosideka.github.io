<?php

use common\models\refs\RefLab;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\searches\RefParameterSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-parameter-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_LAB')->widget(Select2::class, [
                'data' => RefLab::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'RUMUS') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'NAMA') ?>

        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'NAMA_LENGKAP') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'TARIF_UJI') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'IS_AKTIF')->dropDownList(
                [1 => Yii::t('app', 'Ya'), 0 => Yii::t('app', 'Tidak')],
                ['prompt' => Yii::t('app', '-- Pilih --')]
            ) ?>

        </div>
    </div>

    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
