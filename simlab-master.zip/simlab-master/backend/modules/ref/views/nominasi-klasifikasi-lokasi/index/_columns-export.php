<?php

/* @var $searchModel backend\modules\ref\models\NominasiKlasifikasiLokasiSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KLASIFIKASI_LOKASI',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JML_UJI',
        'label' => $searchModel->getAttributeLabel('JML_UJI'),
    ],
];
