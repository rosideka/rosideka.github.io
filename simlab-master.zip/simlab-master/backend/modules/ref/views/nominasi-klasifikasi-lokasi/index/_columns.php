<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $searchModel backend\modules\ref\models\NominasiKlasifikasiLokasiSearch */

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KLASIFIKASI_LOKASI',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JML_UJI',
        'label' => $searchModel->getAttributeLabel('JML_UJI'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'template' => '{view}',
        'viewOptions' => ['role' => 'modal-remote', 'title' => 'Detail', 'data-toggle' => 'tooltip'],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Tambah'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'nama' => $model['KLASIFIKASI_LOKASI']]);
        },
        'template' => '{create}',
        'buttons' => [
            'create' => function ($url, $model, $key) {
                return Html::a(
                    Yii::t('app', 'Tambah'),
                    $url,
                    [
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Tambah'),
                        'class' => 'btn btn-sm btn-primary',
                        'data-pjax' => 0,
                        'role' => 'modal-remote',
                    ]
                );
            },
        ],
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'header' => Yii::t('app', 'Merge'),
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'nama' => $model['KLASIFIKASI_LOKASI']]);
        },
        'template' => '{merge}',
        'buttons' => [
            'merge' => function ($url, $model, $key) {
                return Html::a(
                    Yii::t('app', 'Merge'),
                    $url,
                    [
                        'data-toggle' => 'tooltip',
                        'title' => Yii::t('app', 'Merge'),
                        'class' => 'btn btn-sm btn-danger',
                        'data-pjax' => 0,
                        'role' => 'modal-remote',
                    ]
                );
            },
        ],
    ],
];
