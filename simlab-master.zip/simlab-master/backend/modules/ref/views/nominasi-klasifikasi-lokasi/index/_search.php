<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\modules\ref\models\NominasiKlasifikasiLokasiSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="uji-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>
    <div class="row">
        <div class="col-sm-6">
            <?= $form->field($model, 'KLASIFIKASI_LOKASI') ?>
        
        </div>
        <div class="col-sm-6">
            <?= $form->field($model, 'JML_UJI')->input('number', ['min' => 1, 'step' => 1]) ?>
            
        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . 'Proses',
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . 'Reset',
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
