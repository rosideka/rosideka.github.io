<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiRetensi */

$this->title = Yii::t('app', 'Tambah Ref Uji Retensi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Retensi'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-retensi-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
