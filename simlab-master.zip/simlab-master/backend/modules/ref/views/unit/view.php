<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUnit */

$this->title = Yii::t('app', 'Ref Unit');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Unit'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-unit-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Unit') ?></h2>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'ID',
                    'KODE',
                    'UNIT',
                ],
            ]) ?>

        </div>
    </div>
</div>
