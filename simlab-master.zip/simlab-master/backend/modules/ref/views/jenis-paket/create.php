<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefJenisPaket */
/* @var $dataJenisPaket common\models\refs\RefJenisPaketChild[] */

$this->title = Yii::t('app', 'Tambah Ref Jenis Paket');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Jenis Paket'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-jenis-paket-create">
    <?= $this->render('_form', [
        'model' => $model,
        'dataJenisPaket' => $dataJenisPaket,
    ]) ?>
</div>
