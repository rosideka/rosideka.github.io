<?php

use common\models\refs\RefJenisPaket;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\searches\RefJenisPaketSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-jenis-paket-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-4">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'ID_PARENT')->widget(Select2::class, [
                'data' => RefJenisPaket::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
        <div class="col-sm-4">
            <?= $form->field($model, 'JENIS_PAKET') ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
