<?php

use common\models\refs\RefJenisPaket;
use kartik\select2\Select2;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $model common\models\refs\RefJenisPaket */
/* @var $dataJenisPaket common\models\refs\RefJenisPaketChild[] */

$this->registerCss('.jp-del-item {border-top-left-radius: 0; border-bottom-left-radius: 0}')
?>
<div class="ref-jenis-paket-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Ref Jenis Paket') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(['id' => 'jp_form']); ?>

            <?= $form->field($model, 'ID_PARENT')->widget(Select2::class, [
                'data' => RefJenisPaket::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

            <?= $form->field($model, 'JENIS_PAKET')->textInput(['maxlength' => true]) ?>

            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'jp_container',
                'widgetBody' => '.jp-items',
                'widgetItem' => '.jp-item',
                'min' => 0,
                'insertButton' => '.jp-add-item',
                'deleteButton' => '.jp-del-item',
                'model' => $dataJenisPaket[0],
                'formId' => 'jp_form',
                'formFields' => ['ID_LAYANAN', 'NAMA'],
            ]); ?>

            <div class="callout callout-info jp-callout">
                <h4 class="text-uppercase"><?= Yii::t('app', 'Turunan Jenis Paket') ?></h4>
                <p><?= Yii::t('app', 'Silakan isikan turunan jenis paket melalui form berikut:') ?></p>
            </div>

            <div class="jp-items">
                <div class="row no-padding" style="margin-bottom: 10px">
                    <div class="col-sm-3 col-sm-offset-9">
                        <?= Html::button(
                            '<i class="glyphicon glyphicon-plus"></i> ' . Yii::t('app', 'Tambah'),
                            ['class' => 'btn btn-success jp-add-item btn-block']
                        ) ?>

                    </div>
                </div>
                <?php foreach ($dataJenisPaket as $index => $jenisPaket): ?>
                    <div class="row no-padding jp-item">
                        <?= $jenisPaket->isNewRecord ? Html::activeHiddenInput($jenisPaket, "[{$index}]ID") : '' ?>

                        <div class="col-xs-9">
                            <?=
                            $form
                                ->field($jenisPaket, "[{$index}]JENIS_PAKET")
                                ->textInput([
                                    'maxlength' => true,
                                    'placeholder' => $jenisPaket->getAttributeLabel('JENIS_PAKET'),
                                ])
                                ->label(false)
                            ?>

                        </div>
                        <div class="col-xs-3">
                            <?= Html::button(
                                '<i class="glyphicon glyphicon-trash"></i> Hapus',
                                ['class' => 'btn btn-block btn-danger jp-del-item']
                            ) ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php DynamicFormWidget::end(); ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Simpan') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
