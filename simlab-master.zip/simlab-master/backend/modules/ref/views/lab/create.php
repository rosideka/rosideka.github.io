<?php



/* @var $this yii\web\View */
/* @var $model common\models\refs\RefLab */

$this->title = Yii::t('app', 'Tambah Ref Lab');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Lab'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-lab-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
