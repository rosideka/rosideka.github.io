<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefLab */

$this->title = Yii::t('app', 'Ref Lab');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Lab'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-lab-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= implode(' - ', [$model->KODE, $model->NAMA]) ?></h2>
        </div>
        <div class="box-body">
            <?php if ($model->FILE_NAME): ?>
                <?= Html::img($model->getFileUrl(), ['class' => 'img-responsive']); ?>
            <?php endif; ?>

            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'label' => Yii::t('app', 'Create'),
                        'captionOptions' => ['style' => 'width: 33.33%'],
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]) ?>

            <div class="deskripsi" style="margin-top: 15px">
                <?= $model->DESKRIPSI ?>
            </div>

            <hr />

            <p><i class="glyphicon glyphicon-map-marker text-success"></i> <?= $model->LOKASI ?></p>

            <p><i class="glyphicon glyphicon-glass text-success"></i> <?= $model->KELOMPOK_UJI ?></p>

            <p>
                <i class="glyphicon glyphicon-user text-success"></i>
                <?= $model->IDP_KETUA ? $model->idpKetua->NAMA_LENGKAP : '-' ?>
            </p>

        </div>
    </div>
</div>
