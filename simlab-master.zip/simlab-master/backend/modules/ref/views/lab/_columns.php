<?php

use yii\helpers\Url;

/* @var $searchModel common\models\refs\searches\RefLabSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA',
        'label' => $searchModel->getAttributeLabel('NAMA'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'LOKASI',
        'label' => $searchModel->getAttributeLabel('LOKASI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KELOMPOK_UJI',
        'label' => $searchModel->getAttributeLabel('KELOMPOK_UJI'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_KETUA',
        'label' => $searchModel->getAttributeLabel('NAMA_KETUA'),
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['data-pjax' => '0', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
