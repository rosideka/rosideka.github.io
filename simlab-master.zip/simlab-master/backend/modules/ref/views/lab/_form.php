<?php

use dosamigos\tinymce\TinyMce;
use kartik\file\FileInput;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefLab */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-lab-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= Yii::t('app', 'Form Ref Lab') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'KODE')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'NAMA')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?= $form->field($model, 'LOKASI')->textInput(['maxlength' => true]) ?>

                </div>
                <div class="col-sm-6">
                    <?= $form->field($model, 'KELOMPOK_UJI')->textInput(['maxlength' => true]) ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <?php
                    $ketua = $model->IDP_KETUA ? $model->idpKetua : null;

                    echo $form->field($model, 'IDP_KETUA')->widget(Select2::class, [
                        'initValueText' => implode(' - ', $ketua
                            ? [$ketua->ID, $ketua->NAMA_LENGKAP, $ketua->NIP]
                            : []
                        ),
                        'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                        'pluginOptions' => [
                            'allowClear' => true,
                            'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => Url::to(['/api-helper/id-pegawai']),
                                'delay' => 500,
                                'dataType' => 'JSON',
                                'data' => new JsExpression('function(params) { return { q:params.term }; }'),
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(response) { return response.text; }'),
                            'templateSelection' => new JsExpression('function (response) { return response.text; }'),
                        ],
                    ])
                    ?>

                </div>
                <div class="col-sm-6">
                    <?php
                    $main1 = '<div class="input-group {class}">{caption}<div class="input-group-btn">';
                    if ($model->FILE_NAME) {
                        $main1 .= Html::a(
                            '<span class="glyphicon glyphicon-eye-open"></span> ' . Yii::t('app', 'Lihat'),
                            $model->FILE_NAME,
                            ['class' => 'btn btn-success', 'target' => '_blank']
                        );
                    }
                    $main1 .= '{cancel}{browse}</div></div>';
                    echo $form->field($model, 'file')->widget(FileInput::class, [
                        'options' => [
                            'accept' => 'image/*',
                            'multiple' => false,
                        ],
                        'pluginOptions' => [
                            'layoutTemplates' => ['main1' => $main1],
                            'showPreview' => false,
                            'showCaption' => true,
                            'showRemove' => true,
                            'showUpload' => false,
                            'overwriteInitial' => false,
                        ],
                    ])
                    ?>

                </div>
            </div>
            <?= $form->field($model, 'DESKRIPSI')->widget(TinyMce::class, [
                'clientOptions' => [
                    'height' => 300,
                    'menubar' => false,
                    'plugins' => [
                        "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                        "searchreplace visualblocks visualchars code fullscreen",
                        "insertdatetime media nonbreaking save table contextmenu directionality",
                        "template paste textcolor",
                    ],
                    'toolbar' => "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media | forecolor backcolor | code fullscreen",
                ],
            ]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group" style="margin-bottom: 0">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
