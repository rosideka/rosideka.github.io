<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefJenisMember */

$this->title = Yii::t('app', 'Tambah Ref Jenis Member');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Jenis Member'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-jenis-member-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
