<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefSubUnit */

$this->title = Yii::t('app', 'Ref Sub Unit');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Sub Unit'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-sub-unit-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Sub Unit') ?></h2>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'ID',
                    'KODE',
                    [
                        'attribute' => 'ID_UNIT',
                        'value' => $model->ID_UNIT ? $model->idUnit->UNIT : null,
                    ],
                    'SUB_UNIT',
                ],
            ]) ?>

        </div>
    </div>
</div>
