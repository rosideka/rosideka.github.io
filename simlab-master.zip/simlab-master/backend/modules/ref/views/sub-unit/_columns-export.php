<?php

/* @var $searchModel common\models\refs\searches\RefSubUnitSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID_UNIT',
        'label' => $searchModel->getAttributeLabel('ID_UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'UNIT',
        'label' => $searchModel->getAttributeLabel('UNIT'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'SUB_UNIT',
        'label' => $searchModel->getAttributeLabel('SUB_UNIT'),
    ],
];
