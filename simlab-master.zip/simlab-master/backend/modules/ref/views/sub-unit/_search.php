<?php

use common\models\refs\RefUnit;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\searches\RefSubUnitSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-sub-unit-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
            <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'ID_UNIT')->widget(Select2::class, [
                'data' => RefUnit::map(),
                'options' => ['placeholder' => Yii::t('app', '-- Pilih --')],
                'pluginOptions' => ['allowClear' => true],
            ]) ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'KODE') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'SUB_UNIT') ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
