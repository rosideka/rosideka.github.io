<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefPermintaanProses */

$this->title = Yii::t('app', 'Tambah Ref Permintaan Proses');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Permintaan Proses'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-permintaan-proses-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
