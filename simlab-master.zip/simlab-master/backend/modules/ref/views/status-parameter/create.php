<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefStatusParameter */

$this->title = Yii::t('app', 'Tambah Ref Status Parameter');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Status Parameter'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-status-parameter-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
