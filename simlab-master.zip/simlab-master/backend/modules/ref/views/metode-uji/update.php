<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefMetodeUji */

$this->title = Yii::t('app', 'Update Ref Metode Uji');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Metode Uji'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-metode-uji-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
