<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefMetodeUji */

$this->title = Yii::t('app', 'Tambah Ref Metode Uji');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Metode Uji'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-metode-uji-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
