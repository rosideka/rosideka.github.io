<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefMetodeUji */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-metode-uji-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Form Ref Metode Uji') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($model, 'NAMA_METODE')->textInput(['maxlength' => true]) ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Tambah') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
