<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefMetodeUji */

$this->title = Yii::t('app', 'Ref Metode Uji');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Metode Uji'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-metode-uji-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Metode Uji') ?></div>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width:33.33%'],
                    ],
                    'NAMA_METODE',
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]) ?>

        </div>
    </div>
</div>
