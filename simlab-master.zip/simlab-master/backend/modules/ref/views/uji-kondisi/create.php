<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiKondisi */

$this->title = Yii::t('app', 'Tambah Ref Uji Kondisi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Kondisi'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-kondisi-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
