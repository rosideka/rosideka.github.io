<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiKondisi */

$this->title = Yii::t('app', 'Update Ref Uji Kondisi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Kondisi'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-kondisi-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
