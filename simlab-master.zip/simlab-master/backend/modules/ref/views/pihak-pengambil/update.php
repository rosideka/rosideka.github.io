<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefPihakPengambil */

$this->title = Yii::t('app', 'Update Ref Pihak Pengambil');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Pihak Pengambil'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-pihak-pengambil-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
