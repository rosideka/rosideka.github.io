<?php

/* @var $searchModel common\models\refs\searches\RefJenisKelaminSearch */

return [
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'ID',
        'label' => $searchModel->getAttributeLabel('ID'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'KODE',
        'label' => $searchModel->getAttributeLabel('KODE'),
    ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'JENIS_KELAMIN',
        'label' => $searchModel->getAttributeLabel('JENIS_KELAMIN'),
    ],
];
