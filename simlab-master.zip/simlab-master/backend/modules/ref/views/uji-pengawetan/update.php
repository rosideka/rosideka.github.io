<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiPengawetan */

$this->title = Yii::t('app', 'Update Ref Uji Pengawetan');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Pengawetan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-pengawetan-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
