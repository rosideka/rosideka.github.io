<?php

use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $model common\models\refs\RefLayanan */
/* @var $dataSubLayanan common\models\refs\RefLayanan[] */

$this->registerCss($this->render('form/_style.css'));
?>
<div class="ref-layanan-form">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= Yii::t('app', 'Form Ref Layanan') ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(['id' => 'sl_form']); ?>

            <div class="callout callout-info sl-callout">
                <h4 class="text-uppercase"><?= Yii::t('app', 'Layanan') ?></h4>
            </div>

            <?= $form->field($model, 'NAMA')->textInput([
                'maxlength' => true,
                'placeholder' => Yii::t('app', 'Nama Layanan'),
            ]) ?>

            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'sl_container',
                'widgetBody' => '.sl-items',
                'widgetItem' => '.sl-item',
                'min' => 1,
                'insertButton' => '.sl-add-item',
                'deleteButton' => '.sl-del-item',
                'model' => $dataSubLayanan[0],
                'formId' => 'sl_form',
                'formFields' => ['ID_LAYANAN', 'NAMA'],
            ]); ?>

            <div class="callout callout-info sl-callout">
                <h4 class="text-uppercase"><?= Yii::t('app', 'Sub Layanan') ?></h4>
                <p><?= Yii::t('app', 'Silakan isikan sub layanan melalui form berikut:') ?></p>
            </div>

            <div class="sl-items">
                <div class="row no-padding" style="margin-bottom: 10px">
                    <div class="col-xs-3 col-sm-offset-9">
                        <?= Html::button(
                            '<i class="glyphicon glyphicon-plus"></i> ' . Yii::t('app', 'Tambah'),
                            ['class' => 'btn btn-success sl-add-item btn-block']
                        ) ?>

                    </div>
                </div>
                <?php foreach ($dataSubLayanan as $index => $subLayanan): ?>
                    <?= $subLayanan->isNewRecord ? Html::activeHiddenInput($subLayanan, "[{$index}]ID") : '' ?>

                    <div class="row no-padding sl-item">
                        <div class="col-xs-9">
                            <?=
                            $form
                                ->field($subLayanan, "[{$index}]NAMA")
                                ->textInput([
                                    'maxlength' => true,
                                    'placeholder' => Yii::t('app', 'Nama Sub Layanan'),
                                ])
                                ->label(false)
                            ?>

                        </div>
                        <div class="col-sm-3">
                            <?= Html::button(
                                '<i class="glyphicon glyphicon-trash"></i> Hapus',
                                ['class' => 'btn btn-block btn-danger sl-del-item']
                            ) ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php DynamicFormWidget::end(); ?>

            <?php if (!Yii::$app->request->isAjax) { ?>
                <div class="form-group">
                    <?= Html::submitButton(
                        $model->isNewRecord ? Yii::t('app', 'Simpan') : Yii::t('app', 'Update'),
                        ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
                    ?>
                </div>
            <?php } ?>

            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
