<?php


/* @var $this yii\web\View */
/* @var $model common\models\refs\RefLayanan */
/* @var $dataSubLayanan common\models\refs\RefSubLayanan[] */

$this->title = Yii::t('app', 'Tambah Ref Layanan');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Layanan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-layanan-create">
    <?= $this->render('_form', [
        'model' => $model,
        'dataSubLayanan' => $dataSubLayanan,
    ]) ?>
</div>
