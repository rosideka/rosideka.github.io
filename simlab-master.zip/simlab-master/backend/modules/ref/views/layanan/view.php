<?php

use kartik\grid\GridView;
use yii\data\ActiveDataProvider;
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefLayanan */

$this->title = Yii::t('app', 'Ref Layanan');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Layanan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-layanan-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Layanan') ?></h2>
        </div>
        <div class="box-body">
            <?php
            echo DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width: 33.33%'],
                    ],
                    'NAMA',
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]);

            echo Html::tag('h4', Yii::t('app', 'Sub Layanan'), ['class' => 'text-uppercase']);

            echo GridView::widget([
                'dataProvider' => new ActiveDataProvider([
                    'query' => $model->getDataSubLayanan(),
                    'pagination' => false,
                ]),
                'pjax' => true,
                'pjaxSettings' => [
                    'options' => [
                        'enablePushState' => false,
                        'enableReplaceState' => false,
                    ],
                ],
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => 'kartik\grid\ExpandRowColumn',
                        'expandAllTitle' => Yii::t('app', 'Detail'),
                        'collapseTitle' => Yii::t('app', 'Detail'),
                        'expandIcon' => '<span class="glyphicon glyphicon-expand"></span>',
                        'value' => function () {
                            return GridView::ROW_COLLAPSED;
                        },
                        'detail' => function ($model) {
                            return DetailView::widget([
                                'model' => $model,
                                'options' => [
                                    'class' => 'table table-striped table-bordered detail-view',
                                    'style' => 'margin-bottom: 0',
                                ],
                                'attributes' => [
                                    [
                                        'label' => Yii::t('app', 'Create'),
                                        'captionOptions' => ['style' => 'width:33.33%'],
                                        'value' => implode(' ', [
                                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                                            $model->CREATE_IP,
                                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                                        ]),
                                        'format' => 'raw',
                                    ],
                                    [
                                        'label' => Yii::t('app', 'Update'),
                                        'value' => implode(' ', [
                                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                                            $model->UPDATE_IP,
                                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                                        ]),
                                        'format' => 'raw',
                                    ],
                                ],
                            ]);
                        },
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'NAMA',
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'panel' => false,
                'summary' => false,
            ])
            ?>

        </div>
    </div>
</div>
