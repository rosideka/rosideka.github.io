<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\refs\searches\RefBankSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="ref-bank-search search-form">
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
        <div class="col-sm-3">
              <?= $form->field($model, 'ID') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'KODE') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'NAMA') ?>

        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'IS_AKTIF')->dropDownList(
                [1 => 'Ya', 0 => 'Tidak'],
                ['prompt' => Yii::t('app', '-- Pilih --')],
            ) ?>

        </div>
    </div>
    <div class="form-group" style="margin-bottom: 0">
        <?= Html::submitButton(
            '<i class="fa fa-cog"></i> ' . Yii::t('app', 'Proses'),
            ['class' => 'btn btn-primary']
        ) ?>

        <?= Html::a(
            '<i class="glyphicon glyphicon-refresh"></i> ' . Yii::t('app', 'Reset'),
            ['index'],
            ['class' => 'btn btn-default']
        ) ?>

    </div>

    <?php ActiveForm::end(); ?>

</div>
