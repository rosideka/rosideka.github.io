<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\refs\RefBank */

$this->title = Yii::t('app', 'Tambah Ref Bank');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Bank'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-bank-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
