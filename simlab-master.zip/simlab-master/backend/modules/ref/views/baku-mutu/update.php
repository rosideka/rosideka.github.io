<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefBakuMutu */

$this->title = Yii::t('app', 'Update Ref Baku Mutu');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Baku Mutu'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-baku-mutu-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
