<?php
use yii\helpers\Url;

/* @var $searchModel common\models\refs\searches\RefBakuMutuSearch */

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'ID',
    // 'label' => $searchModel->getAttributeLabel('ID'),
    // ],
    [
        'class' => '\kartik\grid\DataColumn',
        'attribute' => 'NAMA_BAKU_MUTU',
        'label' => $searchModel->getAttributeLabel('NAMA_BAKU_MUTU'),
    ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'CREATE_DATE',
    // 'label' => $searchModel->getAttributeLabel('CREATE_DATE'),
    // ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'CREATE_BY',
    // 'label' => $searchModel->getAttributeLabel('CREATE_BY'),
    // ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'CREATE_IP',
    // 'label' => $searchModel->getAttributeLabel('CREATE_IP'),
    // ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'UPDATE_DATE',
    // 'label' => $searchModel->getAttributeLabel('UPDATE_DATE'),
    // ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'UPDATE_BY',
    // 'label' => $searchModel->getAttributeLabel('UPDATE_BY'),
    // ],
    // [
    // 'class'=>'\kartik\grid\DataColumn',
    // 'attribute' => 'UPDATE_IP',
    // 'label' => $searchModel->getAttributeLabel('UPDATE_IP'),
    // ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign' => 'middle',
        'urlCreator' => function ($action, $model, $key, $index) {
            return Url::to([$action, 'id' => $key]);
        },
        'viewOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Detail'), 'data-toggle' => 'tooltip'],
        'updateOptions' => ['role' => 'modal-remote', 'title' => Yii::t('app', 'Update'), 'data-toggle' => 'tooltip'],
        'deleteOptions' => [
            'role' => 'modal-remote',
            'title' => Yii::t('app', 'Delete'),
            'data-confirm' => false,
            'data-method' => false,
            'data-request-method' => 'post',
            'data-toggle' => 'tooltip',
            'data-confirm-title' => Yii::t('app', 'Are you sure?'),
            'data-confirm-message' => Yii::t('app', 'Are you sure want to delete this item'),
        ],
    ],
];
