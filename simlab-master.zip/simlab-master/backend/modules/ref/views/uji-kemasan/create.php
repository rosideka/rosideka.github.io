<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiKemasan */

$this->title = Yii::t('app', 'Tambah Ref Uji Kemasan');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Kemasan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-kemasan-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
