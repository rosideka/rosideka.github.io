<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefUjiKemasan */

$this->title = Yii::t('app', 'Ref Uji Kemasan');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Uji Kemasan'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-uji-kemasan-view">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <div class="box-title text-uppercase"><?= Yii::t('app', 'Detail Ref Uji Kemasan') ?></div>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width:33.33%'],
                    ],
                    'KEMASAN',
                    [
                        'label' => Yii::t('app', 'Create'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->CREATE_BY ? $model->createBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->CREATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->CREATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                    [
                        'label' => Yii::t('app', 'Update'),
                        'value' => implode(' ', [
                            '<i class="glyphicon glyphicon-user text-gray"></i>',
                            $model->UPDATE_BY ? $model->updateBy->USERNAME : null,
                            '<i class="glyphicon glyphicon-globe text-gray"></i>',
                            $model->UPDATE_IP,
                            '<i class="glyphicon glyphicon-time text-gray"></i>',
                            Yii::$app->formatter->asDate($model->UPDATE_DATE, 'php:l, d F Y'),
                        ]),
                        'format' => 'raw',
                    ],
                ],
            ]) ?>

        </div>
    </div>
</div>
