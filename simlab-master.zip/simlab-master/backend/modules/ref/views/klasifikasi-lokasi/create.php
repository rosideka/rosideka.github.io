<?php

/* @var $this yii\web\View */
/* @var $model common\models\refs\RefKlasifikasiLokasi */

$this->title = Yii::t('app', 'Tambah Ref Klasifikasi Lokasi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dashboard Ref Klasifikasi Lokasi'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="ref-klasifikasi-lokasi-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
