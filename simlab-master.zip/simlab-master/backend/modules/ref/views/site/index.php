<?php
/**
 * @link https://simpeg.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2016 UPT TIK UNS
 */

use kartik\grid\GridView;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $smReferensi backend\modules\ref\models\ReferensiSearch */
/* @var $dpReferensi yii\data\ArrayDataProvider */
/* @var $smNominasi backend\modules\ref\models\NominasiSearch */
/* @var $dpNominasi yii\data\ArrayDataProvider */

$this->title = 'Dashboard Pengaturan Referensi';
$this->params['breadcrumbs'][] = $this->title;
$this->registerCss('.box-body .wrap{margin-top: -15px} .box-body .btn-social{margin-top: 15px}');

?>
<div class="nav-tabs-custom">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#tab-referensi" data-toggle="tab">Referensi</a></li>
        <li><a href="#tab-nominasi" data-toggle="tab">Nominasi</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="tab-referensi">
            <?= GridView::widget([
                'id' => 'cd-referensi',
                'filterModel' => $smReferensi,
                'dataProvider' => $dpReferensi,
                'pjax' => true,
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'label' => '',
                        'hAlign' => 'center',
                        'attribute' => 'icon',
                        'value' => function ($model) {
                            return '<i class="' . $model['icon'] . '"></i>';
                        },
                        'format' => 'raw',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'label',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'description',
                    ],
                    [
                        'class' => 'kartik\grid\ActionColumn',
                        'dropdown' => false,
                        'vAlign' => 'middle',
                        'urlCreator' => function ($action, $model, $key, $index) {
                            return $model['url'];
                        },
                        'template' => '{referensi}',
                        'buttons' => [
                            'referensi' => function ($url, $model, $key) {
                                return Html::a(
                                    '<i class="glyphicon glyphicon-th-large"></i>',
                                    $url,
                                    [
                                        'class' => 'btn btn-success btn-sm',
                                        'title' => $model['description'],
                                        'data-pjax' => '0',
                                    ]
                                );
                            },
                        ],
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'toolbar' => [
                    [
                        'content' =>
                            Html::a(
                                '<i class="glyphicon glyphicon-repeat"></i>',
                                ['index'],
                                [
                                    'data-pjax' => 1,
                                    'class' => 'btn btn-default',
                                    'title' => 'Reset Grid',
                                ]
                            )
                            . '{toggleData} {export}',
                    ],
                ],
                'panel' => [
                    'type' => 'default',
                    'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Referensi'),
                    'after' =>
                        Html::a(
                            '<i class="glyphicon glyphicon-repeat"></i> Reset List',
                            ['index'],
                            ['class' => 'btn btn-primary btn-xs']
                        )
                        . '<div class="clearfix"></div>',
                ],
            ]) ?>

        </div>
        <div class="tab-pane" id="tab-nominasi">
            <?= GridView::widget([
                'id' => 'cd-nominasi',
                'filterModel' => $smNominasi,
                'dataProvider' => $dpNominasi,
                'pjax' => true,
                'columns' => [
                    [
                        'class' => 'kartik\grid\SerialColumn',
                        'width' => '30px',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'label' => '',
                        'hAlign' => 'center',
                        'attribute' => 'icon',
                        'value' => function ($model) {
                            return '<i class="' . $model['icon'] . '"></i>';
                        },
                        'format' => 'raw',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'label',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'description',
                    ],
                    [
                        'class' => 'kartik\grid\ActionColumn',
                        'dropdown' => false,
                        'vAlign' => 'middle',
                        'urlCreator' => function ($action, $model, $key, $index) {
                            return $model['url'];
                        },
                        'template' => '{referensi}',
                        'buttons' => [
                            'referensi' => function ($url, $model, $key) {
                                return Html::a(
                                    '<i class="glyphicon glyphicon-th-large"></i>',
                                    $url,
                                    [
                                        'class' => 'btn btn-success btn-sm',
                                        'title' => $model['description'],
                                        'data-pjax' => '0',
                                    ]
                                );
                            },
                        ],
                    ],
                ],
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'toolbar' => [
                    [
                        'content' =>
                            Html::a(
                                '<i class="glyphicon glyphicon-repeat"></i>',
                                ['index'],
                                [
                                    'data-pjax' => 1,
                                    'class' => 'btn btn-default',
                                    'title' => 'Reset Grid',
                                ]
                            )
                            . '{toggleData} {export}',
                    ],
                ],
                'panel' => [
                    'type' => 'default',
                    'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Nominasi'),
                    'after' =>
                        Html::a(
                            '<i class="glyphicon glyphicon-repeat"></i> Reset List',
                            ['index'],
                            ['class' => 'btn btn-primary btn-xs']
                        )
                        . '<div class="clearfix"></div>',
                ],
            ]) ?>
      
        </div>
    </div>
</div>
