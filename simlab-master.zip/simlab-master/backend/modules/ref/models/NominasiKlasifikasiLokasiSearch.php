<?php

namespace backend\modules\ref\models;

use common\models\simlab\Uji;
use yii\base\Model;
use yii\data\SqlDataProvider;
use yii\db\ActiveQuery;

/**
 * NklSearch represents the model behind the search form about `common\models\simlab\Uji`.
 */
class NominasiKlasifikasiLokasiSearch extends Uji
{
    /**
     * {@inheritdoc}
     */
    public function attributes()
    {
        return array_merge(parent::attributes(), ['JML_UJI']);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['JML_UJI'], 'integer'],
            [['KLASIFIKASI_LOKASI'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    public function attributeLabels()
    {
        return array_merge(parent::attributeLabels(), [
            'JML_UJI' => 'Jml. Uji',
        ]);
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function search($params)
    {
        $query = static::query();
        $this->load($params);
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'totalCount' => $query->count(),
            'key' => 'KLASIFIKASI_LOKASI',
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * Creates data provider instance with search query applied for export
     *
     * @param array $params
     *
     * @return SqlDataProvider
     */
    public function export($params)
    {
        $query = static::query();
        $this->load($params);
        $this->setFilter($query);

        return new SqlDataProvider([
            'sql' => $query->createCommand()->rawSql,
            'totalCount' => $query->count(),
            'key' => 'KLASIFIKASI_LOKASI',
            'sort' => ['attributes' => $this->attributes()],
            'pagination' => ['defaultPageSize' => 20],
        ]);
    }

    /**
     * @param ActiveQuery $query
     */
    protected function setFilter(ActiveQuery &$query)
    {
        if (!$this->validate()) {
            // Don't show data when not valid
            $query->andWhere('0 = 1');
        }

        $query->andFilterHaving([
            'JML_UJI' => $this->JML_UJI,
        ]);

        $query->andFilterWhere(['ilike', 'KLASIFIKASI_LOKASI', $this->KLASIFIKASI_LOKASI]);
    }

    /**
     * Create query for data provider
     *
     * @return ActiveQuery
     */
    public static function query()
    {
        return Uji::find()
            ->select([
                'KLASIFIKASI_LOKASI' => 'KLASIFIKASI_LOKASI',
                'JML_UJI' => 'COUNT(*)',
            ])
            ->andWhere(['is', 'ID_KLASIFIKASI_LOKASI', null])
            ->groupBy('KLASIFIKASI_LOKASI');
    }
}
