<?php

namespace backend\modules\ref\models;

use Yii;
use yii\base\Model;
use yii\data\ArrayDataProvider;

/**
 * Class ReferensiSearch
 *
 * @author agiel
 */
class ReferensiSearch extends Model
{
    public $label;

    public $description;

    /**
     * {@inheritdoc}
     */
    public function rules(): array
    {
        return [
            [['label', 'description'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels(): array
    {
        return [
            'label' => Yii::t('app', 'Nama'),
            'description' => Yii::t('app', 'Deskripsi'),
        ];
    }

    /**
     * @param array $params
     * @return ArrayDataProvider
     */
    public function search($params)
    {
        $items = [
            [
                'label' => Yii::t('app', 'Baku Mutu'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Baku Mutu'),
                'url' => ['/ref/baku-mutu'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Bank'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Bank'),
                'url' => ['/ref/bank'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Jenis Kelamin'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Jenis Kelamin'),
                'url' => ['/ref/jenis-kelamin'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Jenis Member'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Jenis Member'),
                'url' => ['/ref/jenis-member'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Jenis Paket'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Jenis Paket'),
                'url' => ['/ref/jenis-paket'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Klasifikasi Lokasi'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Klasifikasi Lokasi'),
                'url' => ['/ref/klasifikasi-lokasi'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Laboratorium'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Laboratorium'),
                'url' => ['/ref/lab'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Layanan'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Layanan'),
                'url' => ['/ref/layanan'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Metode Uji'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Metode Uji'),
                'url' => ['/ref/metode-uji'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Unit'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Unit'),
                'url' => ['/ref/unit'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Parameter'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Parameter'),
                'url' => ['/ref/parameter'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Permintaan Proses'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Baku Mutu'),
                'url' => ['/ref/permintaan-proses'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Pihak Pengambil'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Pihak Pengambil'),
                'url' => ['/ref/pihak-pengambil'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            /*
            [
                'label' => 'Satuan Paket',
                'url' => ['/ref/satuan-paket'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            */
            [
                'label' => Yii::t('app', 'Status Parameter'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Status Parameter'),
                'url' => ['/ref/status-parameter'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Status Uji'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Status Uji'),
                'url' => ['/ref/status-uji'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Sub Unit'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Sub Unit'),
                'url' => ['/ref/sub-unit'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Kemasan'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Kemasan'),
                'url' => ['/ref/uji-kemasan'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Ketersediaan'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Ketersediaan'),
                'url' => ['/ref/uji-ketersediaan'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Kondisi'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Kondisi'),
                'url' => ['/ref/uji-kondisi'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Kondisi Diterima'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Kondisi Diterima'),
                'url' => ['/ref/uji-kondisi-diterima'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Pengawetan'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Pengawetan'),
                'url' => ['/ref/uji-pengawetan'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
            [
                'label' => Yii::t('app', 'Uji Retensi'),
                'description' => Yii::t('app', 'Dashboard Referensi') . ' ' . Yii::t('app', 'Uji Retensi'),
                'url' => ['/ref/uji-retensi'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
        ];

        $this->load($params);

        $items = array_filter($items, function ($item) {
            $conditions = [true];

            if (!empty($this->label)) {
                $conditions[] = strpos(strtolower($item['label']), strtolower($this->label)) !== false;
            }

            if (!empty($this->description)) {
                $conditions[] = strpos(strtolower($item['description']), strtolower($this->description)) !== false;
            }

            return array_product($conditions);
        });

        $dataProvider = new ArrayDataProvider([
            'allModels' => $items,
            'pagination' => ['defaultPageSize' => 20, 'pageParam' => 'pu'],
            'sort' => ['attributes' => ['label', 'description', 'url'], 'sortParam' => 'su'],
        ]);

        return $dataProvider;
    }
}
