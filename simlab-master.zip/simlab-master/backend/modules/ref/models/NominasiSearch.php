<?php

namespace backend\modules\ref\models;

use Yii;
use yii\base\Model;
use yii\data\ArrayDataProvider;

/**
 * Class ReferensiSearch
 *
 * @author agiel
 */
class NominasiSearch extends Model
{
    public $label;

    public $description;

    /**
     * {@inheritdoc}
     */
    public function rules(): array
    {
        return [
            [['label', 'description'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels(): array
    {
        return [
            'label' => Yii::t('app', 'Nama'),
            'description' => Yii::t('app', 'Deskripsi'),
        ];
    }

    /**
     * @param array $params
     * @return ArrayDataProvider
     */
    public function search($params)
    {
        $items = [
            [
                'label' => Yii::t('app', 'Klasifikasi Lokasi'),
                'description' => Yii::t('app', 'Dashboard Nominasi') . ' ' . Yii::t('app', 'Klasifikasi Lokasi'),
                'url' => ['/ref/nominasi-klasifikasi-lokasi'],
                'icon' => 'fa fa-bars',
                'options' => ['class' => 'btn btn-block btn-social btn-linkedin'],
            ],
        ];

        $this->load($params);

        $items = array_filter($items, function ($item) {
            $conditions = [true];

            if (!empty($this->label)) {
                $conditions[] = strpos(strtolower($item['label']), strtolower($this->label)) !== false;
            }

            if (!empty($this->description)) {
                $conditions[] = strpos(strtolower($item['description']), strtolower($this->description)) !== false;
            }

            return array_product($conditions);
        });

        $dataProvider = new ArrayDataProvider([
            'allModels' => $items,
            'pagination' => ['defaultPageSize' => 20, 'pageParam' => 'pu'],
            'sort' => ['attributes' => ['label', 'description', 'url'], 'sortParam' => 'su'],
        ]);

        return $dataProvider;
    }
}
