<?php

/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace backend\controllers;

use common\models\eis\Pegawai as EisPegawai;
use common\models\refs\RefJenisPaket;
use common\models\refs\RefMetodeUji;
use common\models\refs\RefParameterMetode;
use common\models\refs\RefSubLayanan;
use common\models\refs\RefSubUnit;
use common\models\simlab\Member;
use common\models\simlab\Paket;
use common\models\simlab\Pegawai;
use common\models\simlab\Uji;
use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\redis\ActiveQuery;
use yii\web\Controller;
use yii\web\Response;

/**
 * Class ApiController
 * @package frontend\controllers
 */
class ApiController extends Controller
{
    /**
     * @param $name
     * @param $index
     * @param $parent
     * @return array
     */
    public function actionJenisPaket($name, $index, $parent)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        preg_match("/\[(\d+)\]/", $name, $matches);

        if ($parent && $matches) {
            $iu = $matches[1];
            $ijp = $index + 1;
            $map = RefJenisPaket::map('ID', 'JENIS_PAKET', ['ID_PARENT' => $parent]);

            if ($map) {
                $model = new Uji();
                $attribute = "[{$iu}]dataJenisPaket[{$ijp}]";
                $inputId = Html::getInputId($model, $attribute);

                $field = Html::beginTag('div', ['class' => 'field-' . $inputId . ' form-group']);
                $field .= Html::activeDropDownList($model, $attribute, $map, [
                    'class' => ['form-control fi-jenis-paket'],
                    'prompt' => Yii::t('app', '-- Lainnya --'),
                ]);
                $field .= Html::tag('div', '', ['class' => 'help-block']);
                $field .= Html::endTag('div');

                return [
                    'id' => $inputId,
                    'name' => Html::getInputName($model, $attribute),
                    'field' => $field,
                ];
            }
        }

        return null;
    }

    /**
     * @param $idjp
     * @param $idbm
     * @return array|null
     */
    public function actionPaket(int $idjp, int $idbm)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($idjp && $idbm) {
            return Paket::map('A.ID', 'A.NAMA', ['ID_JENIS_PAKET' => $idjp, 'ID_BAKU_MUTU' => $idbm]);
        }

        return null;
    }

    /**
     * Generate API
     *
     * @param int $id
     * @return array
     */
    public function actionMetodeUji(int $id)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        return [
            'output' => RefParameterMetode::map('B.ID', 'B.NAMA_METODE', ['ID_PARAMETER' => $id]),
            'selected' => RefParameterMetode::find()
                ->select('ID_METODE_UJI')
                ->where(['ID_PARAMETER' => $id, 'IS_DEFAULT' => 1])
                ->scalar(),
        ];
    }

    /**
     * @param $q
     * @param null $id
     * @return array
     */
    public function actionIdPegawai($q, $id = null)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($q) {
            $query = Pegawai::find()
                ->select([
                    'id' => 'A.ID_PEGAWAI',
                    'text' => 'CONCAT_WS(\' - \', "A"."ID_PEGAWAI", "A"."NAMA_LENGKAP", "A"."NIP")',
                ])
                ->from(['A' => Pegawai::tableName()])
                ->where(['or', ['ilike', 'A.NAMA_LENGKAP', $q], ['ilike', 'A.NIP', $q]])
                ->limit(20);

            return ['results' => $query->asArray()->all()];
        }

        return ['results' => [['id' => $id, 'text' => '']]];
    }

    /**
     * @param $q
     * @param null $id
     * @return array
     */
    public function actionIdEisPegawai($q, $id = null)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($q) {
            $query = EisPegawai::find()
                ->select([
                    'id' => 'A.ID',
                    'text' => 'CONCAT_WS(\' - \', A.ID, A.NAMA_LENGKAP, A.NIP)',
                ])
                ->from(['A' => EisPegawai::tableName()])
                ->where(['or', ['like', 'A.NAMA_LENGKAP', $q], ['like', 'A.NIP', $q]])
                ->limit(20);

            return ['results' => $query->asArray()->all()];
        }

        return ['results' => [['id' => $id, 'text' => '']]];
    }

    /**
     * @param $q
     * @param null $id
     * @return array
     */
    public function actionIdMember($q, $id = null)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($q) {
            $query = Member::find()
                ->select([
                    'id' => 'A.ID',
                    'text' => 'CONCAT_WS(\' - \', "A"."ID", "A"."NAMA")',
                ])
                ->from(['A' => Member::tableName()])
                ->where(['ilike', 'A.NAMA', $q])
                ->limit(20);

            return ['results' => $query->asArray()->all()];
        }

        return ['results' => [['id' => $id, 'text' => '']]];
    }

    /**
     * @return array
     */
    public function actionDepdropMetodeUji()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($parents = Yii::$app->request->post('depdrop_parents')) {
            $id = ArrayHelper::getValue($parents, '0');

            return [
                'output' => RefParameterMetode::find()->select(['id' => 'B.ID', 'name' => 'B.NAMA_METODE'])
                    ->from(['A' => RefParameterMetode::tableName()])
                    ->joinWith([
                        'idMetodeUji' => function (ActiveQuery $q) {
                            return $q->from(['B' => RefMetodeUji::tableName()]);
                        },
                    ], false)
                    ->asArray()
                    ->all(),
                'selected' => RefParameterMetode::find()
                    ->select('ID_METODE_UJI')
                    ->where(['ID_PARAMETER' => $id, 'IS_DEFAULT' => 1])
                    ->scalar(),
            ];
        }

        return ['output' => '', 'selected' => ''];
    }

    public function actionDepdropSubUnit($id = null)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($parents = Yii::$app->request->post('depdrop_parents')) {
            $id = ArrayHelper::getValue($parents, 0);

            if (!$id) {
                return ['output' => '', 'selected' => ''];
            }

            return [
                'output' => RefSubUnit::find()
                    ->select(['id' => 'ID', 'name' => 'SUB_UNIT'])
                    ->where(['ID_UNIT' => $id])
                    ->orderBy(['KODE' => SORT_ASC])
                    ->asArray()
                    ->all(),
                'selected' => '',
            ];
        }

        return ['output' => '', 'selected' => ''];
    }

    public function actionDepdropSubLayanan($id = null)
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        if ($parents = Yii::$app->request->post('depdrop_parents')) {
            $id = ArrayHelper::getValue($parents, 0);

            if (!$id) {
                return ['output' => '', 'selected' => ''];
            }

            return [
                'output' => RefSubLayanan::find()
                    ->select(['id' => 'ID', 'name' => 'NAMA'])
                    ->where(['ID' => $id])
                    ->asArray()
                    ->all(),
                'selected' => '',
            ];
        }

        return ['output' => '', 'selected' => ''];
    }
}
