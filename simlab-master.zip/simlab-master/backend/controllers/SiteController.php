<?php

namespace backend\controllers;

use common\models\forms\LoginForm;
use common\models\simlab\searches\AgendaSearch;
use common\models\simlab\searches\UjiSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;

/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'actions' => ['login', 'error'],
                        'allow' => true,
                    ],
                    [
                        'actions' => ['logout', 'index'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $params = Yii::$app->request->queryParams;

        $smAgenda = new AgendaSearch();
        $dpAgenda = $smAgenda->search($params);
        $dpAgenda->sort->sortParam = 'sa';
        $dpAgenda->pagination->pageParam = 'pa';
        $dpAgenda->pagination->defaultPageSize = 10;

        $smUji = new UjiSearch();
        $dpUji = $smUji->search($params);
        $dpUji->sort->sortParam = 'su';
        $dpUji->pagination->pageParam = 'pu';
        $dpUji->pagination->defaultPageSize = 10;

        return $this->render('index', [
            'smAgenda' => $dpAgenda,
            'dpAgenda' => $dpAgenda,
            'smUji' => $smUji,
            'dpUji' => $dpUji,
        ]);
    }

    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        $model->password = '';

        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }
}
