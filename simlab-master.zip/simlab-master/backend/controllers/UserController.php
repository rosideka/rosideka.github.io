<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace backend\controllers;

use common\models\User;
use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/**
 * Class UserController
 * @package backend\controllers
 */
class UserController extends Controller
{
    /**
     * View profile for active user
     */
    public function actionProfile()
    {
        $model = $this->findModel(Yii::$app->user->id);

        return $this->render('profile', [
            'model' => $model,
        ]);
    }

    /**
     * Update profile for active user
     */
    public function actionUpdateProfile()
    {
        $request = Yii::$app->request;
        $model = $this->findModel(Yii::$app->user->id);

        if ($model->load($request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Update profile berhasil'));
            return $this->redirect(['profile']);
        }
        return $this->render('update-profile', [
            'model' => $model,
        ]);
    }

    /**
     * Update password for active user
     */
    public function actionResetPassword()
    {
        $model = $this->findModel(Yii::$app->user->id);
        $model->setScenario('resetPassword');
        if ($model->load(Yii::$app->request->post())) {
            $model->setPassword($model->password);
            if ($model->save()) {
                return $this->redirect(['profile']);
            }
        }

        return $this->render('reset-password', [
            'model' => $model,
        ]);
    }

    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException(Yii::t('app', 'Halaman yang diminta tidak tersedia.'));
    }
}
