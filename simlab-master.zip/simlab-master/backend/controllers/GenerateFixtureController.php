<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers;

use Yii;
use yii\web\Controller;

/**
 * Description of TestController
 *
 * @author agiel
 */
class GenerateFixtureController extends Controller
{
    public function actionRefBank()
    {
        $models = Yii::$app->db->createCommand('SELECT * FROM "REF_BANK"')->queryAll();
        echo '<pre>';
        echo "&lt;?php\n\n";
        echo "return [\n";
        foreach ($models as $index => $model) {
            echo "    'ref_bank{$index}'  => [\n";
            echo "        'KODE' => '{$model['KODE']}',\n";
            echo "        'NAMA' => '{$model['NAMA']}',\n";
            echo "        'IS_AKTIF' => {$model['IS_AKTIF']},\n";
            echo "        'CREATE_DATE' => unserialize('O:17:\"yii\\db\\Expression\":2:{s:10:\"expression\";s:5:\"NOW()\";s:6:\"params\";a:0:{}}'),\n";
            echo "        'CREATE_BY' => 1,\n";
            echo "        'CREATE_IP' => '127.0.0.1',\n";
            echo "        'UPDATE_DATE' => unserialize('O:17:\"yii\\db\\Expression\":2:{s:10:\"expression\";s:5:\"NOW()\";s:6:\"params\";a:0:{}}'),\n";
            echo "        'UPDATE_BY' => 1,\n";
            echo "        'UPDATE_IP' => '127.0.0.1',\n";
            echo "    ],\n";
        }
        echo "];\n";
        echo '</pre>';
        exit();
    }
}
