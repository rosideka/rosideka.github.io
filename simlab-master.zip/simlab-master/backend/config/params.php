<?php
return [
    'adminEmail' => 'uptlabterpadu@unit.uns.ac.id',
];
