<?php

$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

$configs = require(__DIR__ . '/../../common/config/main.php');

return [
    'id' => 'simlab-backend',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'backend\controllers',
    'bootstrap' => ['log'],
    'modules' => [
        'rbac' => [
            'class' => 'mdm\admin\Module',
            'mainLayout' => '@backend/views/layouts/rbac.php',
            'layout' => 'left-menu',
            'controllerMap' => [
                'assignment' => [
                    'class' => 'mdm\admin\controllers\AssignmentController',
                    'searchClass' => 'common\models\searches\UserSearch',
                    'idField' => 'ID',
                    'usernameField' => 'USERNAME',
                ],
            ],
        ],

        'log' => '\backend\modules\log\Module',

        'ref' => '\backend\modules\ref\Module',

        'uji' => '\backend\modules\uji\Module',

        'gridview' => '\kartik\grid\Module',

        'manage' => '\backend\modules\manage\Module',
    ],
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-simlab',
        ],

        'errorHandler' => [
            'errorAction' => 'site/error',
        ],

        'urlManager' => $configs['components']['umBack'],
    ],
    'params' => $params,
];
