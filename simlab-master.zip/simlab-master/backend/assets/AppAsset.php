<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace backend\assets;

use yii\web\AssetBundle;

/**
 * Asset bundle for backend.
 *
 * @package backend\assets
 * @author Agiel K. Saputra <13nightevil@gmail.com>
 * @since 0.1.0
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@appPath';

    public $baseUrl = '@appUrl';

    /**
     * @var array
     */
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\bootstrap\BootstrapPluginAsset',
        'rmrevin\yii\fontawesome\AssetBundle',
        'themes\adminlte\assets\FastClickAsset',
        'themes\adminlte\assets\SlimScrollAsset',
        'themes\adminlte\assets\ThemeAsset',
        'backend\assets\AppAssetIe9',
    ];

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        if (YII_DEBUG) {
            $this->css = ['css/backend.css'];
            $this->js = ['js/jquery.match-height.js'];
        } else {
            $this->css = ['css/backend.min.css'];
            $this->js = ['js/jquery.match-height.min.js'];
        }
    }
}
