<?php

use kartik\grid\GridView;

/* @var $this yii\web\View */
/* @var $smAgenda common\models\simlab\searches\AgendaSearch */
/* @var $dpAgenda yii\data\SqlDataProvider */
/* @var $smUji common\models\simlab\searches\UjiSearch */
/* @var $dpUji yii\data\SqlDataProvider */

$this->title = 'SIMLAB UPT LAB TERPADU UNS';
?>
<div class="site-index">
    <div class="row">
        <div class="col-sm-6">
            <div class="bg-blue info-box">
                <span class="info-box-icon"><i class="fa fa-calendar"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><b>Agenda</b></span>
                    <span class="info-box-number"><?= $dpAgenda->totalCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 100%"></div>
                    </div>
                    <span class="progress-description">
                        <?= Yii::t('app', 'Total Agenda') ?>
                    </span>
                </div>
            </div>
            <?= GridView::widget([
                'dataProvider' => $dpAgenda,
                'pjax' => true,
                'summary' => '',
                'pjaxSettings' => ['neverTimeout' => true],
                'resizableColumns' => true,
                'resizeStorageKey' => Yii::$app->user->id . '-' . date("m"),
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'showPageSummary' => false,
                'hover' => true,
                'columns' => [
                    ['class' => 'kartik\grid\SerialColumn'],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'NAMA',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'TANGGAL_PENERIMAAN',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'STATUS_UJI',
                    ],
                ],
                'panel' => [
                    'type' => 'default',
                    'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Agenda'),
                    'after' => false,
                    'before' => false,
                ],
            ]) ?>

        </div>
        <div class="col-sm-6">
            <div class="bg-red info-box">
                <span class="info-box-icon"><i class="fa fa-tint"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text"><b>Contoh Uji</b></span>
                    <span class="info-box-number"><?= $dpUji->totalCount ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 100%"></div>
                    </div>
                    <span class="progress-description">
                        <?= Yii::t('app', 'Total Contoh Uji') ?>
                    </span>
                </div>
            </div>
            <?= GridView::widget([
                'dataProvider' => $dpUji,
                'pjax' => true,
                'summary' => '',
                'pjaxSettings' => ['neverTimeout' => true],
                'resizableColumns' => true,
                'resizeStorageKey' => Yii::$app->user->id . '-' . date("m"),
                'striped' => true,
                'condensed' => true,
                'responsive' => true,
                'responsiveWrap' => false,
                'showPageSummary' => false,
                'hover' => true,
                'columns' => [
                    ['class' => 'kartik\grid\SerialColumn'],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'KODE',
                    ],
                    [
                        'class' => '\kartik\grid\DataColumn',
                        'attribute' => 'ASAL_CONTOH_UJI',
                    ],
                ],
                'panel' => [
                    'type' => 'default',
                    'heading' => '<i class="glyphicon glyphicon-list"></i> ' . Yii::t('app', 'Daftar Contoh Uji'),
                    'after' => false,
                    'before' => false,
                ],
            ]) ?>
            
        </div>
    </div>
</div>
