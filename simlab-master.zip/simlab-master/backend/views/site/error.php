<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception \yii\web\NotFoundHttpException|\yii\web\ForbiddenHttpException */

$this->title = $name;

if (Yii::$app->user->isGuest) {
    $this->context->layout = 'blank';
}

$this->params['breadcrumbs'][] = $this->title;
$this->registerCss('.error-code{font-size: 150px;line-height:150px;margin:0 auto;border-bottom:1px solid #dddddd;}');

use yii\helpers\ArrayHelper;

?>
<div class="site-error text-center" style="margin: 50px 0">
    <div class="error-content">
        <table class="error-code text-yellow">
            <tr>
                <?php
                if ($status = ArrayHelper::getValue($exception, 'statusCode')) {
                    foreach ($status as $code) {
                        echo '<td>' . $code . '</td>';
                    }
                }
                ?>
            </tr>
        </table>
        <h2><i class="fa fa-warning text-yellow"></i> <?= $name ?></h2>
        <p class="lead"><?= $message ?></p>
    </div>
</div>
