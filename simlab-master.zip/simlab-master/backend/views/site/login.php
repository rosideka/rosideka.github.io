<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model common\models\forms\LoginForm */
/* @var $adminLte themes\adminlte\assets\ThemeAsset */
/* @var $umFront yii\web\UrlManager */

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;

$fieldOptionUsername = [
    'options' => ['class' => 'form-group has-feedback'],
    'inputTemplate' => "{input}<span class='glyphicon glyphicon-user form-control-feedback'></span>",
];

$fieldOptionPassword = [
    'options' => ['class' => 'form-group has-feedback'],
    'inputTemplate' => "{input}<span class='glyphicon glyphicon-lock form-control-feedback'></span>",
];

$umFront = Yii::$app->get('umFront');

$this->context->layout = 'blank';
$adminLte = $this->assetManager->getBundle('themes\adminlte\assets\ThemeAsset');
$adminLte->options = ['skin' => 'skin-green', 'class' => 'register-page'];

$this->title = Yii::t('app', 'Masuk');
?>
<div class="login-box">
    <div class="login-logo">
        <a href="<?= Url::to(['/'], true) ?>">SIMLAB <b>UNS</b></a>
    </div>
    <div class="login-box-body">
        <p class="login-box-msg"><?= Yii::t('app', 'Silakan isi kolom dibawah ini untuk masuk:') ?></p>

        <?php $form = ActiveForm::begin(['id' => 'login-form', 'enableClientValidation' => false]); ?>

        <?=
        $form->field($model, 'username', $fieldOptionUsername)
            ->textInput(['placeholder' => $model->getAttributeLabel('username')])
            ->label(false)
        ?>

        <?=
        $form->field($model, 'password', $fieldOptionPassword)
            ->passwordInput(['placeholder' => $model->getAttributeLabel('password')])
            ->label(false)
        ?>

        <div class="row">
            <div class="col-xs-8">
                <?= $form->field($model, 'rememberMe')->checkbox() ?>
            </div>
            <div class="col-xs-4">
                <?= Html::submitButton(
                    Yii::t('app', 'Masuk'),
                    ['class' => 'btn btn-primary btn-block btn-flat', 'name' => 'login-button']
                ) ?>

            </div>
        </div>
        <?php ActiveForm::end(); ?>

        <div class="social-auth-links text-center">
            <p style="text-transform: uppercase">- <?= Yii::t('app', 'Atau') ?> -</p>
            <a href="<?= $umFront->createUrl(['/sso/login']) ?>" class="btn btn-block btn-social btn-primary btn-flat">
                <i><?= Html::img('@appUrl/img/logo-uns-mini.png', ['style' => 'width:24px; margin-top: -8px']) ?></i>
                <?= Yii::t('app', 'Masuk menggunakan SSO') ?>
            </a>
        </div>
    </div>

    <br/>
    <?= Html::a(
        '<i class="fa fa-home"></i> ' . Yii::t(
            'app', 'Kembali {sitetitle}',
            ['sitetitle' => 'SIMLAB UNS']
        ),
        $umFront->createUrl(['/site/index']),
        ['class' => 'btn btn-block btn-success btn-flat']
    ) ?>

</div>
