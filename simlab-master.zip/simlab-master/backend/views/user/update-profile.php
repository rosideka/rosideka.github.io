<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Update Profile');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-update-profile">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= $this->title ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($model, 'USERNAME')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'EMAIL')->textInput(['maxlength' => true]) ?>

            <div class="form-group" style="margin-bottom: 0">
                <?= Html::submitButton(Yii::t('app', 'Update'), ['class' => 'btn btn-primary']) ?>

            </div>
            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
