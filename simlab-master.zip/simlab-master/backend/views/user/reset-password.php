<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Reset Password');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-update-password">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title"><?= $this->title; ?></h2>
        </div>
        <div class="box-body">
            <?php $form = ActiveForm::begin(); ?>

            <p><?= Yii::t('app', 'Silakan isi form berikut untuk me-reset password:') ?></p>
            <?= $form->field($model, 'passwordOld')->passwordInput([
                'maxlength' => true,
                'placeholder' => $model->getAttributeLabel('passwordOld'),
            ]) ?>

            <?= $form->field($model, 'password')->passwordInput([
                'maxlength' => true,
                'placeholder' => $model->getAttributeLabel('password'),
            ]) ?>

            <?= $form->field($model, 'passwordRepeat')->passwordInput([
                'maxlength' => true,
                'placeholder' => $model->getAttributeLabel('passwordRepeat'),
            ]) ?>

            <div class="form-group" style="margin-bottom: 0">
                <?= Html::submitButton(Yii::t('app', 'Reset Password'), ['class' => 'btn btn-primary']) ?>

            </div>
            <?php ActiveForm::end(); ?>

        </div>
    </div>
</div>
