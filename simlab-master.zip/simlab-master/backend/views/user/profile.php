<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = Yii::t('app', 'Profile Saya');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-profile">
    <div class="box box-primary box-solid">
        <div class="box-header">
            <h2 class="box-title" style="text-transform: uppercase"><?= $this->title; ?></h2>
        </div>
        <div class="box-body">
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'ID',
                        'captionOptions' => ['style' => 'width:33.333%'],
                    ],
                    'USERNAME',
                    'EMAIL:email',
                    [
                        'attribute' => 'STATUS',
                        'value' => $model->getStatusText(),
                    ],
                    [
                        'attribute' => 'CREATED_AT',
                        'format' => ['datetime', 'php:d F Y H:i:s'],
                    ],
                    [
                        'attribute' => 'UPDATED_AT',
                        'format' => ['datetime', 'php:d F Y H:i:s'],
                    ],
                ],
            ]) ?>

            <p style="margin-top: 15px">
                <b><?= Yii::t('app', 'PERHATIAN: Gunakan kode ini hanya jika dibutuhkan.') ?></b>
            </p>
            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    [
                        'attribute' => 'PASSWORD_RESET_TOKEN',
                        'captionOptions' => ['style' => 'width:33.333%'],
                    ],
                    'VERIFICATION_TOKEN',
                ],
            ]) ?>

        </div>
    </div>
</div>
