<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $content string */
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <?= Html::csrfMetaTags() ?>
    <title>SIMLAB UNS - <?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<?= $content; ?>
<?php $this->endBody() ?>
<script>
    let content = '<!DOCTYPE html><html>' + document.documentElement.innerHTML + '</html>';
    content = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(content);
    let fileDownload = document.createElement("a");
    document.body.appendChild(fileDownload);
    fileDownload.href = content;
    fileDownload.download = '<?= $this->title ?>.doc';
    fileDownload.click();
    document.body.removeChild(fileDownload);
</script>
</body>
</html>
<?php $this->endPage() ?>
