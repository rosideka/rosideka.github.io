<?php

use cebe\gravatar\Gravatar;
use themes\adminlte\widgets\Menu;
use yii\helpers\Html;

//use mdm\admin\components\MenuHelper;
//use yii\bootstrap\Nav;

/* @var $this yii\web\View */
/* @var $identity \common\models\User */

$user = Yii::$app->user;
$identity = $user->identity;
?>
<aside class="main-sidebar">
    <section class="sidebar">

        <?php if (!$user->isGuest): ?>
            <div class="user-panel">
                <div class="pull-left image">
                    <?= Gravatar::widget([
                        'email' => $identity->EMAIL,
                        'options' => [
                            'alt' => $identity->USERNAME,
                            'class' => 'img-circle',
                        ],
                        'size' => 45,
                    ]) ?>

                </div>
                <div class="pull-left info">
                    <p><?= $identity->USERNAME; ?></p>
                    <?= Html::a('<i class="fa fa-circle text-success"></i>' . 'Online', ['/user/profile']) ?>
                </div>
            </div>
        <?php endif ?>

        <?php
        $menu[] = [
            'icon' => 'home',
            'label' => Yii::t('app', 'Beranda'),
            'url' => ['/site/index'],
            'visible' => !Yii::$app->user->isGuest,
        ];

        $menu[] = [
            'icon' => 'th-large',
            'label' => Yii::t('app', 'Manage'),
            'items' => [
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Paket'),
                    'url' => ['/manage/paket/index'],
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Paket Parameter'),
                    'url' => ['/manage/paket-parameter/index'],
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Member'),
                    'url' => ['/manage/member/index'],
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Penanggung Jawab'),
                    'url' => ['/manage/member-pj/index'],
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Pegawai'),
                    'url' => ['/manage/pegawai/index'],
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'RBAC'),
                    'url' => ['/rbac/assignment/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_rbac'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'F.A.Q.'),
                    'url' => ['/manage/faq/index'],
                    // 'visible' => Yii::$app->user->can('simlab_perm_faqs'),
                ],
                /*
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'User'),
                    'url' => ['/manage/user/index'],
                ],
                */
            ],
            'visible' => Yii::$app->user->can('simlab_perm_manage'),
        ];

        $menu[] = [
            'icon' => 'tint',
            'label' => Yii::t('app', 'Uji'),
            'items' => [
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Agenda'),
                    'url' => ['/uji/agenda/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_agenda'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Penerimaan'),
                    'url' => ['/uji/penerimaan/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_penerimaan'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Label'),
                    'url' => ['/uji/label/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_penerimaan'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Serah Terima'),
                    'url' => ['/uji/serah-terima/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_disposisi'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Disposisi'),
                    'url' => ['/uji/disposisi/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_disposisi'),
                ],
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Pengujian'),
                    'url' => ['/uji/pengujian/index'],
                    'visible' => Yii::$app->user->can('simlab_perm_pengujian'),
                ],
            ],
        ];

        $menu[] = [
            'label' => Yii::t('app', 'Referensi'),
            'icon' => 'wrench',
            'url' => ['/ref/site/index'],
            'visible' => Yii::$app->user->can('simlab_perm_referensi'),
        ];


        if ($identity) {
            $menu[] = [
                'label' => Yii::t('app', 'Account'),
                'icon' => 'user',
                'items' => [
                    [
                        'icon' => 'circle-o',
                        'label' => Yii::t('app', 'Profile'),
                        'url' => ['/user/profile'],
                    ],
                    [
                        'icon' => 'circle-o',
                        'label' => Yii::t('app', 'Update'),
                        'url' => ['/user/update-profile'],
                    ],
                    [
                        'icon' => 'circle-o',
                        'label' => Yii::t('app', 'Password'),
                        'url' => ['/user/reset-password'],
                    ],
                ],
                'visible' => Yii::$app->user->can('simlab_perm_pegawai'),
            ];
        }

        $menu[] = [
            'label' => Yii::t('app', 'Log'),
            'icon' => 'cloud-download',
            'items' => [
                [
                    'icon' => 'circle-o',
                    'label' => Yii::t('app', 'Data'),
                    'url' => ['/log/data'],
                ],
            ],
            'visible' => Yii::$app->user->can('simlab_perm_logbook'),
        ];

        $menu[] = [
            'icon' => 'sign-in',
            'label' => Yii::t('app', 'Masuk'),
            'url' => ['/site/login'],
            'visible' => $user->isGuest,
        ];

        $menu[] = [
            'icon' => 'sign-out',
            'label' => Yii::t('app', 'Keluar'),
            'url' => ['/site/logout'],
            'linkOptions' => ['data-method' => 'post'],
            'visible' => !$user->isGuest,
        ];

        echo Menu::widget([
            'items' => $menu,
        ]);
        ?>
    </section>
</aside>
