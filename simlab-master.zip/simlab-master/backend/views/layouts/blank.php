<?php

use backend\assets\AppAsset;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $content string */
/* @var $adminLte themes\adminlte\assets\ThemeAsset */

AppAsset::register($this);
$adminLte = $this->assetManager->getBundle('themes\adminlte\assets\ThemeAsset');
$this->registerJs('$(".eq-height").matchHeight()');

// Favicon
$this->registerLinkTag([
    'rel' => 'icon',
    'href' => Yii::getAlias('@appUrl/img/favicon.ico'),
    'type' => 'image/x-icon',
]);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <?= Html::csrfMetaTags() ?>
    <title>SIMLAB UNS - <?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class="<?= $adminLte->getBodyClass() ?>">
<?php $this->beginBody() ?>
<?= $content; ?>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
