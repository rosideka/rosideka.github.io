<?php

use common\widgets\user\PanelWidget;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $identity \common\models\User */

$identity = Yii::$app->user->identity;
?>
<header class="main-header">
    <?= Html::a(
        Html::tag('span', '<b>UNS</b>', ['class' => 'logo-mini']) .
        Html::tag('span', '<b>SIMLAB</b> UNS', ['class' => 'logo-lg']), ['/site/index'], ['class' => 'logo']
    ); ?>

    <nav class="navbar navbar-static-top" role="navigation">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <?= PanelWidget::widget(); ?>
        </div>
    </nav>
</header>
