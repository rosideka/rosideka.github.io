<?php


/* @var $this yii\web\View */

?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">Versi 0.1.0</div>
    <strong>
        Copyright &copy; 2016 - <?= date('Y'); ?> <a href="https://infolab.uns.ac.id/simlab">SIMLAB UNS</a>.
    </strong>
    All rights reserved.
</footer>