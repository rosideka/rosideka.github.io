#!/usr/env bash

set -o errexit
set -o nounset
set -o pipefail

kubectl --kubeconfig kubectl.cfg apply -f deploy/k8s/service.yaml
kubectl --kubeconfig kubectl.cfg apply -f deploy/k8s/ingress.yaml
kubectl --kubeconfig kubectl.cfg apply -f deploy/k8s/autoscale.yaml
