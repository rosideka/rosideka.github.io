<?php
/**
 * @link https://simlab.uns.ac.id/
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace common\helpers;

use Yii;

class DateHelper
{
    public static function dbDatetime()
    {
        return Yii::$app->db->createCommand('SELECT to_char(NOW(), \'yyyy-mm-dd HH24:MI:SS\')')->queryScalar();
    }

    public static function dbDate()
    {
        return Yii::$app->db->createCommand('SELECT to_char(NOW(), \'yyyy-mm-dd\')')->queryScalar();
    }
}
