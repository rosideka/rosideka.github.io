<?php
return [
    'adminEmail' => 'uptlabterpadu@unit.uns.ac.id',
    'supportEmail' => 'uptlabterpadu@unit.uns.ac.id',
    'senderEmail' => 'uptlabterpadu@unit.uns.ac.id',
    'senderName' => 'uptlabterpadu@unit.uns.ac.id',
    'user.passwordResetTokenExpire' => 3600,
    'mdm.admin.configs' => [
        'advanced' => [
            'simlab-frontend' => [
                '@common/config/main.php',
                '@common/config/main-local.php',
                '@frontend/config/main.php',
                '@frontend/config/main-local.php',
            ],
            'simlab-backend' => [
                '@common/config/main.php',
                '@common/config/main-local.php',
                '@backend/config/main.php',
                '@backend/config/main-local.php',
            ],
        ],
    ],
];
