<?php
\Dotenv\Dotenv::createMutable(__DIR__ . '/../../')
    ->load();

Yii::setAlias('@common', dirname(__DIR__));
Yii::setAlias('@frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('@backend', dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('@console', dirname(dirname(__DIR__)) . '/console');
Yii::setAlias('@themes', dirname(dirname(__DIR__)) . '/themes');

Yii::setAlias('@appPath', getenv('APP_PATH') ?: dirname(dirname(__DIR__)) . '/public');
Yii::setAlias('@appUrl', getenv('APP_URL'));

Yii::setAlias('@assetPath', getenv('ASSET_PATH') ?: dirname(dirname(__DIR__)) . '/public/assets');
Yii::setAlias('@assetUrl', getenv('ASSET_URL') ?: getenv('APP_URL') . '/assets');
