<?php
return [
    'language' => 'id',
    'timeZone' => 'Asia/Jakarta',
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm' => '@vendor/npm-asset',
    ],
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'saml' => [
            'class' => 'asasmoyo\yii2saml\Saml',
            'configFileName' => '@frontend/config/sso.php',
        ],

        'user' => [
            'class' => 'yii\web\User',
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => '_identity-simlab', 'httpOnly' => true],
        ],

        'formatter' => [
            'class' => 'yii\i18n\Formatter',
            'currencyCode' => 'IDR',
        ],

        'umFront' => [
            'class' => 'yii\web\UrlManager',
            'baseUrl' => getenv('APP_URL') ?: null,
            'scriptUrl' => getenv('APP_URL') ? getenv('APP_URL') . '/index.php' : null,
            'showScriptName' => false,
            'enablePrettyUrl' => true,
            'rules' => [
                '<controller:\w+>/<id:\d+>' => '<controller>/view',
                '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
            ],
        ],

        'umBack' => [
            'class' => 'yii\web\UrlManager',
            'baseUrl' => getenv('APP_URL') . '/admin',
            'scriptUrl' => getenv('APP_URL') . '/admin/index.php',
            'showScriptName' => false,
            'enablePrettyUrl' => true,
            'rules' => [
                '<controller:\w+>/<id:\d+>' => '<controller>/view',
                '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
            ],
        ],

        'authManager' => [
            'class' => 'common\classes\DbManager',
            'itemTable' => 'APP_AUTH_ITEM',
            'itemChildTable' => 'APP_AUTH_ITEM_CHILD',
            'assignmentTable' => 'APP_AUTH_ASSIGNMENT',
            'ruleTable' => 'APP_AUTH_RULE',
        ],

        'assetManager' => [
            'class' => 'yii\web\AssetManager',
            'basePath' => '@assetPath',
            'baseUrl' => '@assetUrl',
            'linkAssets' => true,
            'hashCallback' => function ($path) {
                return hash('crc32', $path);
            },
            'bundles' => [
                'wbraganca\dynamicform\DynamicFormAsset' => [
                    'basePath' => '@appPath/js',
                    'baseUrl' => '@appUrl/js',
                ],
            ],
        ],
    ],
];
