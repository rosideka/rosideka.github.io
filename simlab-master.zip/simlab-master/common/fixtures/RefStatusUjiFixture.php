<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefStatusUji;
use yii\test\ActiveFixture;

class RefStatusUjiFixture extends ActiveFixture
{
    public $modelClass = RefStatusUji::class;
}
