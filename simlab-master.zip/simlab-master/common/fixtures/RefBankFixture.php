<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2021 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefBank;
use yii\test\ActiveFixture;

class RefBankFixture extends ActiveFixture
{
    public $modelClass = RefBank::class;
}
