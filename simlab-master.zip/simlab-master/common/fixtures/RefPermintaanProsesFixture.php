<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefPermintaanProses;
use yii\test\ActiveFixture;

class RefPermintaanProsesFixture extends ActiveFixture
{
    public $modelClass = RefPermintaanProses::class;
}
