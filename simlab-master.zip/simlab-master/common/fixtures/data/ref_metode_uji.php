<?php

return [
    'ref_metode_uji0' => [
        'NAMA_METODE' => 'Laborum necessitatibus et rem harum.',
        'CREATE_DATE' => '2015-03-17 12:35:50',
        'CREATE_BY' => 3,
        'CREATE_IP' => '212.85.233.222',
        'UPDATE_DATE' => '1977-04-14 08:07:09',
        'UPDATE_BY' => 3,
        'UPDATE_IP' => '232.6.167.205',
    ],
    'ref_metode_uji1' => [
        'NAMA_METODE' => 'Sapiente ut dolores velit at dolores qui ab.',
        'CREATE_DATE' => '1980-05-26 08:35:57',
        'CREATE_BY' => 1,
        'CREATE_IP' => '86.189.8.85',
        'UPDATE_DATE' => '2018-01-31 07:20:59',
        'UPDATE_BY' => 6,
        'UPDATE_IP' => '175.79.180.238',
    ],
    'ref_metode_uji2' => [
        'NAMA_METODE' => 'Beatae commodi voluptatem ut nihil quia facere.',
        'CREATE_DATE' => '1976-02-16 18:48:21',
        'CREATE_BY' => 8,
        'CREATE_IP' => '71.246.10.229',
        'UPDATE_DATE' => '1986-07-29 10:25:15',
        'UPDATE_BY' => 4,
        'UPDATE_IP' => '141.14.0.38',
    ],
    'ref_metode_uji3' => [
        'NAMA_METODE' => 'Autem neque sunt numquam totam nulla.',
        'CREATE_DATE' => '1983-03-21 10:58:27',
        'CREATE_BY' => 5,
        'CREATE_IP' => '49.138.161.135',
        'UPDATE_DATE' => '2014-08-21 10:55:32',
        'UPDATE_BY' => 6,
        'UPDATE_IP' => '149.39.202.99',
    ],
    'ref_metode_uji4' => [
        'NAMA_METODE' => 'Illum veritatis aperiam expedita est.',
        'CREATE_DATE' => '1992-09-20 10:17:26',
        'CREATE_BY' => 7,
        'CREATE_IP' => '74.217.212.185',
        'UPDATE_DATE' => '1993-03-27 13:38:30',
        'UPDATE_BY' => 6,
        'UPDATE_IP' => '60.99.70.247',
    ],
];
