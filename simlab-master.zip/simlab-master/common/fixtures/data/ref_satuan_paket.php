<?php

return [
    'ref_satuan_paket0' => [
        'SATUAN_PAKET' => 'Maiores aliquam doloremque aut sit laborum.',
        'CREATE_DATE' => '2001-05-05 13:32:32',
        'CREATE_BY' => 6,
        'CREATE_IP' => '250.246.244.134',
        'UPDATE_DATE' => '1978-05-13 01:36:51',
        'UPDATE_BY' => 4,
        'UPDATE_IP' => '147.67.147.235',
    ],
    'ref_satuan_paket1' => [
        'SATUAN_PAKET' => 'Sapiente voluptatem non porro ut.',
        'CREATE_DATE' => '2004-04-30 23:11:01',
        'CREATE_BY' => 5,
        'CREATE_IP' => '232.177.243.52',
        'UPDATE_DATE' => '1976-10-26 11:14:08',
        'UPDATE_BY' => 4,
        'UPDATE_IP' => '54.13.219.179',
    ],
    'ref_satuan_paket2' => [
        'SATUAN_PAKET' => 'Qui accusamus cupiditate officia quas aut.',
        'CREATE_DATE' => '1995-12-30 05:55:01',
        'CREATE_BY' => 9,
        'CREATE_IP' => '18.200.193.183',
        'UPDATE_DATE' => '1986-07-24 18:21:17',
        'UPDATE_BY' => 3,
        'UPDATE_IP' => '85.100.89.234',
    ],
    'ref_satuan_paket3' => [
        'SATUAN_PAKET' => 'Eum doloremque voluptatem laboriosam aut id unde.',
        'CREATE_DATE' => '1970-08-02 21:20:02',
        'CREATE_BY' => 7,
        'CREATE_IP' => '237.194.68.81',
        'UPDATE_DATE' => '2009-10-14 10:24:03',
        'UPDATE_BY' => 6,
        'UPDATE_IP' => '223.27.133.91',
    ],
    'ref_satuan_paket4' => [
        'SATUAN_PAKET' => 'Sint enim quis eum et.',
        'CREATE_DATE' => '2012-04-23 05:04:15',
        'CREATE_BY' => 5,
        'CREATE_IP' => '116.67.101.11',
        'UPDATE_DATE' => '1996-11-06 21:37:55',
        'UPDATE_BY' => 8,
        'UPDATE_IP' => '176.202.25.251',
    ],
];
