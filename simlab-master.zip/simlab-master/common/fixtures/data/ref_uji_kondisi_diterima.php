<?php

use yii\db\Expression;

return [
    'ref_uji_kondisi0' => [
        'KONDISI_TERIMA' => 'Dengan Pendingin',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi1' => [
        'KONDISI_TERIMA' => 'Tanpa Pendingin',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
];
