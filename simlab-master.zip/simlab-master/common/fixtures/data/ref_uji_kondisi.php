<?php

use yii\db\Expression;

return [
    'ref_uji_kondisi0' => [
        'KONDISI' => 'Jernih Ada Endapan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi1' => [
        'KONDISI' => 'Jernih Berwarna',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi2' => [
        'KONDISI' => 'Jernih Tidak Ada Endapan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi3' => [
        'KONDISI' => 'Keruh Ada Endapan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi4' => [
        'KONDISI' => 'Keruh Berwarna',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kondisi5' => [
        'KONDISI' => 'Keruh Tidak Ada Endapan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
];
