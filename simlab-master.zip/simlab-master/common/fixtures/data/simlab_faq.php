<?php

return [
    'simlab_faq0' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Cum excepturi aut enim nam. In laudantium velit et. Animi commodi iste mollitia aliquid.',
        'ANSWER' => 'Qui distinctio minima debitis alias harum laboriosam. Quia suscipit iste ut voluptatem et molestiae. Vel alias qui quaerat rerum dolorum. Eos quasi et dicta non.

Minima sed odio in alias sit corrupti dolor. Deleniti laborum alias nihil. Omnis ut et quia dolores.

Nulla voluptate esse aut. Perferendis blanditiis iusto ut sunt rerum. Doloribus architecto reiciendis dolorum officia qui in minima.

Temporibus dignissimos perspiciatis aut eius occaecati id. Aut est ea qui soluta. Necessitatibus sunt magni harum quaerat. Quis est sequi sit quos.

Rerum sapiente a tenetur facilis molestias culpa corporis eos. Autem accusamus repellat numquam autem excepturi rerum perspiciatis. Minus ratione a et quasi.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq1' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Eos nemo non autem quasi dolore et excepturi. Alias exercitationem modi placeat et magnam.',
        'ANSWER' => 'Hic sint officia rerum et iusto. A facilis quos delectus blanditiis corporis. Ut quas vero eligendi qui rerum accusantium debitis assumenda.

Vero earum et magnam pariatur tenetur soluta vitae. Deserunt qui dolor aut itaque. Repudiandae nihil est voluptatem occaecati sed fugiat dolores autem.

Quis voluptate est consequatur quia. In nesciunt soluta ex accusamus in et nisi.

Sit omnis porro velit minus laborum quaerat. Voluptas sit dolor ea aspernatur voluptate sunt enim. Minima aut facere a possimus. Praesentium voluptatibus sunt iusto praesentium unde vitae accusantium.

Cumque tempora error alias eum nihil omnis. Facere nulla quam enim sed est.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq2' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Et earum tenetur odit in error minus illo. Voluptatibus iste quam nobis ratione quis.',
        'ANSWER' => 'Voluptatem illo maxime nulla. Occaecati temporibus expedita quia blanditiis soluta corporis esse autem. Eos sit tempora mollitia exercitationem nobis est vero. Cupiditate et atque saepe odio qui. Quia autem est et eveniet sint ratione exercitationem ipsa.

Ut illum neque est. Doloribus nisi omnis quisquam perferendis excepturi commodi. Odit repellat quis quidem quo nostrum sapiente. Ratione est non voluptatem necessitatibus illo animi.

Sit ea fugiat esse vero ut ad et. Est iste cupiditate corporis et facilis. Earum sit ut quos quo. Cum sit et doloremque animi totam voluptates.

Et necessitatibus mollitia illo. Qui officia saepe accusamus nihil. Sunt harum perferendis beatae nesciunt voluptatem deserunt quisquam. Iure eaque aut sint hic.

Nihil id quam perferendis laudantium. Dolorem rerum molestiae porro vitae explicabo.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq3' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Nobis vel ut qui enim. Quidem quidem enim deleniti et aliquam.',
        'ANSWER' => 'Eum fugiat magni qui tenetur provident assumenda sint. Debitis perspiciatis ipsam modi et animi laborum nulla. Quia aut et quam voluptatibus officia eum. Aut aut velit unde.

Ipsum odio voluptatem laboriosam. Aliquid qui quis et perspiciatis velit voluptas. Reiciendis velit omnis aut. Dolores quas velit excepturi dignissimos ex fuga.

Voluptas sapiente rerum animi modi. Sequi explicabo qui aut deserunt laboriosam aliquam expedita incidunt. Deserunt repellendus dolorem et autem.

Error ad quis et at eaque quaerat ipsam velit. Non rerum aut earum unde est. Aliquam libero fugiat aut maxime corporis rerum. Omnis nemo cupiditate consequatur dolor unde quam labore.

Hic voluptates et consequatur. Recusandae dignissimos est earum ducimus nulla. Sed dolorem beatae dignissimos perspiciatis numquam sequi. Velit illo harum impedit voluptas amet.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq4' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Aut illum veritatis impedit qui ut vitae. Expedita quod voluptatem voluptatem aperiam.',
        'ANSWER' => 'Fugiat et pariatur mollitia doloremque quia. Quis quod non sunt cupiditate error officia. Ex et et perferendis et magnam numquam. Eum officiis repellendus reiciendis.

Odio optio est recusandae consequatur maiores. Sit hic sed nobis qui maiores deleniti iusto est. Molestias ad dolores est pariatur tenetur assumenda non. Consequuntur voluptatem tempore voluptatem nisi et quia enim minima.

Aut numquam non nisi nostrum quis numquam quam. Soluta quam animi tempora quo quas. Voluptatem ratione consequatur a. Cumque accusamus commodi repellat et quis omnis laboriosam et.

Voluptatem vel minima voluptas dolorem dignissimos. Quam molestiae autem ad est quo. Nesciunt vero suscipit omnis exercitationem. Molestias nihil rerum rerum fugit consequatur. Nihil unde sed minus mollitia unde sit.

Omnis illo id debitis debitis at minima possimus sed. Cumque doloribus repudiandae consectetur sapiente et eos omnis. Dolor voluptatum at perferendis sequi at sint fuga.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq5' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Officiis harum mollitia unde ipsum. Iusto quod sunt odio tempore omnis rem harum.',
        'ANSWER' => 'Non id inventore asperiores eum quasi. Deleniti temporibus iure necessitatibus quisquam velit impedit assumenda.

Minus vel voluptates commodi explicabo consequuntur laudantium. Consectetur dolores unde eveniet qui et numquam. Magnam repudiandae consequatur magni molestiae qui. Ut est itaque illo dolorem ea.

Ut dolores illum non iure alias laborum nisi. Rerum ducimus corrupti laborum porro. Ratione nostrum quo ut.

Unde dolorem natus earum quibusdam beatae et possimus. Magni quia dicta alias aut deserunt quia. Consectetur a est et rerum debitis ratione praesentium laboriosam. Officia repudiandae voluptatibus tenetur ut.

Facere libero ipsa aut quas. Hic ab odio voluptas rerum ab.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq6' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Aut voluptas similique qui. Rem in quos hic quos ullam. Porro et consequatur quia amet.',
        'ANSWER' => 'Odio minima voluptatum provident doloribus voluptas et est rem. Autem mollitia non sunt quos magnam. Qui iusto accusantium soluta quis hic rerum delectus sequi. Voluptatem deserunt sit quo sed est quos dolor.

Esse expedita non consequatur illum aut hic eum. Et eius non et dolores et sit.

Et qui quis voluptates enim quis quod. Voluptas dicta harum quia amet ut et quasi occaecati.

Ut velit sit et nesciunt maiores repellat ut. Rem ducimus odio commodi odit consequatur expedita corporis rem. Sed alias et vel quia ut quia.

Laboriosam ducimus vel commodi dolorum. Sapiente pariatur est animi inventore occaecati voluptatum ipsam sint. Eligendi similique voluptas laborum rerum totam adipisci aut. Sed qui consectetur rerum optio nisi voluptatibus.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq7' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Illum est ad fugiat amet. Tenetur enim nihil itaque. Et cum omnis architecto doloribus.',
        'ANSWER' => 'At aperiam quae quam officia qui. Unde blanditiis veritatis consequatur iusto fugit dolorem. Ea in nam qui soluta.

At saepe veniam sint molestias blanditiis. Sunt asperiores voluptatum consequatur aperiam nihil. Accusantium consectetur vero atque dolores. Quibusdam rerum impedit repellendus quod ut.

Eos soluta repellat est corrupti odit repellat. Quo omnis qui et dolor nesciunt. Facilis quis esse asperiores quia occaecati expedita et. Sit voluptatibus quo quia qui.

Nemo voluptas unde perspiciatis dicta rerum quia. Deserunt repellendus rerum explicabo molestias eos fugit impedit. Omnis officiis hic illum voluptas animi quaerat quos. Labore assumenda ducimus doloremque quo debitis praesentium odit.

Et et ratione totam laudantium illum. Qui tempora consequatur ut. Ut nemo ullam nesciunt tempore. Dolores laboriosam vero vitae enim corrupti.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq8' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Sit error et aut rerum. Asperiores veritatis id autem repellat distinctio hic natus.',
        'ANSWER' => 'Reiciendis qui in expedita natus est porro. Eos quae temporibus amet cum exercitationem mollitia. Sed odit asperiores qui vel consequuntur cum similique blanditiis.

Impedit omnis quae est nemo doloribus. Et enim commodi sit dolorem ut impedit. Dolorem nam et cupiditate impedit similique reiciendis quibusdam.

Accusamus numquam iusto quia fugiat omnis. Esse accusantium magnam ducimus blanditiis tempore.

Ad ut non nesciunt ut. Est enim nisi ullam rerum est. Sunt minus impedit nulla id doloremque rerum quis excepturi. Tenetur quos blanditiis necessitatibus sed eum adipisci. Ducimus ut dolor unde nam odit.

Aut voluptatem veniam sed qui ipsam dignissimos dignissimos. Vel aut ut ab. Sit in necessitatibus necessitatibus alias voluptatem qui id ullam. Aliquid deserunt delectus expedita iusto.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq9' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Ad at ipsum id est ex esse et. Velit sunt sit optio maiores ipsa.',
        'ANSWER' => 'Porro aut dolores corrupti molestiae. Est distinctio voluptatem praesentium eveniet sit totam. Architecto atque magni optio facilis corrupti doloremque.

Voluptatem eius aliquam sit rerum. Sed fugiat asperiores sed et sunt asperiores doloremque eum. Temporibus fugit totam enim eos a. Sed occaecati magni vel quisquam temporibus magni dolore quidem.

Vel veritatis sed aut vitae. Tenetur et sed et quo enim id. Id qui optio omnis et aut velit ex fugit.

Est vel modi soluta aut vitae rerum sed. Totam consequuntur dolores et debitis et dolores nulla. Impedit ratione iusto a natus molestias nisi voluptatibus.

Pariatur itaque exercitationem veritatis est quam odio et. Velit sunt omnis officia. Quaerat dolor laborum sunt repudiandae odit quia alias eveniet. Harum nihil consequatur cupiditate voluptatibus qui. Voluptate ducimus velit velit aut adipisci reiciendis ex.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq10' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Quidem eos non voluptatem quos et pariatur. Cum alias dolores autem eaque fuga officiis.',
        'ANSWER' => 'Cumque iusto odio in dolor. Neque ullam animi mollitia est voluptatem tempore. Neque ex quaerat sequi fuga culpa. At ut eum corporis placeat eaque hic accusantium.

Soluta perspiciatis ex unde doloribus pariatur eaque. Veritatis voluptatem ducimus omnis et perspiciatis. Facilis earum voluptatem non saepe.

In quod voluptate iure voluptate recusandae cupiditate vel. A iusto quisquam numquam laudantium. Velit dolorem nostrum odit nam.

Nulla enim et a. Aut et fugit deserunt. Molestias aut esse corporis similique fugiat ut. Et omnis est occaecati voluptatibus.

Vero voluptatem deleniti sapiente cum nostrum ut molestiae. Dolorem nisi nesciunt rerum vel. Blanditiis aut nobis harum hic et voluptatem. Quaerat sunt architecto atque inventore assumenda. Quod est et occaecati iure sit earum.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq11' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Porro vero praesentium officiis. Quibusdam sed porro harum eaque. Qui neque facere harum molestiae.',
        'ANSWER' => 'Repellendus id doloribus et aut. Fugiat vitae ab esse quis nemo qui. Nostrum placeat non ratione aliquid commodi facere.

Tenetur voluptatem provident voluptatibus itaque exercitationem magnam ex possimus. Modi unde dolores earum quaerat. Culpa consequatur unde ut qui dolorem reiciendis beatae.

Id quod nulla beatae quasi est velit. Officiis aperiam dolor reiciendis repellat culpa sed vero.

Qui temporibus ipsam velit magni repellat asperiores. Rerum molestias in quis voluptatem rerum consequatur fuga. Sit magnam illo minus eveniet.

Molestiae explicabo aut illo consequatur tenetur eos. Dolores quis sint quis similique iure quas velit. Dicta omnis ad in vitae vitae. Nulla architecto nihil consequatur iusto nulla vel aut.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq12' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Voluptatem quibusdam velit modi aut. Sint fugit iste quos illum. Enim quaerat possimus quos cumque.',
        'ANSWER' => 'Voluptatem aliquid iure earum ratione. Dolore voluptate perspiciatis nobis tenetur vel magni. Fuga ut aut fugiat dolorum id corporis voluptatem expedita.

Molestias ut maxime consectetur. Laborum ducimus soluta est vel qui placeat. Eos ad est dolor dolore.

Laudantium voluptatum illo nam cupiditate aut quaerat eos. Laudantium qui quam et dolore consectetur vel. Facere aut itaque qui et aut perspiciatis. Reprehenderit quia vitae qui.

Consequatur et at nesciunt. Unde cupiditate eum qui molestias sint. Deleniti ea rerum laboriosam.

Molestiae eius rerum rerum optio molestiae. Et aliquam a dicta eos sint rerum. Saepe repellat aspernatur qui autem neque sequi.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq13' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Maxime asperiores enim repudiandae laboriosam. Dicta nihil est sit architecto suscipit eaque.',
        'ANSWER' => 'Est officiis facilis eius saepe sunt atque est. Aut nesciunt ipsam fugit sit qui.

Ea impedit voluptatem corrupti eos ea quia. Ut necessitatibus aut nihil eum. Maxime corrupti debitis id placeat esse maiores reiciendis.

Quisquam amet repellendus est dolorem nulla rerum. Eligendi harum natus omnis sit.

Facilis ea eum saepe occaecati delectus quod. Iure ut aut necessitatibus nam natus quis. Dolores non veritatis odio ipsum.

Est deserunt iusto at porro voluptate vel. Voluptatibus veniam a illo aut impedit. Voluptas amet cumque aspernatur voluptas.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq14' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Repellat quos accusamus ut perferendis quia aut animi. Laborum ipsa blanditiis et nemo et.',
        'ANSWER' => 'Nihil dolorem veniam blanditiis cupiditate assumenda adipisci. Nobis in suscipit natus ad perspiciatis libero maiores.

In iste et rem. Esse quia rerum dignissimos eos illo. Esse quisquam dicta vel consequatur dolores sint itaque. At fuga voluptatem quo atque beatae assumenda accusantium omnis. Quis quia impedit reprehenderit sint rerum.

Sit dolores atque quod inventore sunt voluptatem. Inventore explicabo beatae et quidem qui. Optio aliquam qui neque beatae eaque alias.

Quis quasi et ab placeat qui provident autem rem. Nesciunt laborum praesentium incidunt quae enim ad. Voluptates officiis consectetur eos eligendi voluptatem quibusdam autem aut.

Temporibus amet earum et reiciendis ut excepturi qui. Voluptatem quasi dicta adipisci enim facere. Porro reiciendis qui id dolor asperiores.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq15' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Dolores ut aut eius. Adipisci corrupti cupiditate qui ea maxime inventore.',
        'ANSWER' => 'Dicta voluptas omnis necessitatibus nulla ut aut. Doloremque asperiores porro reiciendis est impedit corporis facere. Praesentium dolores maxime quis. Sed molestiae voluptas et quo consequatur esse aut. Nam provident repellendus quae modi neque doloribus non.

Aperiam et eum est nihil. Qui dolor ipsum qui enim. Animi quia rerum tempora dicta libero. Voluptatem a nulla aut magnam non.

Explicabo repellendus sed laboriosam. Minima aliquid sint reiciendis magnam delectus expedita. Illo dolorem fugiat non totam. Omnis est minus molestiae error eligendi et.

Dicta animi consequatur quaerat quae expedita doloremque. Et eum natus quisquam et delectus ut. Assumenda autem id repellat ratione est.

Eum qui aspernatur quis aliquid. Sequi officiis itaque porro veritatis. Voluptatem quod qui tempora cupiditate.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq16' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Est quasi sed officiis dolore. Quos porro blanditiis debitis quam vel quod.',
        'ANSWER' => 'Rerum dicta a pariatur consequatur. Aut beatae assumenda et ad. Consequatur et dolore aliquid repudiandae provident repellendus et. Sequi atque quae est.

Possimus autem hic illum et veniam. Quibusdam quos voluptatem sapiente hic nobis. Asperiores sed error alias explicabo non minima dolorem inventore.

Corporis cum nobis eum eos quibusdam. Tenetur illo eos mollitia natus. Et molestiae magnam neque. Quasi repudiandae impedit fugit ea voluptate.

Accusantium in sed aut ducimus est voluptas. Et saepe asperiores nobis est voluptatem. Et mollitia sequi nemo iste.

Tempora error doloribus aut illum quas temporibus. Voluptas rerum possimus amet voluptates quos et in ad. Facere dolor voluptas cumque maxime. Incidunt recusandae pariatur mollitia ipsum repellendus sed pariatur at.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq17' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Aliquid voluptatem fuga ut rerum et mollitia. Est est quo culpa. Ducimus eos odit fuga.',
        'ANSWER' => 'Odit ea aspernatur voluptas itaque nemo. Nam cupiditate sit rerum dolorum. Tempore et fugiat sunt sunt qui nihil. Sint autem architecto dignissimos omnis. Distinctio beatae qui ut odio.

Repudiandae sed cupiditate non laudantium beatae nihil quia. Consequuntur adipisci iure maxime nihil quia asperiores quidem. Ea sed aut et dolor magni et.

Dolorum illum eos fugit et. Similique non accusamus nemo doloribus deserunt quasi cum. Laborum quia omnis dolor quia nesciunt maiores. Iste ut temporibus perferendis quia. In temporibus placeat nisi eligendi sed placeat.

Consectetur est provident tempora amet sed. Totam rem et excepturi iste occaecati veritatis. Sint et iste dolorem quia maiores ratione est. Quam ut voluptatem ex nobis neque.

Autem et qui fuga et neque ut eos pariatur. Corporis consequatur quis ea adipisci enim molestiae libero possimus. Et vitae tempora aut non nihil ut sit.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq18' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Rerum est voluptatem laboriosam sit veritatis pariatur. Ut minima itaque quo qui et magni dolores.',
        'ANSWER' => 'Et quaerat odio temporibus exercitationem. Nihil ut deleniti explicabo et. Voluptatum dolores autem eveniet quis voluptatem. Ratione in et doloremque nesciunt.

Culpa quaerat soluta veniam ipsa est consequuntur mollitia. Voluptatibus dicta facilis maiores dolore possimus. Officia et atque omnis nobis. Natus aut possimus et et sed velit.

Praesentium sit in dolores placeat inventore facere voluptatem quo. Necessitatibus rerum soluta et ducimus minus accusamus ducimus. Voluptate eum sapiente consequuntur eum. Consequatur deleniti vero et ipsum ducimus.

Ipsum sit ut rerum. Ut ea et aut necessitatibus eaque dolorum. Rerum eum ipsam ut qui hic doloribus. Id aliquam natus velit consequuntur.

Praesentium est quas velit qui provident deserunt dolorem. Aliquid quis accusantium suscipit beatae dolores cumque voluptatem. Nisi corrupti repellat inventore cupiditate.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq19' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Nostrum sunt est aperiam ut occaecati eaque. Explicabo et in animi error voluptatem.',
        'ANSWER' => 'Et ratione repellat sequi. Ullam rerum ea ullam rem odit nostrum est. Quisquam inventore aut earum earum earum. Quibusdam minima nemo aut magnam.

Doloribus perspiciatis consequatur aliquam nam autem tempora. Consequatur molestiae ipsa consectetur ut. Et eligendi non velit omnis inventore ut.

Quo mollitia blanditiis qui. Harum recusandae ut ex. Pariatur veritatis porro tempora velit ut nihil. Assumenda aut ut nihil nulla fugit voluptas.

Quas accusantium quis aut aliquid vel. Alias exercitationem nihil quos eos dolor excepturi assumenda autem. Sed necessitatibus non quisquam quod voluptatum provident consequatur. Dolores corporis dolor quia nulla et officia quis.

Distinctio placeat eos velit. Quis aliquam assumenda enim. Quos dolorem officia totam. Cupiditate culpa et quos ut debitis cupiditate.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq20' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Possimus vel reiciendis eum. Et omnis quo aperiam. Ut sed rem voluptatem nesciunt quisquam sed.',
        'ANSWER' => 'Quia dolorum quis ipsam cumque facilis perferendis. Magnam ducimus ratione excepturi atque sit vel. Voluptatem id eum qui magni. Distinctio et incidunt corporis harum a harum cupiditate autem.

Laborum in cupiditate et suscipit quae veniam ea. Id optio tenetur illo adipisci repellat architecto.

Modi culpa tenetur earum libero ex est quia. Ipsum nobis voluptates adipisci alias. Doloribus ex non aut id sequi.

Provident similique iste sunt vel perferendis. Quam et suscipit quae aut. Optio error libero adipisci doloribus.

Velit qui eum esse ut magnam consequatur veniam numquam. Cum laborum iure velit voluptate impedit amet accusantium. Quo et velit aut officia aut qui.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq21' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Ratione doloremque ut asperiores at fugiat. Natus qui doloribus doloremque ducimus nulla.',
        'ANSWER' => 'Quaerat voluptas expedita error dolor. Vitae voluptatibus nostrum minus modi illo commodi.

Magni animi ut eos libero fuga est distinctio at. Voluptas et consequatur et aut qui ullam vel. Laborum doloribus tenetur facere laborum ea.

Et id ut sed expedita. Reiciendis ducimus nulla velit dicta neque aut. Quo voluptas nisi aperiam provident qui dolorem.

Velit perferendis eligendi ex vel. Dolores aperiam aliquid incidunt.

Quidem ut excepturi nihil est eveniet ex distinctio vel. Molestiae non est non ducimus. Fuga voluptates aut vero dicta.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq22' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Et et impedit sint ut magni. Eligendi dolor sunt velit. Maiores hic dolor quo aperiam aut quia.',
        'ANSWER' => 'Accusantium cum laborum ipsam doloremque. Iure autem corporis itaque est cupiditate ut.

Voluptates nostrum quae ut accusantium fugit totam. Numquam tempora magnam quia qui voluptatem sint expedita sed. Fugiat rerum et alias porro magnam.

Delectus aspernatur accusamus aut sint. Dolor et asperiores voluptatem aliquam omnis delectus ut. Quia nostrum itaque quae pariatur. Qui mollitia nisi quibusdam. Nihil dolores aut placeat vel temporibus ea amet.

Rem nemo dolor earum. Praesentium et voluptate consequatur nisi rerum temporibus. Dolores dignissimos omnis odit voluptatum.

Recusandae facere sunt dolor nesciunt exercitationem accusantium provident. Tenetur reiciendis consequatur ducimus qui. Ut vel non ea voluptas odit quo corrupti. Accusamus aliquam iusto dolores voluptatibus voluptas omnis eum.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq23' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Quia harum fugiat illum consequuntur rerum nemo repellat. Suscipit id sunt rerum aut ex.',
        'ANSWER' => 'Harum harum voluptatum vel amet mollitia ipsum. Est libero praesentium molestiae eum perspiciatis exercitationem totam. Consequatur qui hic ea aliquam quaerat voluptatem expedita. Voluptate repellendus qui et aut id.

Consectetur blanditiis sed sint qui quis voluptas expedita. Magnam voluptatem non et suscipit. Quisquam aliquid rerum ut qui vero neque.

Odio magnam modi sit reprehenderit ut necessitatibus. Blanditiis cumque optio ut mollitia exercitationem. Vero ab corrupti voluptatem reiciendis facilis delectus illum. Voluptatem aut iste fugit vel molestias nesciunt.

Non officia eius sed quia aliquam. Molestiae vero et quo tempora cupiditate. Neque molestias dolorem quia dolorem. Et cupiditate corporis tempora itaque.

Rerum et libero illo quas. Tempora voluptatem dolores optio architecto dignissimos beatae. In voluptatem occaecati laboriosam quia.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq24' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Similique alias suscipit autem autem tenetur qui reiciendis. Sunt in neque sint ab.',
        'ANSWER' => 'A repellendus quo et. Quasi ex voluptas ipsa eaque omnis aut et vitae. Quia ullam occaecati eligendi repudiandae quis aliquam.

Ullam provident nobis dolor. Suscipit pariatur odio qui impedit quisquam in. Aperiam quaerat expedita magnam nam id. Voluptas enim consequuntur quos doloribus et.

Autem et illum ab qui non est nihil. Placeat autem alias vitae et eius. Quo non qui harum nostrum possimus adipisci.

Enim totam qui ut. Veniam autem hic accusantium aut. Vitae tempora nam corrupti vel.

Rerum nihil et in aut fuga dolores. Ab provident et magni iure doloremque. Ea iusto assumenda deserunt ea rerum veritatis accusamus.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq25' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Vel sed rem rerum rem. In qui quis molestiae quae iste quo quae dolor.',
        'ANSWER' => 'Et quia magnam maxime impedit dolor. Quas non harum deleniti et dolore possimus est itaque. Reiciendis dolorem exercitationem earum necessitatibus nemo sequi.

Et magni ullam qui ducimus accusamus suscipit quam nobis. Nisi officiis tenetur qui eos mollitia. Et et quia maxime itaque fugiat in aut odit. Harum reiciendis quis nobis sit et ipsum.

Consequatur fuga quod quia aut est soluta voluptas. Natus ea praesentium nam molestias occaecati reprehenderit sit. Dolorem quia sit nisi ut. Id voluptatem ullam laudantium fugit distinctio sint qui. Dignissimos amet ut eos temporibus nemo ut.

Suscipit perferendis sit sunt ab non unde est. Voluptatem occaecati ducimus molestias odit tempore accusamus. Consequatur voluptas ipsa sint et rerum. Velit eveniet sed quaerat sed ab voluptate est.

Saepe aut eos nobis voluptatem aliquid. Dolor sed quasi et sed. Iure perspiciatis omnis vitae consequatur. Dolorem quibusdam quia sed. Molestias similique placeat iste modi illum.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq26' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Sed ipsum quis expedita voluptatem qui. Unde dolor officia officiis mollitia itaque ab.',
        'ANSWER' => 'Est explicabo ratione vitae nihil mollitia. Quis quam ex quae quis esse totam porro. Molestiae voluptate in odit commodi.

Vero repudiandae fuga non id cupiditate. Corrupti labore ut cum quae ipsa recusandae. Voluptas in consequuntur quo adipisci dolorem. Expedita velit maxime laudantium vero beatae.

Reprehenderit maxime quidem alias corporis est dolorum. Quo magni qui dolore nihil dolor praesentium ut. Quam nisi officiis consequuntur voluptas. Et consequatur id temporibus corrupti et tempore cupiditate. Exercitationem aut officia perferendis similique temporibus adipisci quas aliquam.

Aut maiores ut iusto neque voluptas possimus. Quis et aut rerum. Quasi eum et nulla at autem provident.

Similique ut accusamus doloribus. Sed distinctio minima et unde natus repellat ea. Ad modi deleniti quis. Ipsum non expedita sed eveniet blanditiis dicta.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq27' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Odit minima enim possimus et. Et et ducimus qui et commodi non officia magnam.',
        'ANSWER' => 'Dicta voluptate vel provident earum id. Odit repellat animi inventore atque nisi vel aliquam. Minima veniam rerum voluptate et quasi quam aut. Dolore iure sed accusamus minus voluptatem.

Magni vel quia occaecati architecto veniam blanditiis quaerat deleniti. Et sequi rerum possimus dolor. Dolores rerum impedit ipsum. Porro consequuntur reiciendis ut assumenda qui.

Possimus consequatur fugiat saepe et esse autem. Officia libero consequatur totam similique eos quaerat. Molestias explicabo expedita tenetur id. Nihil aut ad voluptates.

Molestias harum nemo dolores iusto tenetur odio. Consequatur quod aut iusto voluptas placeat quos libero. Est eos aliquid voluptatem animi sunt.

Neque veniam odit qui mollitia voluptas sit. Velit provident blanditiis enim sunt. Voluptas dolorem eius quam aut alias ex et. Aut voluptas distinctio sed harum cumque molestiae.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq28' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Eveniet voluptatibus autem enim fugiat architecto nam. Voluptates a aut facilis cumque.',
        'ANSWER' => 'Assumenda ut nihil omnis. Dolor et accusamus quaerat libero. Officia veritatis cumque et repellat blanditiis.

Et velit inventore voluptas sint aliquid velit reiciendis. Earum ut nisi animi et beatae est odit. Voluptate dicta itaque in aliquid est.

Saepe commodi voluptas qui corporis. Culpa velit optio numquam molestiae.

Molestiae sapiente reprehenderit incidunt voluptatibus voluptas. Similique odio deleniti aliquam nostrum ex optio velit.

Animi repellendus dolore quas et. Explicabo qui est in expedita sed sint. Dignissimos sint praesentium qui.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'simlab_faq29' => [
        'ID_LAYANAN' => 1,
        'ID_SUB_LAYANAN' => 1,
        'QUESTION' => 'Nostrum dolores voluptatem officia distinctio modi ad. Labore molestiae sit est.',
        'ANSWER' => 'Omnis molestiae possimus qui minus facere et. Nesciunt omnis ut asperiores ratione. Accusamus nam nihil quibusdam ullam qui qui. A doloremque amet velit voluptatem quis blanditiis saepe.

Et nam dolor quisquam voluptatum. Ea facilis quaerat officia est sint dolores. Quis voluptatem cum sequi magnam.

Ratione aliquam dolorem et qui nesciunt. Est eligendi praesentium dolorem inventore aperiam. Explicabo quia ut illum architecto rerum eos fuga.

Animi et quasi qui reprehenderit asperiores laborum mollitia. Culpa rerum sit sunt eos. Rerum repellat qui maxime esse ut. Animi et recusandae velit inventore minima sit enim.

Sunt dolores ea est ullam esse. Dolorem qui consectetur ut sed dolores. Maxime voluptatibus veritatis dolorem deserunt quibusdam eveniet. Aliquam tempore praesentium quia repudiandae est blanditiis quisquam sequi. Recusandae provident quia modi perspiciatis.',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
];
