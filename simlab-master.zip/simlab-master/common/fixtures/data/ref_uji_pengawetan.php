<?php

use yii\db\Expression;

return [
    'ref_uji_pengawetan0' => [
        'PENGAWETAN' => 'Diawetkan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_pengawetan1' => [
        'PENGAWETAN' => 'Tidak Diawetkan',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
];
