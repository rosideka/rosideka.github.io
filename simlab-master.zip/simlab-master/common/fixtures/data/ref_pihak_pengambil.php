<?php

return [
    'ref_pihak_pengambil0' => [
        'KODE' => 'LP1',
        'PIHAK_PENGAMBIL' => 'Pelanggan',
        'CREATE_DATE' => '2020-11-24 12:21:00',
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => '2020-11-24 12:21:00',
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_pihak_pengambil' => [
        'KODE' => 'LP2',
        'PIHAK_PENGAMBIL' => 'UPT Laboratorium Terpadu UNS',
        'CREATE_DATE' => '2020-11-24 12:21:00',
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => '2020-11-24 12:21:00',
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
];
