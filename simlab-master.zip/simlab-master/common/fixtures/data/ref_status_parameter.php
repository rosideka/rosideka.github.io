<?php

return [
    'ref_status_parameter0' => [
        'STATUS_PARAMETER' => 'Pengajuan',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.01',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.01',
    ],
    'ref_status_parameter1' => [
        'STATUS_PARAMETER' => 'Penerimaan',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.01',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.01',
    ],
    'ref_status_parameter2' => [
        'STATUS_PARAMETER' => 'Disposisi',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.01',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.01',
    ],
    'ref_status_parameter3' => [
        'STATUS_PARAMETER' => 'Proses Analisis',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.01',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.01',
    ],
    'ref_status_parameter4' => [
        'STATUS_PARAMETER' => 'Selesai Analisis',
        'CREATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.01',
        'UPDATE_DATE' => unserialize('O:17:"yii\\db\\Expression":2:{s:10:"expression";s:5:"NOW()";s:6:"params";a:0:{}}'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.01',
    ],
];
