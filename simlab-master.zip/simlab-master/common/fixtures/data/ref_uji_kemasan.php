<?php

use yii\db\Expression;

return [
    'ref_uji_kemasan0' => [
        'KEMASAN' => 'Botol Plastik',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kemasan1' => [
        'KEMASAN' => 'Botol Kaca',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
    'ref_uji_kemasan2' => [
        'KEMASAN' => 'Jeriken',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '127.0.0.1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '127.0.0.1',
    ],
];
