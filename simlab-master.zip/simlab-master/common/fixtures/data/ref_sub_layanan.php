<?php

use yii\db\Expression;

return [
    'ref_layanan0' => [
        'ID' => 1,
        'ID_LAYANAN' => 1,
        'NAMA' => 'Pengujian',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'ref_layanan1' => [
        'ID' => 2,
        'ID_LAYANAN' => 2,
        'NAMA' => 'Kalibrasi',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
];
