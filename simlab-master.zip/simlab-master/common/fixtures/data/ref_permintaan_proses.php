<?php

use yii\db\Expression;

return [
    'ref_permintaan_proses0' => [
        'ID' => 1,
        'PERMINTAAN_PROSES' => 'Reguler',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
    'ref_permintaan_proses1' => [
        'ID' => 2,
        'PERMINTAAN_PROSES' => 'Segera',
        'CREATE_DATE' => new Expression('NOW()'),
        'CREATE_BY' => 1,
        'CREATE_IP' => '::1',
        'UPDATE_DATE' => new Expression('NOW()'),
        'UPDATE_BY' => 1,
        'UPDATE_IP' => '::1',
    ],
];
