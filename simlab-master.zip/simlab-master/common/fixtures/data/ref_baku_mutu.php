<?php

return [
    'ref_baku_mutu0' => [
        'NAMA_BAKU_MUTU' => 'Vel iusto non ratione recusandae dolorem.',
        'CREATE_DATE' => '1994-09-18 12:00:03',
        'CREATE_BY' => 3,
        'CREATE_IP' => '76.74.85.194',
        'UPDATE_DATE' => '1996-03-29 04:27:38',
        'UPDATE_BY' => 8,
        'UPDATE_IP' => '244.236.8.108',
    ],
    'ref_baku_mutu1' => [
        'NAMA_BAKU_MUTU' => 'Minima blanditiis aut praesentium ratione.',
        'CREATE_DATE' => '1997-12-14 12:25:41',
        'CREATE_BY' => 1,
        'CREATE_IP' => '212.3.169.20',
        'UPDATE_DATE' => '1994-01-30 02:33:36',
        'UPDATE_BY' => 2,
        'UPDATE_IP' => '175.180.207.0',
    ],
    'ref_baku_mutu2' => [
        'NAMA_BAKU_MUTU' => 'Sunt et omnis voluptatem optio nihil sed et eos.',
        'CREATE_DATE' => '1976-07-09 08:26:32',
        'CREATE_BY' => 4,
        'CREATE_IP' => '80.217.171.95',
        'UPDATE_DATE' => '2003-01-03 20:51:14',
        'UPDATE_BY' => 5,
        'UPDATE_IP' => '43.121.59.24',
    ],
    'ref_baku_mutu3' => [
        'NAMA_BAKU_MUTU' => 'Dolorem omnis et non culpa enim iusto.',
        'CREATE_DATE' => '2001-06-20 05:57:58',
        'CREATE_BY' => 7,
        'CREATE_IP' => '121.50.116.150',
        'UPDATE_DATE' => '1995-05-08 04:15:32',
        'UPDATE_BY' => 5,
        'UPDATE_IP' => '200.201.99.45',
    ],
    'ref_baku_mutu4' => [
        'NAMA_BAKU_MUTU' => 'Asperiores error dicta dignissimos et.',
        'CREATE_DATE' => '1996-09-05 13:47:09',
        'CREATE_BY' => 2,
        'CREATE_IP' => '92.140.157.52',
        'UPDATE_DATE' => '2007-09-13 10:25:08',
        'UPDATE_BY' => 6,
        'UPDATE_IP' => '1.52.32.186',
    ],
];
