<?php

return [
    'user0' => [
        'USERNAME' => 'tschoen',
        'AUTH_KEY' => '48Jl0URcuOuV_KGheD-Zj4OUXt-M0L6D',
        'PASSWORD_HASH' => '$2y$13$mTc1I/uqj54xYmRcHg3.Q.40Q8kol0b/gaLfS6wT9bwerZdTVznZ2',
        'PASSWORD_RESET_TOKEN' => 'Q8GPuMOItcOC3VqIqwZmVP5QkyRELMdz',
        'VERIFICATION_TOKEN' => 'quePq6IrQ-kvIOuJ-JtjKEQhJn0GDU3x',
        'EMAIL' => 'ondricka.audra@konopelski.com',
        'STATUS' => 10,
        'CREATED_AT' => unserialize('O:8:"DateTime":3:{s:4:"date";s:26:"2016-09-13 02:49:13.000000";s:13:"timezone_type";i:3;s:8:"timezone";s:12:"Asia/Jakarta";}'),
        'UPDATED_AT' => unserialize('O:8:"DateTime":3:{s:4:"date";s:26:"1977-08-06 02:02:14.000000";s:13:"timezone_type";i:3;s:8:"timezone";s:12:"Asia/Jakarta";}'),
    ],
    'user1' => [
        'USERNAME' => 'jhettinger',
        'AUTH_KEY' => 'Gq_5-yecvU5hmNQOe1w-GV4AfUYqK5e_',
        'PASSWORD_HASH' => '$2y$13$KNn236zgCfe6L.Nu5MLRcO4FWJ3yi20lljzgO31lL3ApLbzrO/FxK',
        'PASSWORD_RESET_TOKEN' => 'XaVoiKaUfADdIZ1o-fIUT72g0rLUF6R0',
        'VERIFICATION_TOKEN' => '8HzbsJTnWuHDk0tucCYk5avRoU4P4aJ9',
        'EMAIL' => 'marian57@lehner.com',
        'STATUS' => 10,
        'CREATED_AT' => unserialize('O:8:"DateTime":3:{s:4:"date";s:26:"1984-03-20 13:24:39.000000";s:13:"timezone_type";i:3;s:8:"timezone";s:12:"Asia/Jakarta";}'),
        'UPDATED_AT' => unserialize('O:8:"DateTime":3:{s:4:"date";s:26:"1996-10-02 19:59:38.000000";s:13:"timezone_type";i:3;s:8:"timezone";s:12:"Asia/Jakarta";}'),
    ],
];
