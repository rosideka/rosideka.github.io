<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefBakuMutu;
use yii\test\ActiveFixture;

class RefBakuMutuFixture extends ActiveFixture
{
    public $modelClass = RefBakuMutu::class;
}
