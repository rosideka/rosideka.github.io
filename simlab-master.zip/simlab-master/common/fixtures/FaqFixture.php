<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\simlab\Faq;
use yii\test\ActiveFixture;

class FaqFixture extends ActiveFixture
{
    public $modelClass = Faq::class;
}
