<?php
namespace common\fixtures;

use common\models\User;
use yii\test\ActiveFixture;

class AppUserFixture extends ActiveFixture
{
    public $modelClass = User::class;
}
