<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefSubLayanan;
use yii\test\ActiveFixture;

class RefSubLayananFixture extends ActiveFixture
{
    public $modelClass = RefSubLayanan::class;

    public $depends = [RefLayananFixture::class];
}
