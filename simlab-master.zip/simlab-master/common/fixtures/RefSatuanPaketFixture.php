<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2019 UPT TIK UNS
 */

namespace common\fixtures;

use common\models\refs\RefSatuanPaket;
use yii\test\ActiveFixture;

class RefSatuanPaketFixture extends ActiveFixture
{
    public $modelClass = RefSatuanPaket::class;
}
