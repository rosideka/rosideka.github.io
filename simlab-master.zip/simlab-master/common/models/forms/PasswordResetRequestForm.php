<?php
namespace common\models\forms;

use common\models\User;
use Yii;
use yii\base\Model;

/**
 * Password reset request form
 */
class PasswordResetRequestForm extends Model
{
    public $email;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            ['email', 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'exist',
                'targetClass' => '\common\models\User',
                'targetAttribute' => 'EMAIL',
                'filter' => ['STATUS' => User::STATUS_ACTIVE],
                'message' => 'There is no user with this email address.',
            ],
        ];
    }

    /**
     * Sends an email with a link, for resetting the password.
     *
     * @return bool whether the email was send
     */
    public function sendEmail()
    {
        /* @var $user User */
        /* @var $mailer \yii\swiftmailer\Mailer */

        $user = User::findOne([
            'STATUS' => User::STATUS_ACTIVE,
            'EMAIL' => $this->email,
        ]);

        if (!$user) {
            return false;
        }

        if (!User::isPasswordResetTokenValid($user->PASSWORD_RESET_TOKEN)) {
            $user->generatePasswordResetToken();
            if (!$user->save()) {
                return false;
            }
        }

        $mailer = Yii::$app->mailer;
        $mailer->htmlLayout = '@common/mail/layouts/html';
        $mailer->textLayout = '@common/mail/layouts/text';

        return $mailer
            ->compose(
                ['html' => '@common/mail/passwordResetToken-html', 'text' => '@common/mail/passwordResetToken-text'],
                ['user' => $user]
            )
            ->setFrom([Yii::$app->params['supportEmail'] => 'SIMLAB Noreply'])
            ->setTo($this->email)
            ->setSubject('Reset Password SIMLAB UPT Lab Terpadu UNS')
            ->send();
    }
}
