<?php

namespace common\models;

use common\classes\LogBehavior;
use common\models\simlab\Member;
use common\models\simlab\Pegawai;
use Yii;
use yii\base\NotSupportedException;
use yii\db\ActiveRecord;
use yii\db\Expression;
use yii\web\IdentityInterface;

/**
 * This is the model class for table "APP_USER".
 *
 * @property int $ID
 * @property string $USERNAME
 * @property string $PASSWORD_HASH
 * @property string|null $PASSWORD_RESET_TOKEN
 * @property string|null $VERIFICATION_TOKEN
 * @property string $EMAIL
 * @property string $AUTH_KEY
 * @property int $STATUS
 * @property string $CREATED_AT
 * @property string $UPDATED_AT
 * @property string $PASSWORD write-only password
 *
 * @property Member $idMember
 * @property Pegawai $idPegawai
 */
class User extends ActiveRecord implements IdentityInterface
{
    const STATUS_DELETED = 0;

    const STATUS_INACTIVE = 9;

    const STATUS_ACTIVE = 10;

    public $password;

    public $passwordOld;

    public $passwordRepeat;

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'APP_USER';
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios['sso'] = array_diff($scenarios['default'], ['PASSWORD_HASH']);
        return $scenarios;
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['USERNAME', 'AUTH_KEY', 'EMAIL'], 'required'],
            [['USERNAME', 'EMAIL'], 'trim'],
            [['EMAIL'], 'email'],
            [['STATUS'], 'integer'],
            [['CREATED_AT', 'UPDATED_AT'], 'safe'],
            [['PASSWORD_HASH', 'PASSWORD_RESET_TOKEN', 'EMAIL', 'VERIFICATION_TOKEN'], 'string', 'max' => 255],
            [['USERNAME'], 'string', 'min' => 3, 'max' => 255],
            [['AUTH_KEY'], 'string', 'max' => 32],
            [['USERNAME'], 'unique'],
            [['EMAIL'], 'unique'],
            [['PASSWORD_RESET_TOKEN'], 'unique'],
            [['password', 'passwordOld', 'passwordRepeat'], 'required', 'on' => 'resetPassword'],
            [['password', 'passwordRepeat'], 'required', 'on' => 'register'],
            [['password'], 'string', 'min' => 6],
            [['passwordOld'], 'passwordValidation'],
            [['passwordRepeat'], 'compare', 'compareAttribute' => 'password'],
            [
                ['USERNAME'],
                'match',
                'pattern' => '/^[a-z0-9@_.\-]+$/i',
                'message' => Yii::t(
                    'app',
                    'Nama pengguna hanya dapat berisi karakter alfanumerik [a-z0-9], garis bawah [_], garis [-], dan titik [.], at [@]'
                ),
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'USERNAME' => Yii::t('app', 'Username'),
            'AUTH_KEY' => Yii::t('app', 'Auth Key'),
            'PASSWORD_HASH' => Yii::t('app', 'Password Hash'),
            'PASSWORD_RESET_TOKEN' => Yii::t('app', 'Password Reset Token'),
            'EMAIL' => Yii::t('app', 'Email'),
            'STATUS' => Yii::t('app', 'Status'),
            'CREATED_AT' => Yii::t('app', 'Dibuat'),
            'UPDATED_AT' => Yii::t('app', 'Diupdate'),
            'VERIFICATION_TOKEN' => Yii::t('app', 'Verification Token'),
            'password' => Yii::t('app', 'Password'),
            'passwordOld' => Yii::t('app', 'Password Lama'),
            'passwordRepeat' => Yii::t('app', 'Ulangi Password'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdMember()
    {
        return $this->hasOne(Member::class, ['ID_USER' => 'ID']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPegawai()
    {
        return $this->hasOne(Pegawai::class, ['ID_USER' => 'ID']);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        return static::findOne(['ID' => $id, 'STATUS' => self::STATUS_ACTIVE]);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return static::findOne(['USERNAME' => $username, 'STATUS' => self::STATUS_ACTIVE]);
    }

    /**
     * Finds user by password reset token
     *
     * @param string $token password reset token
     * @return static|null
     */
    public static function findByPasswordResetToken($token)
    {
        if (!static::isPasswordResetTokenValid($token)) {
            return null;
        }

        return static::findOne([
            'PASSWORD_RESET_TOKEN' => $token,
            'STATUS' => self::STATUS_ACTIVE,
        ]);
    }

    /**
     * Finds user by verification email token
     *
     * @param string $token verify email token
     * @return static|null
     */
    public static function findByVerificationToken($token)
    {
        return static::findOne([
            'VERIFICATION_TOKEN' => $token,
            'STATUS' => self::STATUS_INACTIVE,
        ]);
    }

    /**
     * Finds out if password reset token is valid
     *
     * @param string $token password reset token
     * @return bool
     */
    public static function isPasswordResetTokenValid($token)
    {
        if (empty($token)) {
            return false;
        }

        $timestamp = (int)substr($token, strrpos($token, '_') + 1);
        $expire = Yii::$app->params['user.passwordResetTokenExpire'];
        return $timestamp + $expire >= time();
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return $this->AUTH_KEY;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->PASSWORD_HASH);
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->PASSWORD_HASH = Yii::$app->security->generatePasswordHash($password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey()
    {
        $this->AUTH_KEY = Yii::$app->security->generateRandomString();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken()
    {
        $this->PASSWORD_RESET_TOKEN = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Generates new token for email verification
     */
    public function generateEmailVerificationToken()
    {
        $this->VERIFICATION_TOKEN = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken()
    {
        $this->PASSWORD_RESET_TOKEN = null;
    }

    /**
     * Get array of user status.
     *
     * @return array
     */
    public static function getStatusList()
    {
        return [
            self::STATUS_ACTIVE => Yii::t('app', 'Aktif'),
            self::STATUS_INACTIVE => Yii::t('app', 'Tidak Aktif'),
            self::STATUS_DELETED => Yii::t('app', 'Dihapus'),
        ];
    }

    /**
     * Get text from user status.
     *
     * @return string
     */
    public function getStatusText()
    {
        $status = static::getStatusList();
        return isset($status[$this->STATUS]) ? $status[$this->STATUS] : null;
    }

    /**
     * Validate password when resetting
     */
    public function passwordValidation()
    {
        $user = self::findOne(Yii::$app->user->id);
        if (!$user || !$user->validatePassword($this->passwordOld)) {
            $this->addError('passwordOld', Yii::t('app', 'Password lama tidak sesuai.'));
        }
    }

    /**
     * {@inheritdoc}
     */
    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($this->isNewRecord) {
                $this->CREATED_AT = new Expression('NOW()');
                if (!$this->STATUS) {
                    $this->STATUS = self::STATUS_INACTIVE;
                }
            }

            $this->UPDATED_AT = new Expression('NOW()');

            return true;
        }

        return false;
    }
}
