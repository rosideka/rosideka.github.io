<?php
/**
 * @link https://simlab.uns.ac.id
 * @author Agiel K. Saputra <agielkurniawans@gmail.com>
 * @copyright Copyright (c) 2020 UPT TIK UNS
 */

namespace common\models;

use Yii;
use yii\helpers\ArrayHelper;

class MultipleModel extends \yii\base\Model
{
    /**
     * Creates and populates a set of models.
     *
     * @param string $modelClass
     * @param array $multipleModels
     * @param null $data
     * @param string $pk
     * @return array
     */
    public static function create($modelClass, $multipleModels = [], $pk = 'ID', $data = null)
    {
        /* @var $model \yii\db\ActiveRecord */

        $model = new $modelClass();
        $formName = $model->formName();
        $post = empty($data) ? Yii::$app->request->post($formName) : $data[$formName];
        $models = [];

        if (!empty($multipleModels)) {
            $keys = array_keys(ArrayHelper::map($multipleModels, $pk, $pk));
            $multipleModels = array_combine($keys, $multipleModels);
        }

        if ($post && is_array($post)) {
            foreach ($post as $i => $item) {
                if (isset($item[$pk]) && !empty($item[$pk]) && isset($multipleModels[$item[$pk]])) {
                    $models[] = $multipleModels[$item[$pk]];
                } else {
                    $models[] = new $modelClass();
                }
            }
        }

        unset($model, $formName, $post);

        return $models;
    }
}
