<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "REF_LAYANAN".
 *
 * @property int $ID Primary key AI
 * @property string $NAMA
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 *
 * @property RefSubLayanan[] $dataSubLayanan
 */
class RefLayanan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_LAYANAN';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['NAMA'], 'required'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['NAMA'], 'string', 'max' => 150],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'NAMA' => Yii::t('app', 'Nama'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDataSubLayanan()
    {
        return $this->hasMany(RefSubLayanan::class, ['ID_LAYANAN' => 'ID']);
    }

    /**
     * Get array key => value from data
     * @param string $key
     * @param string $value
     * @param array $conditions
     * @return array
     */
    public static function map($key = 'ID', $value = 'NAMA', $conditions = [])
    {
        $query = static::find()->select(['ITEM_KEY' => $key, 'ITEM_VALUE' => $value]);

        if ($orderBy = ArrayHelper::remove($conditions, 'orderBy')) {
            $query->orderBy($orderBy);
        }

        if ($conditions) {
            $query->andWhere($conditions);
        }

        return ArrayHelper::map($query->asArray()->all(), 'ITEM_KEY', 'ITEM_VALUE');
    }

    /**
     * {@inheritdoc}
     * @throws \Throwable
     */
    public function afterDelete()
    {
        parent::afterDelete();

        $models = RefSubLayanan::find()->where(['ID_LAYANAN' => $this->ID])->all();

        foreach ($models as $model) {
            $model->delete();
        }
    }
}
