<?php

namespace common\models\refs;

/**
 * {@inheritdoc}
 */
class RefJenisPaketChild extends RefJenisPaket
{
    // For work with dynamic form with the same tableName
}
