<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use Yii;
use yii\db\Expression;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "REF_JENIS_PAKET".
 *
 * @property int $ID Primary key AI
 * @property int $ID_PARENT ID from table REF_JENIS_PAKET
 * @property string $JENIS_PAKET
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 *
 * @property RefJenisPaket $idParent
 * @property RefJenisPaketChild[] $dataJenisPaket
 */
class RefJenisPaket extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_JENIS_PAKET';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['CREATE_BY', 'UPDATE_BY'], 'default', 'value' => null],
            [['ID_PARENT', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['JENIS_PAKET'], 'required'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['JENIS_PAKET'], 'string', 'max' => 150],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
            [['ID_PARENT'], 'default', 'value' => '0'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'ID_PARENT' => Yii::t('app', 'Induk Paket'),
            'JENIS_PAKET' => Yii::t('app', 'Jenis Paket'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdParent()
    {
        return $this->hasOne(RefJenisPaket::class, ['ID' => 'ID_PARENT']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDataJenisPaket()
    {
        return $this->hasMany(RefJenisPaketChild::class, ['ID_PARENT' => 'ID']);
    }

    /**
     * Get array key => value from data
     * @param string $key
     * @param string $value
     * @param array $conditions
     * @return array
     */
    public static function map($key = 'ID', $value = 'JENIS_PAKET', $conditions = [])
    {
        $query = static::find()->select(['ITEM_KEY' => $key, 'ITEM_VALUE' => $value]);

        if ($orderBy = ArrayHelper::remove($conditions, 'orderBy')) {
            $query->orderBy($orderBy);
        }

        if ($lastChild = ArrayHelper::remove($conditions, 'lastChild')) {
            $query
                ->from(['A' => static::tableName()])
                ->andWhere([
                    '(' . RefJenisPaket::find()->select(['COUNT(*)'])->where(['ID_PARENT' => new Expression('"A"."ID"')])->createCommand()->rawSql . ')' => 0,
                ]);
        }

        if ($conditions) {
            $query->andWhere($conditions);
        }

        return ArrayHelper::map($query->asArray()->all(), 'ITEM_KEY', 'ITEM_VALUE');
    }

    /**
     * {@inheritdoc}
     * @throws \Throwable
     */
    public function afterDelete()
    {
        parent::afterDelete();

        $models = $this->dataJenisPaket;

        foreach ($models as $model) {
            $model->delete();
        }
    }
}
