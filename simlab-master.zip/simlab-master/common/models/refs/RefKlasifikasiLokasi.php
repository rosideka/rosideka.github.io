<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "REF_KLASIFIKASI_LOKASI".
 *
 * @property int $ID Primary key AI
 * @property string $KLASIFIKASI_LOKASI
 * @property int $IS_DEFAULT 0: Tidak ditampilkan pada pilihan; 1: Ditampilkan pada pilihan
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 *
 * @property \common\models\User $createBy
 * @property \common\models\User $updateBy
 */
class RefKlasifikasiLokasi extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_KLASIFIKASI_LOKASI';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KLASIFIKASI_LOKASI'], 'required'],
            [['IS_DEFAULT', 'CREATE_BY', 'UPDATE_BY'], 'default', 'value' => null],
            [['IS_DEFAULT', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KLASIFIKASI_LOKASI'], 'string', 'max' => 150],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'KLASIFIKASI_LOKASI' => Yii::t('app', 'Klasifikasi Lokasi'),
            'IS_DEFAULT' => Yii::t('app', 'Aktif?'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
        ];
    }

    /**
     * Get array key => value from data
     * @param string $key
     * @param string $value
     * @param array $conditions
     * @return array
     */
    public static function map($key = 'ID', $value = 'KLASIFIKASI_LOKASI', $conditions = [])
    {
        $query = static::find()->select(['ITEM_KEY' => $key, 'ITEM_VALUE' => $value]);

        if ($orderBy = ArrayHelper::remove($conditions, 'orderBy')) {
            $query->orderBy($orderBy);
        }

        if ($conditions) {
            $query->andWhere($conditions);
        }

        return ArrayHelper::map($query->asArray()->all(), 'ITEM_KEY', 'ITEM_VALUE');
    }
}
