<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use common\models\simlab\Pegawai;
use common\models\User;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "REF_LAB".
 *
 * @property int $ID Primary key AI
 * @property string $KODE
 * @property string $NAMA Nama laboratorium
 * @property string $DESKRIPSI Deskripsi singkat laboratorium
 * @property string $LOKASI
 * @property string $KELOMPOK_UJI Menentukan kelompok uji
 * @property int|null $IDP_KETUA ID from table SIMLAB_PEGAWAI
 * @property string $FILE_NAME Upload  gambar atau menggunakan default image
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 *
 * @property Pegawai $idpKetua
 * @property User $createBy
 * @property User $updateBy
 */
class RefLab extends \yii\db\ActiveRecord
{
    /**
     * @var
     */
    public $file;

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_LAB';
    }

    /**
     * {@inheritdoc}
     */

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['NAMA', 'DESKRIPSI', 'LOKASI', 'KELOMPOK_UJI'], 'required'],
            [['DESKRIPSI'], 'string'],
            [['IDP_KETUA', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KODE'], 'string', 'max' => 10],
            [['NAMA', 'LOKASI'], 'string', 'max' => 150],
            [['KELOMPOK_UJI'], 'string', 'max' => 100],
            [['FILE_NAME'], 'string', 'max' => 255],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
            [['KODE'], 'unique'],
            [['file'], 'file', 'extensions' => ['png', 'jpg', 'jpeg', 'gif'], 'maxSize' => 5 * 1024 * 1024],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'KODE' => Yii::t('app', 'Kode'),
            'NAMA' => Yii::t('app', 'Nama'),
            'DESKRIPSI' => Yii::t('app', 'Deskripsi'),
            'LOKASI' => Yii::t('app', 'Lokasi'),
            'KELOMPOK_UJI' => Yii::t('app', 'Kelompok Uji'),
            'IDP_KETUA' => Yii::t('app', 'Ketua'),
            'FILE_NAME' => Yii::t('app', 'Foto'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
            'file' => Yii::t('app', 'Foto'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdpKetua()
    {
        return $this->hasOne(Pegawai::class, ['ID' => 'IDP_KETUA']);
    }

    /**
     * @param null $filename
     * @return bool|string
     */
    public function getFileUrl($filename = null)
    {
        $filename = $filename ?: $this->FILE_NAME;
        return Yii::getAlias('@baseUrl/uploads/' . $filename);
    }

    /**
     * @param null $filename
     * @return bool|string
     */
    public function getFilePath($filename = null)
    {
        $filename = $filename ?: $this->FILE_NAME;
        return Yii::getAlias('@appPath/uploads/' . $filename);
    }

    /**
     * Get array key => value from data
     * @param string $key
     * @param string $value
     * @param array $conditions
     * @return array
     */
    public static function map($key = 'ID', $value = 'NAMA', $conditions = [])
    {
        $query = static::find()->select(['ITEM_KEY' => $key, 'ITEM_VALUE' => $value]);

        if ($orderBy = ArrayHelper::remove($conditions, 'orderBy')) {
            $query->orderBy($orderBy);
        }

        if ($conditions) {
            $query->andWhere($conditions);
        }

        return ArrayHelper::map($query->asArray()->all(), 'ITEM_KEY', 'ITEM_VALUE');
    }

    /**
     * {@inheritdoc}
     */
    public function afterDelete()
    {
        parent::afterDelete();

        if (is_file($this->getFilePath())) {
            unlink($this->getFilePath());
        }
    }
}
