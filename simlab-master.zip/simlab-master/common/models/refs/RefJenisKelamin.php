<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "REF_JENIS_KELAMIN".
 *
 * @property int $ID Primary key AI
 * @property string $KODE Kode jenis kelamin L, P
 * @property string $JENIS_KELAMIN Jenis kelamin Laki-laki, Perempuan
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 */
class RefJenisKelamin extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => ['class' => LogBehavior::class]];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_JENIS_KELAMIN';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KODE', 'JENIS_KELAMIN'], 'required'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['KODE'], 'string', 'max' => 10],
            [['JENIS_KELAMIN'], 'string', 'max' => 150],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
            [['KODE'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'KODE' => Yii::t('app', 'Kode'),
            'JENIS_KELAMIN' => Yii::t('app', 'Jenis Kelamin'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
        ];
    }

    /**
     * Get array key => value from data
     * @param string $key
     * @param string $value
     * @param array $conditions
     * @return array
     */
    public static function map($key = 'ID', $value = 'JENIS_KELAMIN', $conditions = [])
    {
        $query = static::find()->select(['ITEM_KEY' => $key, 'ITEM_VALUE' => $value]);

        if ($orderBy = ArrayHelper::remove($conditions, 'orderBy')) {
            $query->orderBy($orderBy);
        }

        if ($conditions) {
            $query->andWhere($conditions);
        }

        return ArrayHelper::map($query->asArray()->all(), 'ITEM_KEY', 'ITEM_VALUE');
    }
}
