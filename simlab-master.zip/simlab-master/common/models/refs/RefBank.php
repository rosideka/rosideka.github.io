<?php

namespace common\models\refs;

use common\classes\LogBehavior;
use Yii;

/**
 * This is the model class for table "REF_BANK".
 *
 * @property int $ID Primary key AI
 * @property string $KODE Kode bank
 * @property string $NAMA Nama bank
 * @property int $IS_AKTIF (1) Aktif (0) Nonaktif
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP IPv4 or IPv6
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP IPv4 or IPv6
 */
class RefBank extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return ['log' => LogBehavior::class];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_BANK';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KODE', 'NAMA'], 'required'],
            [['IS_AKTIF', 'CREATE_BY', 'UPDATE_BY'], 'default', 'value' => null],
            [['IS_AKTIF', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KODE'], 'string', 'max' => 10],
            [['NAMA'], 'string', 'max' => 255],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'KODE' => Yii::t('app', 'Kode'),
            'NAMA' => Yii::t('app', 'Nama'),
            'IS_AKTIF' => Yii::t('app', 'Aktif?'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_IP' => Yii::t('app', 'Create IP'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_IP' => Yii::t('app', 'Update IP'),
        ];
    }
}
