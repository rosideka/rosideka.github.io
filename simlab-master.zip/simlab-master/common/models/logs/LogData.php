<?php

namespace common\models\logs;

use common\models\User;
use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Json;

/**
 * This is the model class for table "LOG_DATA".
 *
 * @property int $ID
 * @property int $USER_ID ID from User
 * @property string|null $USER_IP IPv4 or IPv6
 * @property int $ACTION_TYPE 1: create 2: update 3: delete
 * @property string $ACTION_DATE
 * @property string $APP_NAME ID from app config
 * @property string $CONTROLLER Controller that execute the command
 * @property string $CONTROLLER_ID Controller ID that execute the command
 * @property string $ACTION_ID Action ID from the controller
 * @property string $TABLE_NAME Table name
 * @property string $MODEL_NAME Model name
 * @property string $MODEL_ID Model ID, can be a composite key
 * @property string|null $DATA_OLD Data before update
 * @property string|null $DATA_NEW Data after update
 * @property int $IS_ROLLBACK
 *
 * @property User $userId
 */
class LogData extends \yii\db\ActiveRecord
{
    const ACTION_CREATE = 1;

    const ACTION_UPDATE = 2;

    const ACTION_DELETE = 3;

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'LOG_DATA';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [
                [
                    'USER_ID',
                    'ACTION_TYPE',
                    'APP_NAME',
                    'CONTROLLER',
                    'CONTROLLER_ID',
                    'ACTION_ID',
                    'TABLE_NAME',
                    'MODEL_NAME',
                    'MODEL_ID',
                ],
                'required',
            ],
            [['USER_ID', 'ACTION_TYPE', 'IS_ROLLBACK'], 'integer'],
            [['ACTION_DATE'], 'safe'],
            [['DATA_OLD', 'DATA_NEW'], 'string'],
            [['USER_IP', 'ACTION_ID', 'TABLE_NAME'], 'string', 'max' => 50],
            [['APP_NAME'], 'string', 'max' => 255],
            [['CONTROLLER', 'MODEL_NAME'], 'string', 'max' => 200],
            [['CONTROLLER_ID', 'MODEL_ID'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'USER_ID' => Yii::t('app', 'ID User'),
            'USER_IP' => Yii::t('app', 'IP User'),
            'ACTION_TYPE' => Yii::t('app', 'Tipe Aksi'),
            'ACTION_DATE' => Yii::t('app', 'Tanggal Aksi'),
            'APP_NAME' => Yii::t('app', 'Nama App'),
            'CONTROLLER' => Yii::t('app', 'Controller'),
            'CONTROLLER_ID' => Yii::t('app', 'ID Controller'),
            'ACTION_ID' => Yii::t('app', 'ID Action'),
            'TABLE_NAME' => Yii::t('app', 'Nama Tabel'),
            'MODEL_NAME' => Yii::t('app', 'Nama Model'),
            'MODEL_ID' => Yii::t('app', 'ID Model'),
            'DATA_OLD' => Yii::t('app', 'Data Lama'),
            'DATA_NEW' => Yii::t('app', 'Data Baru'),
            'IS_ROLLBACK' => Yii::t('app', 'Rollback?'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserId()
    {
        return $this->hasOne(User::class, ['ID' => 'USER_ID']);
    }

    /**
     * @return array
     */
    public static function getActionTypeList()
    {
        return [
            self::ACTION_CREATE => Yii::t('app', 'Create'),
            self::ACTION_UPDATE => Yii::t('app', 'Update'),
            self::ACTION_DELETE => Yii::t('app', 'Delete'),
        ];
    }

    /**
     * @return mixed
     */
    public function getActionTypeText()
    {
        return ArrayHelper::getValue(static::getActionTypeList(), $this->ACTION_TYPE);
    }

    /**
     * @return array
     */
    public function getDataDiff()
    {
        return array_diff_assoc($this->getDataNew(), $this->getDataOld());
    }

    /**
     * @return mixed
     */
    public function getDataOld()
    {
        return array_filter(Json::decode($this->DATA_OLD), function ($data) {
            return !is_array($data);
        });
    }

    /**
     * @return mixed
     */
    public function getDataNew()
    {
        return array_filter(Json::decode($this->DATA_NEW), function ($data) {
            return !is_array($data);
        });
    }
}
