<?php

namespace common\models\eis;

use Yii;

/**
 * This is the model class for table "REF_UNIT".
 *
 * @property int $ID
 * @property string $KODE
 * @property string $KODE_LAMA
 * @property string $NAMA
 * @property int $ID_UNIT_JENIS
 * @property string $KODE_UNIT_RIIL
 * @property string $KODE_BAN
 * @property string $KODE_SIAKAD
 * @property string|null $KODE_REGISTRASI
 * @property string|null $KODE_SPMB
 * @property string|null $NIM_AWAL
 * @property string|null $JENJANG
 * @property string|null $KODE_SIMAK
 * @property int $ID_UNIT
 * @property int|null $ID_GJ
 * @property int|null $ID_SIMPEG
 * @property int|null $ID_SIA
 * @property int|null $IS_UNIT_SPMB
 * @property int|null $IS_AKTIF
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_DATE
 * @property string|null $CREATE_IP
 * @property string|null $UPDATE_IP
 */
class RefSubUnit extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_UNIT';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDb()
    {
        return Yii::$app->get('dbeis');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KODE', 'KODE_LAMA', 'NAMA', 'ID_UNIT_JENIS', 'KODE_UNIT_RIIL', 'KODE_BAN', 'KODE_SIAKAD', 'ID_UNIT'], 'required'],
            [['ID_UNIT_JENIS', 'ID_UNIT', 'ID_GJ', 'ID_SIMPEG', 'ID_SIA', 'IS_UNIT_SPMB', 'IS_AKTIF', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KODE', 'KODE_LAMA', 'KODE_UNIT_RIIL', 'KODE_BAN', 'KODE_SIAKAD', 'KODE_REGISTRASI', 'KODE_SPMB', 'KODE_SIMAK'], 'string', 'max' => 20],
            [['NAMA', 'CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 100],
            [['NIM_AWAL'], 'string', 'max' => 3],
            [['JENJANG'], 'string', 'max' => 10],
            [['KODE'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'KODE' => 'Kode',
            'KODE_LAMA' => 'Kode Lama',
            'NAMA' => 'Nama',
            'ID_UNIT_JENIS' => 'Id Unit Jenis',
            'KODE_UNIT_RIIL' => 'Kode Unit Riil',
            'KODE_BAN' => 'Kode Ban',
            'KODE_SIAKAD' => 'Kode Siakad',
            'KODE_REGISTRASI' => 'Kode Registrasi',
            'KODE_SPMB' => 'Kode Spmb',
            'NIM_AWAL' => 'Nim Awal',
            'JENJANG' => 'Jenjang',
            'KODE_SIMAK' => 'Kode Simak',
            'ID_UNIT' => 'Id Unit',
            'ID_GJ' => 'Id Gj',
            'ID_SIMPEG' => 'Id Simpeg',
            'ID_SIA' => 'Id Sia',
            'IS_UNIT_SPMB' => 'Is Unit Spmb',
            'IS_AKTIF' => 'Is Aktif',
            'CREATE_BY' => 'Create By',
            'CREATE_DATE' => 'Create Date',
            'UPDATE_BY' => 'Update By',
            'UPDATE_DATE' => 'Update Date',
            'CREATE_IP' => 'Create Ip',
            'UPDATE_IP' => 'Update Ip',
        ];
    }
}
