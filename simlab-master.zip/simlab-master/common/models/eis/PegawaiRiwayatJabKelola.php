<?php

namespace common\models\eis;

use Yii;
use yii\db\ActiveQuery;

/**
 * This is the model class for table "PEGAWAI_RIWAYAT_JAB_KELOLA".
 *
 * @property int $ID
 * @property int $ID_PEGAWAI
 * @property int $ID_JENIS_PEGAWAI 1:Pendidik, 2:Tendik
 * @property int $ID_JABATAN
 * @property int $ID_JABATAN_DETAIL
 * @property string $URAIAN_JABATAN
 * @property string $NOMOR_SK
 * @property string $TANGGAL_SK
 * @property string $TANGGAL_AWAL
 * @property string $TANGGAL_AKHIR
 * @property int $ID_SK_DARI
 * @property string $JAB_SK_DARI
 * @property int $ID_PEJABAT_PENANDA_TANGAN
 * @property string $JAB_PEJABAT_PENANDA_TANGAN
 * @property string $PERIODE
 * @property string $ESELON
 * @property int $ID_STATUS_JABATAN
 * @property int $IS_BERAKHIR
 * @property int $IS_DEFAULT
 * @property int $ID_APPROVE
 * @property string $UPDATE_DATE
 */
class PegawaiRiwayatJabKelola extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PEGAWAI_RIWAYAT_JAB_KELOLA';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDb()
    {
        return Yii::$app->get('dbeis');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ID'], 'required'],
            [
                [
                    'ID',
                    'ID_PEGAWAI',
                    'ID_JENIS_PEGAWAI',
                    'ID_JABATAN',
                    'ID_JABATAN_DETAIL',
                    'ID_SK_DARI',
                    'ID_PEJABAT_PENANDA_TANGAN',
                    'ID_STATUS_JABATAN',
                    'IS_BERAKHIR',
                    'IS_DEFAULT',
                    'ID_APPROVE',
                ],
                'integer',
            ],
            [['URAIAN_JABATAN'], 'string'],
            [['TANGGAL_SK', 'TANGGAL_AWAL', 'TANGGAL_AKHIR', 'UPDATE_DATE'], 'safe'],
            [['NOMOR_SK', 'JAB_SK_DARI', 'JAB_PEJABAT_PENANDA_TANGAN'], 'string', 'max' => 255],
            [['PERIODE'], 'string', 'max' => 50],
            [['ESELON'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'ID_PEGAWAI' => 'Pegawai',
            'ID_JENIS_PEGAWAI' => 'Jenis Pegawai',
            'ID_JABATAN' => 'Jabatan',
            'ID_JABATAN_DETAIL' => 'Jabatan Detail',
            'URAIAN_JABATAN' => 'Uraian Jabatan',
            'NOMOR_SK' => 'Nomor SK',
            'TANGGAL_SK' => 'Tanggal SK',
            'TANGGAL_AWAL' => 'Tanggal Awal',
            'TANGGAL_AKHIR' => 'Tanggal Akhir',
            'ID_SK_DARI' => 'SK Dari',
            'JAB_SK_DARI' => 'Jab. SK Dari',
            'ID_PEJABAT_PENANDA_TANGAN' => 'Penanda Tangan',
            'JAB_PEJABAT_PENANDA_TANGAN' => 'Jab. Penanda Tangan',
            'PERIODE' => 'Periode',
            'ESELON' => 'Eselon',
            'ID_STATUS_JABATAN' => 'Status Jabatan',
            'IS_BERAKHIR' => 'Berakhir?',
            'IS_DEFAULT' => 'Default?',
            'ID_APPROVE' => 'ID Approve',
            'UPDATE_DATE' => 'Update Date',
        ];
    }

    /**
     * @return ActiveQuery
     */
    public function getIdPegawai()
    {
        return $this->hasOne(Pegawai::class, ['ID' => 'ID_PEGAWAI']);
    }

    /**
     * @param int $id ID_JABATAN_DETAIL
     * @param string|null $tgl
     * @return ActiveQuery
     */
    public static function findByJabatan(int $id, string $tgl = null)
    {
        $queryIdsPegawai = static::find()
            ->select(['ID_PEGAWAI'])
            ->where(['ID_JABATAN_DETAIL' => $id]);

        if ($tgl) {
            $queryIdsPegawai->andWhere(['and', ['<=', 'TANGGAL_AWAL', $tgl], ['>=', 'TANGGAL_AKHIR', $tgl]]);
        } else {
            $queryIdsPegawai->andWhere(['IS_BERAKHIR' => 0]);
        }

        return Pegawai::find()->where(['in', 'ID', $queryIdsPegawai]);
    }

    /**
     * @param int $id ID_PEGAWAI
     * @return ActiveQuery
     */
    public static function findByPegawai(int $id)
    {
        return static::find()->where(['ID_JABATAN_DETAIL' => $id])
            ->where(['ID_PEGAWAI' => $id, 'IS_BERAKHIR' => 0]);
    }
}
