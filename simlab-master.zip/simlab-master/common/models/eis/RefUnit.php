<?php

namespace common\models\eis;

use Yii;

/**
 * This is the model class for table "REF_UNIT_FAKULTAS".
 *
 * @property int $ID_FAKULTAS
 * @property int $ID_JENIS_STAF
 * @property string|null $KODE_FAKULTAS
 * @property string $FAKULTAS
 * @property string $FAKULTAS_LENGKAP
 * @property string|null $EMAIL_KEPEGAWAIAN Email yang digunakan operator
 * @property int|null $ID_UNIT ID dari REF_UNIT
 * @property string|null $CREATE_DATE
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_IP
 * @property string|null $UPDATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_IP
 */
class RefUnit extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_UNIT_FAKULTAS';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDb()
    {
        return Yii::$app->get('dbeis');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ID_JENIS_STAF', 'FAKULTAS', 'FAKULTAS_LENGKAP'], 'required'],
            [['ID_JENIS_STAF', 'ID_UNIT', 'CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KODE_FAKULTAS'], 'string', 'max' => 5],
            [['FAKULTAS'], 'string', 'max' => 6],
            [['FAKULTAS_LENGKAP'], 'string', 'max' => 50],
            [['EMAIL_KEPEGAWAIAN'], 'string', 'max' => 255],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID_FAKULTAS' => 'Id Fakultas',
            'ID_JENIS_STAF' => 'Id Jenis Staf',
            'KODE_FAKULTAS' => 'Kode Fakultas',
            'FAKULTAS' => 'Fakultas',
            'FAKULTAS_LENGKAP' => 'Fakultas Lengkap',
            'EMAIL_KEPEGAWAIAN' => 'Email Kepegawaian',
            'ID_UNIT' => 'Id Unit',
            'CREATE_DATE' => 'Create Date',
            'CREATE_BY' => 'Create By',
            'CREATE_IP' => 'Create Ip',
            'UPDATE_DATE' => 'Update Date',
            'UPDATE_BY' => 'Update By',
            'UPDATE_IP' => 'Update Ip',
        ];
    }
}
