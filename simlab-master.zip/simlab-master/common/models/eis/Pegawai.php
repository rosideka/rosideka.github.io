<?php

namespace common\models\eis;

use Yii;

/**
 * This is the model class for table "PEGAWAI".
 *
 * @property int $ID
 * @property string|null $ID_SISTER
 * @property int $ID_UNIT
 * @property int|null $ID_SUB_UNIT
 * @property int $ID_JENIS_STAF
 * @property int|null $ID_GOL_RUANG
 * @property int|null $ID_JABATAN_FUNGSIONAL
 * @property int|null $ID_JABATAN_FUNGSIONAL_DETIL
 * @property string|null $TMT_JAB_FUNGSIONAL
 * @property int|null $ID_JABATAN_STRUKTURAL
 * @property int|null $ID_JABATAN_STRUKTURAL_DETIL
 * @property string|null $TMT_JAB_STRUKTURAL_AWAL
 * @property string|null $TMT_JAB_STRUKTURAL_AKHIR
 * @property string|null $KET_DETIL_JABATAN
 * @property int|null $ID_PENDIDIKAN_TERTINGGI
 * @property int|null $ID_PENDIDIKAN_TERAKHIR
 * @property int $ID_STATUS_PEGAWAI
 * @property int $ID_JENIS_KELAMIN
 * @property int|null $ID_STATUS_KAWIN
 * @property int $ID_STATUS_HENTI
 * @property int|null $ID_STATUS_STUDI
 * @property int|null $ID_AGAMA
 * @property int|null $ID_GOLONGAN_DARAH
 * @property string $NAMA
 * @property string|null $GELAR_DEPAN
 * @property string|null $GELAR_BELAKANG
 * @property string|null $NAMA_LENGKAP
 * @property string $NIP
 * @property string|null $TEMPAT_LAHIR
 * @property string $TANGGAL_LAHIR
 * @property string|null $NIDN
 * @property string|null $NOMOR_KARPEG
 * @property string|null $NOMOR_KTP
 * @property string|null $NOMOR_TELEPON_HP
 * @property string|null $ALAMAT_EMAIL
 * @property string|null $EMAIL_SSO
 * @property int|null $ID_BANK
 * @property string|null $NOMOR_NPWP
 * @property string|null $TMT_GOL_RUANG
 * @property int|null $ID_GOLONGAN_RUANG_CPNS
 * @property string|null $TMT_CPNS
 * @property int|null $ID_GOLONGAN_RUANG_PNS
 * @property string|null $TMT_PNS
 * @property string|null $TMT_KGB
 * @property string|null $TMT_MKG
 * @property string|null $ID_JENJANG_HOMEBASE
 * @property string|null $ID_PRODI_HOMEBASE
 * @property int|null $ID_JENIS_IKATAN
 * @property int|null $ID_SERTIFIKASI
 * @property string|null $TMT_SK_PENGANGKATAN
 * @property string|null $FILE_FOTO_NAME
 * @property string|null $FILE_FOTO_PATH
 * @property string|null $FILE_FOTO_URL
 * @property string|null $UPDATE_DATE
 */
class Pegawai extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'PEGAWAI';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDb()
    {
        return Yii::$app->get('dbeis');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ID', 'ID_JENIS_STAF', 'ID_STATUS_PEGAWAI', 'ID_JENIS_KELAMIN', 'NAMA', 'NIP', 'TANGGAL_LAHIR'], 'required'],
            [['ID', 'ID_UNIT', 'ID_SUB_UNIT', 'ID_JENIS_STAF', 'ID_GOL_RUANG', 'ID_JABATAN_FUNGSIONAL', 'ID_JABATAN_FUNGSIONAL_DETIL', 'ID_JABATAN_STRUKTURAL', 'ID_JABATAN_STRUKTURAL_DETIL', 'ID_PENDIDIKAN_TERTINGGI', 'ID_PENDIDIKAN_TERAKHIR', 'ID_STATUS_PEGAWAI', 'ID_JENIS_KELAMIN', 'ID_STATUS_KAWIN', 'ID_STATUS_HENTI', 'ID_STATUS_STUDI', 'ID_AGAMA', 'ID_GOLONGAN_DARAH', 'ID_BANK', 'ID_GOLONGAN_RUANG_CPNS', 'ID_GOLONGAN_RUANG_PNS', 'ID_JENIS_IKATAN', 'ID_SERTIFIKASI'], 'integer'],
            [['TMT_JAB_FUNGSIONAL', 'TMT_JAB_STRUKTURAL_AWAL', 'TMT_JAB_STRUKTURAL_AKHIR', 'TANGGAL_LAHIR', 'TMT_GOL_RUANG', 'TMT_CPNS', 'TMT_PNS', 'TMT_KGB', 'TMT_MKG', 'TMT_SK_PENGANGKATAN', 'UPDATE_DATE'], 'safe'],
            [['ID_SISTER', 'KET_DETIL_JABATAN'], 'string', 'max' => 255],
            [['NAMA', 'NAMA_LENGKAP', 'FILE_FOTO_NAME', 'FILE_FOTO_PATH', 'FILE_FOTO_URL'], 'string', 'max' => 300],
            [['GELAR_DEPAN', 'GELAR_BELAKANG', 'TEMPAT_LAHIR', 'NOMOR_KTP'], 'string', 'max' => 30],
            [['NIP'], 'string', 'max' => 18],
            [['NIDN', 'NOMOR_TELEPON_HP'], 'string', 'max' => 20],
            [['NOMOR_KARPEG', 'ID_JENJANG_HOMEBASE', 'ID_PRODI_HOMEBASE'], 'string', 'max' => 10],
            [['ALAMAT_EMAIL', 'NOMOR_NPWP'], 'string', 'max' => 50],
            [['EMAIL_SSO'], 'string', 'max' => 100],
            [['NIP'], 'unique'],
            [['ID'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'ID_SISTER' => 'Id Sister',
            'ID_UNIT' => 'Id Unit',
            'ID_SUB_UNIT' => 'Id Sub Unit',
            'ID_JENIS_STAF' => 'Id Jenis Staf',
            'ID_GOL_RUANG' => 'Id Gol Ruang',
            'ID_JABATAN_FUNGSIONAL' => 'Id Jabatan Fungsional',
            'ID_JABATAN_FUNGSIONAL_DETIL' => 'Id Jabatan Fungsional Detil',
            'TMT_JAB_FUNGSIONAL' => 'Tmt Jab Fungsional',
            'ID_JABATAN_STRUKTURAL' => 'Id Jabatan Struktural',
            'ID_JABATAN_STRUKTURAL_DETIL' => 'Id Jabatan Struktural Detil',
            'TMT_JAB_STRUKTURAL_AWAL' => 'Tmt Jab Struktural Awal',
            'TMT_JAB_STRUKTURAL_AKHIR' => 'Tmt Jab Struktural Akhir',
            'KET_DETIL_JABATAN' => 'Ket Detil Jabatan',
            'ID_PENDIDIKAN_TERTINGGI' => 'Id Pendidikan Tertinggi',
            'ID_PENDIDIKAN_TERAKHIR' => 'Id Pendidikan Terakhir',
            'ID_STATUS_PEGAWAI' => 'Id Status Pegawai',
            'ID_JENIS_KELAMIN' => 'Id Jenis Kelamin',
            'ID_STATUS_KAWIN' => 'Id Status Kawin',
            'ID_STATUS_HENTI' => 'Id Status Henti',
            'ID_STATUS_STUDI' => 'Id Status Studi',
            'ID_AGAMA' => 'Id Agama',
            'ID_GOLONGAN_DARAH' => 'Id Golongan Darah',
            'NAMA' => 'Nama',
            'GELAR_DEPAN' => 'Gelar Depan',
            'GELAR_BELAKANG' => 'Gelar Belakang',
            'NAMA_LENGKAP' => 'Nama Lengkap',
            'NIP' => 'Nip',
            'TEMPAT_LAHIR' => 'Tempat Lahir',
            'TANGGAL_LAHIR' => 'Tanggal Lahir',
            'NIDN' => 'Nidn',
            'NOMOR_KARPEG' => 'Nomor Karpeg',
            'NOMOR_KTP' => 'Nomor Ktp',
            'NOMOR_TELEPON_HP' => 'Nomor Telepon Hp',
            'ALAMAT_EMAIL' => 'Alamat Email',
            'EMAIL_SSO' => 'Email Sso',
            'ID_BANK' => 'Id Bank',
            'NOMOR_NPWP' => 'Nomor Npwp',
            'TMT_GOL_RUANG' => 'Tmt Gol Ruang',
            'ID_GOLONGAN_RUANG_CPNS' => 'Id Golongan Ruang Cpns',
            'TMT_CPNS' => 'Tmt Cpns',
            'ID_GOLONGAN_RUANG_PNS' => 'Id Golongan Ruang Pns',
            'TMT_PNS' => 'Tmt Pns',
            'TMT_KGB' => 'Tmt Kgb',
            'TMT_MKG' => 'Tmt Mkg',
            'ID_JENJANG_HOMEBASE' => 'Id Jenjang Homebase',
            'ID_PRODI_HOMEBASE' => 'Id Prodi Homebase',
            'ID_JENIS_IKATAN' => 'Id Jenis Ikatan',
            'ID_SERTIFIKASI' => 'Id Sertifikasi',
            'TMT_SK_PENGANGKATAN' => 'Tmt Sk Pengangkatan',
            'FILE_FOTO_NAME' => 'File Foto Name',
            'FILE_FOTO_PATH' => 'File Foto Path',
            'FILE_FOTO_URL' => 'File Foto Url',
            'UPDATE_DATE' => 'Update Date',
        ];
    }
}
