<?php

namespace common\models\eis;

use Yii;

/**
 * This is the model class for table "REF_JENIS_KELAMIN".
 *
 * @property int $ID_JENIS_KELAMIN
 * @property string $KODE_KELAMIN
 * @property string $JENIS_KELAMIN
 * @property int|null $CREATE_BY
 * @property string|null $CREATE_DATE
 * @property int|null $UPDATE_BY
 * @property string|null $UPDATE_DATE
 * @property string|null $CREATE_IP
 * @property string|null $UPDATE_IP
 */
class RefJenisKelamin extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'REF_JENIS_KELAMIN';
    }

    /**
     * {@inheritdoc}
     */
    public static function getDb()
    {
        return Yii::$app->get('dbeis');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['KODE_KELAMIN', 'JENIS_KELAMIN'], 'required'],
            [['CREATE_BY', 'UPDATE_BY'], 'integer'],
            [['CREATE_DATE', 'UPDATE_DATE'], 'safe'],
            [['KODE_KELAMIN'], 'string', 'max' => 1],
            [['JENIS_KELAMIN'], 'string', 'max' => 10],
            [['CREATE_IP', 'UPDATE_IP'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID_JENIS_KELAMIN' => Yii::t('app', 'Id Jenis Kelamin'),
            'KODE_KELAMIN' => Yii::t('app', 'Kode Kelamin'),
            'JENIS_KELAMIN' => Yii::t('app', 'Jenis Kelamin'),
            'CREATE_BY' => Yii::t('app', 'Create By'),
            'CREATE_DATE' => Yii::t('app', 'Create Date'),
            'UPDATE_BY' => Yii::t('app', 'Update By'),
            'UPDATE_DATE' => Yii::t('app', 'Update Date'),
            'CREATE_IP' => Yii::t('app', 'Create Ip'),
            'UPDATE_IP' => Yii::t('app', 'Update Ip'),
        ];
    }
}
